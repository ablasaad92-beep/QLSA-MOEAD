package FFT_8p_GSA;



import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

public class Filter {

    public static void main(String[] args) {
        String filePath = "./output/Montage/data/set_montage_0.5.txt"; // Replace with the actual path to your data file

        try {
            List<ParetoSolution> rawSolutions = readData(filePath);

            // Sort the data based on to minimize and maximize objectives
            rawSolutions.sort((s1, s2) -> {
                if (s1.minimizeObjective != s2.minimizeObjective) {
                    return Double.compare(s1.minimizeObjective, s2.minimizeObjective);
                } else {
                    return -Double.compare(s1.maximizeObjective, s2.maximizeObjective);
                }
            });

            // Filter the non-dominated set
            List<ParetoSolution> nonDominatedSet = filterNonDominated(rawSolutions);

            // Print the result
            for (ParetoSolution solution : nonDominatedSet) {
                System.out.println("Minimize: " + solution.minimizeObjective + ", Maximize: " + solution.maximizeObjective);
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    static List<ParetoSolution> readData(String filePath) throws IOException {
        List<ParetoSolution> solutions = new ArrayList<>();

        try (BufferedReader reader = new BufferedReader(new FileReader(filePath))) {
            String line;
            while ((line = reader.readLine()) != null) {
                String[] values = line.trim().split(",");
                double minimizeObjective = Double.parseDouble(values[0]);
                double maximizeObjective = Double.parseDouble(values[1]);
                solutions.add(new ParetoSolution(minimizeObjective, maximizeObjective));
            }
        }

        return solutions;
    }

    static List<ParetoSolution> filterNonDominated(List<ParetoSolution> solutions) {
        List<ParetoSolution> nonDominatedSet = new ArrayList<>();
           // Sort the data based on to minimize and maximize objectives
            solutions.sort((s1, s2) -> {
                if (s1.minimizeObjective != s2.minimizeObjective) {
                    return Double.compare(s1.minimizeObjective, s2.minimizeObjective);
                } else {
                    return -Double.compare(s1.maximizeObjective, s2.maximizeObjective);
                }
            });
        for (ParetoSolution candidate : solutions) {
            if (!isDominated(candidate, nonDominatedSet)) {
                nonDominatedSet.add(candidate);
            }
        }

        return nonDominatedSet;
    }

    static boolean isDominated(ParetoSolution candidate, List<ParetoSolution> existingSet) {
        // Check if the candidate is dominated by any solution in the existing set
        for (ParetoSolution solution : existingSet) {
            if (solution.minimizeObjective <= candidate.minimizeObjective
                    && solution.maximizeObjective >= candidate.maximizeObjective) {
                return true;
            }
        }
        return false;
    }

}
