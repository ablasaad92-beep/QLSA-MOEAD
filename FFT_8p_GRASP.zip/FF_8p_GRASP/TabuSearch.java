/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package FF_8p_GRASP;



import java.util.*;


/**
 * @author AblaSaad
 */
public class TabuSearch {

    int cl[];
    public int RCL[];
    public int[] finalRCL;
    public double alpha = 0.4;

    int[] bestSol;
    double bestMake;
    int[] constructionSolution;

    MachineAssign S1;
    ArrayList<Double> probability;
    Set<int[]> solution;
    ArrayList<int[]> options;

    ArrayList<int[]> population;
    ArrayList<Double> pop_make;
    int TABU_ITEM_LIFETIME = 10;
    int TABU_LIST_MAX_LENGTH = 50;
    int MAX_ITERATION = 100;
    int NO_IMPROVEMENT_LIMIT = 200;
    ArrayList<int[]> TabuList;
    ArrayList<Double > TabuList_makespan;

    public TabuSearch() {
        cl = new int[GraphSimulation.noftasks];
        constructionSolution = new int[GraphSimulation.noftasks];
        probability = new ArrayList<>();
        solution = new HashSet<>();
        options = new ArrayList<>();
        bestSol = new int[GraphSimulation.noftasks];
        TabuList = new ArrayList<>();
        population = new ArrayList<>();
        pop_make = new ArrayList<>();
        TabuList_makespan=new ArrayList<>();;
    }

    // Validate Any Schedule
    public boolean validateConstruction() {
        boolean valid = true;
        for (int i = 0; i < constructionSolution.length; i++) {
            for (int ii = i + 1; ii < constructionSolution.length; ii++) {
                if ((GraphSimulation.level[constructionSolution[i]] > GraphSimulation.level[constructionSolution[ii]])) {
                    valid = false;
                    break;
                }
            }
        }

        return valid;
    }

    //      Phase 1 Construction Phase
    public void construct(int[] cl) throws Exception {
       
        constructionSolution =  new GraphUtils().random_population().clone();
    }

    //_________________Tabu-Search_________________//
    public void Tabu_Search() throws Exception {
        MachineAssign S0 = new MachineAssign();
        S0.Assigning(constructionSolution);  // intial solution      
        pop_make.add(S0.makespan);    // objective of intial sol
        int noImprovementIterations = 0;        // Initialize the number of iterations without improvement to 0
        // Repeat until the max number of iterations is reached or there has no improvement
        for (int i = 0; i < MAX_ITERATION && noImprovementIterations<NO_IMPROVEMENT_LIMIT; i++) {
            // Generate a list of all possible Neighbours 
         int rand1 = 0;
                    int rand2 = 0;
                    do {

                        rand1 = getRandomNumberInRange(0, GraphSimulation.noftasks - 1);
                        rand2 = getRandomNumberInRange(0, GraphSimulation.noftasks - 1);

                    } while (rand1 == rand2 || (!(GraphSimulation.level[rand1] == GraphSimulation.level[rand2])));

                    int temp2 = constructionSolution[rand1];
                    constructionSolution[rand1] = constructionSolution[rand2];
                    constructionSolution[rand2] = temp2;

                    S1 = new MachineAssign();
                    S1.Assigning(constructionSolution);                   
                    pop_make.add(S1.makespan);
                      pop_make.add(S1.makespan);
                   //  System.out.println(+S1.makespan + "\t" + S1.flowtime);

              

            // fill tabuList and Update the best solution and best cost if the current solution is better 
            double d = S0.makespan - S1.makespan;
            if (!TabuList.contains(S1.makespan) && d > 0) {
                   S0.makespan = S1.makespan;
                   TabuList.add(constructionSolution);
                   pop_make.add(S0.makespan);
                noImprovementIterations = 0;              
            } else {
                 noImprovementIterations++;
            }



            // If the tabu list is full, remove the oldest element
            if (TabuList.size() > TABU_LIST_MAX_LENGTH) {                
                TabuList.remove(0);
            }
        }
                 
   
                bestMake = pop_make.get(0);
            for (int i = 1; i < pop_make.size(); i++) {
            if (bestMake > pop_make.get(i)) {
                bestMake = pop_make.get(i);
            }
        }
          
    }


    // random number generation
    public int getRandomNumberInRange(int min, int max) {
        if (min >= max) {
            throw new IllegalArgumentException("max must be greater than min");
        }
        Random r = new Random();
        return r.nextInt((max - min) + 1) + min;
    }


    public static void main(String[] args) {
     for(int j=0;j<=20;j++){
//          int avgRunTime = 0;
//          int avgMake = 0;
//          long totalTime = 0;
        ArrayList<Double> bestMake = new ArrayList<>();
        // long startTime = System.currentTimeMillis();
        int noRuns = 20;
        try {
            for (int i = 0; i < noRuns; i++) {
               // System.out.println("run: #" + (i + 1) + " processing...");
//                long startTime = System.currentTimeMillis();
                TabuSearch cp = new TabuSearch();
                
               
                 int[] input = new GraphUtils().random_population().clone();
                 // int[] input = new GraphUtils().Bottom_Descending().clone();
//                int[] input = new GraphUtils().Top_Ascending().clone();
//                int[] input = new GraphUtils().CriticalPath_Descending().clone();
               cp.construct(input);
                cp.Tabu_Search();
                bestMake.add(cp.bestMake);

//                long endTime = System.currentTimeMillis();
//                long time = endTime - startTime;
//                totalTime += time;
//                System.out.print(  totalTime+"\t");
              //  System.out.println("run: #" + (i + 1) + " processing done");
            }
        } catch (Exception e) {
            e.printStackTrace();
        }

        System.out.println(bestMake + "\t");
        double sumOfBestMake = 0;
        for (double d : bestMake) {
            sumOfBestMake += d;
        }
        double avgBestMake = sumOfBestMake / noRuns;
        System.out.println("Avg Best Make\t:: " + avgBestMake);
        System.out.println("Min Best Make\t:: " + bestMake.get(ArrayUtils.getIndexOfMinimum(bestMake)));
        System.out.println("Max Best Make\t:: " + bestMake.get(ArrayUtils.getIndexOfMaximum(bestMake)));
        //  avgRunTime = (int) (totalTime / 30);
        //  System.out.println("Avg Running Time \t:: " + avgRunTime);

    }

     }
}