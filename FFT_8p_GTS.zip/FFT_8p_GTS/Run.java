package FFT_8p_GTS;



import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

public class Run {

    public static void main(String[] args) throws IOException {
        // Specify the file path
        String paretofile = "New/8P_Paretofront-FFT-10CCR-GTS-MOEAD.txt";
        String allRunsfile = "New/8P_allruns-FFT-10CCR-GTS-MOEAD.txt";
        String MetricsFile = "New/8P_Metrics-FFT-10CCR-GTS-MOEAD.txt";
        String optimalfile="./output/8pFFT/data/optimal_FFT_10.txt";
        ArrayList<Double> HV = new ArrayList<>();
        ArrayList<Double> GD = new ArrayList<>();
        ArrayList<Double> invGD = new ArrayList<>();
        int noRuns = 20;
        int N = 100;  // population size
        int neighborSize = 10; // neighbour size of population
        MOEAD b = new MOEAD();
        MachineAssign MO = new MachineAssign();
        ArrayList<ArrayList<ParetoSolution>> allRuns = new ArrayList<>();
      
        
        int avgRunTime = 0;
        long totalTime = 0;
 
        for (int run = 0; run < noRuns; run++) {
      long startTime = System.currentTimeMillis();
            // 1.1 initialization for population
            b.initialization(MO);
            b.generatePopulationWeights(); // generate weights for population solutions
            //        System.out.println("\n * Initial Population: ");
            //        for (Solution s : b.population) {
            //            System.out.println(s.toString());
            //        }
            //        System.out.println("------------------------------------------------\n\n");
            int[][] allNeighbors = MOEAD.findAllNeighbors(N, neighborSize);
            int iteration = 0;
            do {
                // 11.2 randomly  selection two solutions from all  population
                b.selection();

                // 1.2 by generating a random number for Probability less than 0.7 applying cross over on the two selected solution
                // maximum crossover probabilities
                double maxCrossoverProbability = 0.7;
                // Randomly generate crossover probability within the range [0, maxCrossoverProbability)
                double Pc = Math.random() * maxCrossoverProbability;
                b.crossOver(Pc);

                // 1.2 by generating a random number for Probability less than 0.3 applying mutation on the solutions Crossed over in step 1.2
                // Minimum and maximum mutation probabilities
                double minMutationProbability = 0.1;
                double maxMutationProbability = 0.3;
                // Randomly generate mutation probability within the specified range
                double Pm = minMutationProbability + (maxMutationProbability - minMutationProbability) * Math.random();
                b.mutation(MO, Pm);

                if (b.first.isValid && b.second.isValid) {
                    try {
                        // comparing the best one from mutation with the neighbour size of its iteration and then update the population
                        Solution bestMutatedSolution;
                        // select best mutated solution
                        if (b.first.getMOF() < b.second.getMOF()) {
                            bestMutatedSolution = b.first.clone();
                        } else {
                            bestMutatedSolution = b.second.clone();
                        }
                        b.compareAndSwapIfMinimized(bestMutatedSolution, allNeighbors, iteration);
                    } catch (Exception e) {
                        // System.out.println("iteration#" + iteration + ": System can't compare unassigned solutions");
                        //TODO: [Aplaa] if you want to retry just comment the above print statement and uncomment the following
                        // System.out.println("iteration#" + iteration + ": System can't compare unassigned solutions, retrying again ...");
                        // continue;
                    }
                } else {
                    //  System.out.println("iteration#" + iteration + ": Sorry, maybe one of both solution isn't valid");
                    //TODO: [Aplaa] same here, if you want to retry just comment the above print statement and uncomment the following
                    // System.out.println("iteration#" + iteration + ": Sorry, maybe one of both solution isn't valid, retrying again ...");
                    // continue;
                }
                iteration++;

            } while (iteration < 100);
            //   System.out.println("=================================================\n\n");
            //   System.out.println("\n * final Population: ");

                   

   //////////////////////// Calculate   Hyper Volume /////////////////////////
    List<ParetoSolution> Optimal = EfficientOptimalSet.readParetoSolutionsFromFile(optimalfile);
            //////////////////////// Calculate   Hyper Volume /////////////////////////

            double[][] paretoFront = b.getMakeSpanUtilization(b.population);
            List<ParetoSolution> paretoFrontList = ParetoSolution.getMakeSpanUtilization(b.population); // Check [Aplaa]

            // Set reference point for hyperVolume calculation
            double[] referencePoint = HypervolumeCalculator.calculateReferencePoint(Optimal);
            //  System.out.println("Reference Point: " + Arrays.toString(referencePoint));
            double hyperVolume = HypervolumeCalculator.calculateHypervolume(paretoFront, referencePoint);
             // System.out.println("Hyper Volume: " + hyperVolume ); 
            HV.add(hyperVolume);

            ///////////////////Calculate   GD /////////////////////////

          

            // Find all optimal solutions           
            double generationalDistance = GenerationalDistanceCalculator.calculateGenerationalDistance(paretoFrontList, Optimal);
            GD.add(generationalDistance);
          //  System.out.println("Generational Distance: " + generationalDistance);

        
        
        // Inverted Generational Distance

        double invgenerationalDistance = IGD.calculateIGDPlus(Optimal,paretoFrontList);
            invGD.add(invgenerationalDistance);
            
            
            ////////////////// run time 
             long endTime = System.currentTimeMillis();
            long time = endTime - startTime;
            totalTime += time;
           // System.out.print( totalTime +"\t");
                          System.out.println("Run Number  :" +run );

        }
        
////////////////    Standard Deviation of Hyper Volume ///////////////////
            double sumOfhypervolume = 0;
            for (double d : HV) {
                sumOfhypervolume += d;
            }
            double avghypervolume = sumOfhypervolume / noRuns;

            // Step 2: Calculate the squared differences
            ArrayList<Double> squaredDifferences = new ArrayList<>();
            for (double num : HV) {
                double difference = num - avghypervolume;
                squaredDifferences.add(difference * difference);
            }

            // Step 3: Calculate the mean of squared differences
            double squaredDifferencesSum = 0.0;
            for (double squaredDifference : squaredDifferences) {
                squaredDifferencesSum += squaredDifference;
            }
            double meanSquaredDifferences = squaredDifferencesSum / HV.size();

            // Step 4: Take the square root to get the standard deviation
            double standardDeviation = Math.sqrt(meanSquaredDifferences);
        
           
 
    
////////////////    Standard Deviation of Generational Distance ///////////////////

       double sumOfGD = 0;
            for (double G : GD) {
                sumOfGD += G;
            }
            double avgGD = sumOfGD / noRuns;

            // Step 2: Calculate the squared differences
            ArrayList<Double> squaredDifferencesGD = new ArrayList<>();
            for (double n : GD) {
                double differenceGD = n - avgGD;
                squaredDifferencesGD.add(differenceGD * differenceGD);
            }

            // Step 3: Calculate the mean of squared differences
            double squaredDifferencesSumGD = 0.0;
            for (double squaredDifferenceGD : squaredDifferencesGD) {
                squaredDifferencesSumGD += squaredDifferenceGD;
            }
            double meanSquaredDifferencesGD = squaredDifferencesSumGD / GD.size();

            // Step 4: Take the square root to get the standard deviation
            double standardDeviationGD = Math.sqrt(meanSquaredDifferencesGD);
            
      ///////////////////////   inverted Generational Distance ////////////////////////////////
 double sumOfinvGD = 0;
            for (double G : invGD) {
                sumOfinvGD += G;
            }
            double avginvGD = sumOfinvGD / noRuns;

            // Step 2: Calculate the squared differences
            ArrayList<Double> squaredDifferencesinvGD = new ArrayList<>();
            for (double n : GD) {
                double differenceinvGD = n - avginvGD;
                squaredDifferencesinvGD.add(differenceinvGD * differenceinvGD);
            }

            // Step 3: Calculate the mean of squared differences
            double squaredDifferencesSuminvGD = 0.0;
            for (double squaredDifferenceinvGD : squaredDifferencesinvGD) {
                squaredDifferencesSuminvGD += squaredDifferenceinvGD;
            }
            double meanSquaredDifferencesinvGD = squaredDifferencesSuminvGD / invGD.size();

            // Step 4: Take the square root to get the standard deviation
            double standardDeviationinvGD = Math.sqrt(meanSquaredDifferencesinvGD);
      
 
  ////////////////////////   out pup //////////////////////////////////////////  
ArrayList<ParetoSolution> paretoSolutions = new ArrayList<>();
   for (Solution s : b.population) {
         paretoSolutions.add(new ParetoSolution(s.makeSpan, s.resourceUtilization));
            }
            allRuns.add(paretoSolutions);
            FileIOUtils.writeToFile(allRuns,allRunsfile, false);
           ArrayList<ParetoSolution> allRunsOutput = FileIOUtils.readFromFile(allRunsfile);
           List<ParetoSolution> nonDominatedSolutions = Filter.filterNonDominated(allRunsOutput);
//            // save [nonDominatedSolutions] into file
           FileIOUtils.writeNonDominatedSolutionsToFile(nonDominatedSolutions, paretofile);

  




// hyper volume           
System.out.println("Avg hyper volume ::" + avghypervolume + " \t Standard Diviation ::" + standardDeviation);
// GD
System.out.println("Avg Generational Distance ::" + avgGD + " \t Standard Diviation of GD ::" + standardDeviationGD);

// IGD
System.out.println("Avg invGenerational Distance ::" + avginvGD + " \t Standard Diviation of invGD ::" + standardDeviationinvGD);

  avgRunTime = (int) (totalTime / 20);
        System.out.println("Avg Running Time \t:: " + avgRunTime);   

          try (FileWriter writer = new FileWriter(MetricsFile)) {
            writer.write("Average Hypervolume: " + avghypervolume+ "\n");
            writer.write("Standard Deviation Hypervolume: " + standardDeviation + "\n");
            writer.write("Average Generational Distance: " + avgGD + "\n");
            writer.write("Standard Deviation Generational Distance: " + standardDeviationGD+ "\n");
            writer.write("Average Inverted Generational Distance: " + avginvGD + "\n");
            writer.write("Standard Deviation Inverted Generational Distance: " + standardDeviationinvGD + "\n");
            writer.write("Average Run Time: " + avgRunTime + " ms\n");
       

        
}

        
    }

    public static void saveListDataToFile(ArrayList<Solution> dataList, String filePath) {
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(filePath))) {
            for (Solution data : dataList) {
                writer.write(data.toString());
                writer.newLine(); // Add a newline for each item in the list
            }
            //  System.out.println("List of data saved to file.");
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public static void appendDoubleValueToFile(double value, String filePath) {
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(filePath, true))) {
            writer.write(String.valueOf(value));
            writer.newLine(); // Add a newline for the new value
            //  System.out.println("Additional double value added to the file.");
        } catch (IOException e) {
            e.printStackTrace();
        }
    }


}
