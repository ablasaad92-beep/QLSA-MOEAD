package FFT_8p_GTS;


import java.io.*;
import java.nio.file.FileSystems;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;

/**
 * Utility class for reading from and writing to files related to Pareto solutions.
 *
 * @author Eng.Aplaa Saad
 */
public class FileIOUtils {

    /**
     * Writes ArrayList<ArrayList<ParetoSolution>> data to a CSV file in append mode.
     *
     * @param data         The data to be written.
     * @param fileName     The name of the CSV file.
     * @param appendToFile Flag indicating whether to append to an existing file or create a new one.
     */
    static void writeToFile(ArrayList<ArrayList<ParetoSolution>> data, String fileName, boolean appendToFile) {
        try {
            // Create parent directories if they don't exist
            Path parentDir = FileSystems.getDefault().getPath(fileName).getParent();
            if (parentDir != null && !Files.exists(parentDir)) {
                Files.createDirectories(parentDir);
            }

            try (BufferedWriter writer = new BufferedWriter(new FileWriter(fileName, appendToFile))) {
                for (ArrayList<ParetoSolution> run : data) {
                    for (ParetoSolution solution : run) {
                        solution.writeToFile(writer); // Write each ParetoSolution
                    }
                }

                System.out.println("Data appended to file: " + fileName);
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    /**
     * Reads ArrayList<ParetoSolution> data from a CSV file.
     *
     * @param fileName The name of the CSV file.
     * @return The read data as a list of ParetoSolutions.
     */
    static ArrayList<ParetoSolution> readFromFile(String fileName) {
        ArrayList<ParetoSolution> data = new ArrayList<>();

        try (BufferedReader reader = new BufferedReader(new FileReader(fileName))) {
            String line;
            while ((line = reader.readLine()) != null) {
                ArrayList<ParetoSolution> run = new ArrayList<>();
                String[] values = line.split(",");

                for (int i = 0; i < values.length; i += 2) {
                    double minimize = Double.parseDouble(values[i]);
                    double maximize = Double.parseDouble(values[i + 1]);
                    run.add(new ParetoSolution(minimize, maximize));
                }

                data.addAll(run);
            }

            System.out.println("Data read from file: " + fileName);
        } catch (IOException e) {
            e.printStackTrace();
        }

        return data;
    }

    /**
     * Writes non-dominated solutions to a file.
     *
     * @param nonDominatedSolutions The list of non-dominated Pareto solutions.
     * @param filePath              The path of the file to write to.
     */
    static void writeNonDominatedSolutionsToFile(List<ParetoSolution> nonDominatedSolutions, String filePath) {
        _writeNonDominatedSolutionsToFile(nonDominatedSolutions, filePath, false);
    }

    /**
     * Writes non-dominated solutions to a file with an option to append.
     *
     * @param nonDominatedSolutions The list of non-dominated Pareto solutions.
     * @param filePath              The path of the file to write to.
     * @param append                Flag indicating whether to append to an existing file or create a new one.
     */
    static void writeNonDominatedSolutionsToFile(List<ParetoSolution> nonDominatedSolutions, String filePath, boolean append) {
        _writeNonDominatedSolutionsToFile(nonDominatedSolutions, filePath, append);
    }

    /**
     * Private helper method to write non-dominated solutions to a file.
     *
     * @param nonDominatedSolutions The list of non-dominated Pareto solutions.
     * @param filePath              The path of the file to write to.
     * @param append                Flag indicating whether to append to an existing file or create a new one.
     */
    private static void _writeNonDominatedSolutionsToFile(List<ParetoSolution> nonDominatedSolutions, String filePath, boolean append) {
        try {
            // Create parent directories if they don't exist
            Path parentDir = FileSystems.getDefault().getPath(filePath).getParent();
            if (parentDir != null && !Files.exists(parentDir)) {
                Files.createDirectories(parentDir);
            }

            // Create a FileWriter in append mode and PrintWriter to write to the file
            FileWriter fileWriter = new FileWriter(filePath, append);
            PrintWriter printWriter = new PrintWriter(fileWriter);

            // Append non-dominated solutions to the file
            for (ParetoSolution solution : nonDominatedSolutions) {
                printWriter.println(solution.minimizeObjective + "\t" + solution.maximizeObjective);
            }

            // Close the PrintWriter and FileWriter
            printWriter.close();
            fileWriter.close();

            // System.out.println("Non-dominated solutions written to the file: " + filePath);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
