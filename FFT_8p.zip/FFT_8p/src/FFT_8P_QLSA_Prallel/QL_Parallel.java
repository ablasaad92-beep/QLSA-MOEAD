package FFT_8P_QLSA_Prallel;


import java.util.*;
import java.util.concurrent.*;

public class QL_Parallel {

    static int episodes = 300;  
    static double alpha = 0.5;
    static double gamma = 0.9;
    static double epsilon = 1.0;
    static double minEpsilon = 0.01;
    static double decayRate = 0.995;

    static Map<Integer, double[]> Q = new ConcurrentHashMap<>(); // thread-safe Q-table
    static List<Integer> bestSchedule = Collections.synchronizedList(new ArrayList<>());
    static double bestMakespan = Double.MAX_VALUE;

    static final Random rand = new Random();

    public static void main(String[] args) throws InterruptedException {
        long start = System.currentTimeMillis();
        learnScheduleParallel();
        long end = System.currentTimeMillis();

        System.out.println("\n⏱️ Total Parallel Execution Time: " + (end - start) + " ms");
        System.out.println("\n✅ Best Makespan Achieved: " + bestMakespan);
        for (int i = 0; i < bestSchedule.size(); i++) {
            System.out.println("Task " + bestSchedule.get(i));
        }
    }

    /** Parallel learning process **/
    public static void learnScheduleParallel() throws InterruptedException {
        int numThreads = Runtime.getRuntime().availableProcessors();
        ExecutorService executor = Executors.newFixedThreadPool(numThreads);

        for (int ep = 0; ep < episodes; ep++) {
            executor.execute(() -> runEpisode());
        }

        executor.shutdown();
        executor.awaitTermination(Long.MAX_VALUE, TimeUnit.NANOSECONDS);
        System.out.println("\n✅ All episodes completed in parallel.");
    }

    /** Core Q-learning episode **/
    public static void runEpisode() {
        MA localMachine = new MA();  
        GraphSimulation localGraph = new GraphSimulation();

        localMachine.resetMachine();
        localMachine.calculateCost();
        localMachine.calculateAveCost();

        List<Integer> schedule = new ArrayList<>();
        Set<Integer> availableTasks = new HashSet<>();

        for (int i = 0; i < GraphSimulation.noftasks; i++) {
            if (localGraph.check_Start(i)) {
                availableTasks.add(i);
            }
        }

        int taskIndex = 0;
        while (schedule.size() < GraphSimulation.noftasks) {
            int stateKey = taskIndex * 1000 + schedule.hashCode();
            Q.putIfAbsent(stateKey, new double[GraphSimulation.noftasks]);

            int selectedTask = (rand.nextDouble() < epsilon)
                    ? getRandomTask(availableTasks)
                    : getBestTask(stateKey, availableTasks);

            int bestProcessor = getBestProcessor(localMachine, schedule.size(), selectedTask);

            schedule.add(selectedTask);
            availableTasks.remove(selectedTask);
            localMachine.assignTask(taskIndex, selectedTask, bestProcessor);

            for (int i = 0; i < GraphSimulation.noftasks; i++) {
                if (!schedule.contains(i)) {
                    int[][] preds = localGraph.predecessor(i);
                    boolean allDone = true;
                    for (int j = 0; j < preds[1].length; j++) {
                        if (!schedule.contains(preds[1][j])) {
                            allDone = false;
                            break;
                        }
                    }
                    if (allDone) availableTasks.add(i);
                }
            }

            double finalMake = localMachine.evaluateSchedule(schedule);
            double reward = -finalMake;
            double oldQ = Q.get(stateKey)[selectedTask];
            double maxNextQ = 0.0;

            if (schedule.size() < GraphSimulation.noftasks) {
                int nextStateKey = (taskIndex + 1) * 1000 + schedule.hashCode();
                Q.putIfAbsent(nextStateKey, new double[GraphSimulation.noftasks]);
                maxNextQ = Arrays.stream(Q.get(nextStateKey)).max().orElse(0.0);
            }

            synchronized (Q) {
                Q.get(stateKey)[selectedTask] = oldQ + alpha * (reward + gamma * maxNextQ - oldQ);
            }

            taskIndex++;
        }

        double finalMake = localMachine.evaluateSchedule(schedule);
        synchronized (QL_Parallel.class) {
            if (finalMake < bestMakespan) {
                bestMakespan = finalMake;
                bestSchedule = new ArrayList<>(schedule);
            }
        }

        if (epsilon > minEpsilon)
            epsilon = Math.max(minEpsilon, epsilon * decayRate);
    }

    static int getRandomTask(Set<Integer> tasks) {
        int i = rand.nextInt(tasks.size());
        return new ArrayList<>(tasks).get(i);
    }

    static int getBestTask(int stateKey, Set<Integer> tasks) {
        double[] qValues = Q.get(stateKey);
        return tasks.stream()
                .max(Comparator.comparingDouble(t -> qValues[t]))
                .orElseGet(() -> getRandomTask(tasks));
    }

    static int getBestProcessor(MA machine, int taskIndex, int task) {
        int bestProcessor = 0;
        double bestTime = Double.MAX_VALUE;
        for (int p = 0; p < MA.nofprocessors; p++) {
            int est = machine.calculateEST(taskIndex, p);
            double ast = Math.max(est, taskIndex == 0 ? 0 : machine.avail[taskIndex - 1][p]);
            double eft = ast + machine.cost[task][p];
            if (eft < bestTime) {
                bestTime = eft;
                bestProcessor = p;
            }
        }
        return bestProcessor;
    }
}
