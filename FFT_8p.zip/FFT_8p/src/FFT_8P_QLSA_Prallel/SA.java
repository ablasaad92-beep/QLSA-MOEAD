/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package FFT_8P_QLSA_Prallel;



import java.util.ArrayList;
import java.util.HashSet;
import java.util.Random;
import java.util.Set;

/**
 *
 * @author Aplaa Saad
 */
public class SA {

    int cl[];
    public ArrayList tempRCL;
    public int RCL[];
    public int[] FinalRCL;
    public int[] randomRCL;
    public int randomNum = -1;
    public double alpha = 0.3;
    public double beta = 0.7;
    int[] bestSol;
   double bestMake;
    int constructionSolution[];
    GraphSimulation obj = new GraphSimulation();
    MachineAssign sa;
    MachineAssign a;
    int makespan;
    MachineAssign S1;
    ArrayList<Double> probability;
    Set<int[]> solution;
    ArrayList<int[]> options;
    ArrayList<int[]> population;
    ArrayList<Double> pop_make;

    public SA() {
        cl = new int[GraphSimulation.noftasks];
        constructionSolution = new int[GraphSimulation.noftasks];
        probability = new ArrayList<>();
        solution = new HashSet<>();
        options = new ArrayList<>();
        bestSol = new int[GraphSimulation.noftasks];

        population = new ArrayList();
        pop_make = new ArrayList();
    }

    
    // Validate Any Schedule
    public boolean validateConstruction() {
        boolean valid = true;
        for (int i = 0; i < constructionSolution.length; i++) {
            for (int ii = i + 1; ii < constructionSolution.length; ii++) {
                if ((GraphSimulation.level[constructionSolution[i]] > GraphSimulation.level[constructionSolution[ii]])) {
                    valid = false;
                    break;
                }
            }
        }

        return valid;
    }
    //_________________local Search with Simulated Annealing_________________//
    public void SearchSimulated() {
     
        // 1.. solution S0 with make span F(S0)
        MachineAssign S0 = new  MachineAssign();
         GraphUtils obj= new GraphUtils();
       
        S0.Assigning(obj.random_population());
        population.add(obj.random_population());
        pop_make.add(S0.makespan);
        //System.out.println(+S0.makespan + "\t" + S0.flowtime);
        
         // 2.. temperature
        int T = 200;  // temperature
        double r=0.99,delta = 0.01; // small value
      while(T>delta){
          if (T > delta) {
        // 3.. generate solution S0 with make span F(S0)
//                for (int ii = GraphSimulation.noftasks - 1; ii >= GraphSimulation.noftasks - 2; ii--) {
//
//            int temp = 0;
//            if (GraphSimulation.level[obj.random_population()[ii]] >= GraphSimulation.level[obj.random_population()[ii - 1]]) {
//                temp = obj.random_population()[ii];
//              obj.random_population()[ii] = obj.random_population()[ii - 1];
//                obj.random_population()[ii - 1] = temp;
//            }}
//            // new solution S1 with make span F(S1)
//            S1 = new MachineAssign();
//            S1.Assigning(obj.random_population());
//            population.add(obj.random_population());
//            pop_make.add(S1.makespan);
         //   System.out.println(+S1.makespan + "\t" + S1.flowtime);
                
            double R = Math.random();
            if (R <= 0.49) {
                int rand1 = 0;
                int rand2 = 0;
                do {

                    rand1 = getRandomNumberInRange(0, GraphSimulation.noftasks - 1);
                    rand2 = getRandomNumberInRange(0, GraphSimulation.noftasks - 1);

                } while (rand1 == rand2 || (!(GraphSimulation.level[rand1] == GraphSimulation.level[rand2])));

                int temp2 = obj.random_population()[rand1];
                obj.random_population()[rand1] =obj.random_population()[rand2];
               obj.random_population()[rand2] = temp2;

                S1 = new MachineAssign();
                S1.Assigning(obj.random_population());
                population.add(obj.random_population());
                pop_make.add(S1.makespan);
                //  pop_make.add(S1.makespan);
               // System.out.println(+S1.makespan + "\t" + S1.flowtime);

            } else {
                int rand1 = 0;
                int rand2 = 0;

                do {

                    rand1 = getRandomNumberInRange(0, GraphSimulation.noftasks - 1);
                    rand2 = getRandomNumberInRange(0, GraphSimulation.noftasks - 1);

                } while (rand1 == rand2 || (!(GraphSimulation.level[rand1] == GraphSimulation.level[rand2])));

                int temp2 = obj.random_population()[rand1];
                obj.random_population()[rand1] = obj.random_population()[rand2];
                obj.random_population()[rand2] = temp2;

                S1 = new MachineAssign();
                S1.Assigning(obj.random_population());
                population.add(obj.random_population());
                pop_make.add(S1.makespan);
                         //   System.out.println(+S1.makespan + "\t" + S1.flowtime);

            }
            
        
        // calculate acceptance probability
        double d = S0.makespan - S1.makespan;
        double RR = Math.random();
        if (d > 0) {
            S0.makespan = S1.makespan;
            population.add(obj.random_population());
            pop_make.add(S0.makespan);
            //   pop_make.add(S0.makespan);
          
          // System.out.println(+S0.makespan + "\t" + S0.flowtime);
            T = (int) (T*r);
          // System.out.println(T + "\t" );
                
        } else if (RR < Math.exp(d / T)) {
                S0.makespan = S1.makespan;
                population.add(obj.random_population());
                pop_make.add(S0.makespan);
                // pop_make.add(S0.makespan);
              
              //  System.out.println(+S0.makespan + "\t" + S0.flowtime);
               T = (int) (T*r);
               //System.out.println(T + "\t" );
            } 
        else {
                  T = (int) (T*r);
              //    System.out.println(T + "\t" );
            }
            T = T-1;
           //  System.out.println(T + "\t" );
        // temp decrease
      }
        

       
         else {

            S0.Assigning(obj.random_population());
            population.add(obj.random_population());
            pop_make.add(S0.makespan);
           
        //  System.out.println(+S0.makespan + "\t" + S0.flowtime);
        
        }
      }
        
        bestMake = pop_make.get(0);
        for (int i = 1; i < pop_make.size(); i++) {
            if (bestMake > pop_make.get(i)) {
                bestMake = pop_make.get(i);
            }
        }

//                   for (int ii=0;ii<population.size();ii++){
//                   for (int x :constructionSolution){
//         
//                    System.out.print(" T" + x+ "  ");
//                   }
//                Assign s = new Assign();
//           s.GRA(constructionSolution);
//           System.out.println(+s.makespan + "\t" + s.flowtime);
//            }
//     if (S1.makespan > S0.makespan) {
//                bestSol =  constructionSolution.clone();
//                bestMake = S0.makespan;
//                 System.out.println("    make: " + bestMake );
//               
//          
//    }}
//         if (bestMake > S0.makespan) {
//                bestSol = constructionSolution.clone();
//                bestMake = S0.makespan;
//             System.out.println(+bestMake + "\t");
//             
//                
//            } else if (bestMake > S1.makespan) {
//                bestSol = constructionSolution.clone();
//                bestMake = S1.makespan;
//                  System.out.println(+bestMake + "\t");
//            }
    }
// random number generation

    public int getRandomNumberInRange(int min, int max) {
        if (min >= max) {
            throw new IllegalArgumentException("max must be greater than min");
        }
        Random r = new Random();
        return r.nextInt((max - min) + 1) + min;
    }

    public static void main(String[] args) {
       // for(int j=0;j<=30;j++){
        int avgRunTime = 0;
        long totalTime = 0;
         int avgMake = 0;
        ArrayList<Double> bestMake = new ArrayList<>();
        // long startTime = System.currentTimeMillis();
        for (int i = 0; i < 20; i++) {
            long startTime = System.currentTimeMillis();
            SA cp = new SA();

            
            cp.SearchSimulated();
            bestMake.add(cp.bestMake);

//             for (int j = 0; j < cp.bestSol.length; j++) {
//                if (j < DAG.noftasks) {
//                    System.out.print("T" + cp.bestSol[i] + "  ");
//                } else {
//                    System.out.print("P" + cp.bestSol[i] + "  ");
//                }
//            }
//            System.out.println("    make: " + cp.bestMake );
//           
//            avgMake += cp.bestMake;
//
//        
//        
//        avgMake /= 30;
            // System.out.println("\033[36maverage make: " + avgMake );
            //System.out.print("\033[36m  ");
          //  System.out.println("----------------------------------------" + "Iteration " + i);
            long endTime = System.currentTimeMillis();
            long time = endTime - startTime;
            totalTime += time;
          //  System.out.print( totalTime +"\t");
                    
        }
     
       System.out.print(bestMake+"\t");
        double sumOfBestMake = 0;
        for (double d : bestMake) {
            sumOfBestMake += d;
        }
       double avgBestMake = sumOfBestMake / 20;
        System.out.println("Avg Best Make\t:: " + avgBestMake);
        //avgRunTime = (int) (totalTime / 20);
      // System.out.println("Avg Running Time \t:: " + avgRunTime);

    }
}
//}
