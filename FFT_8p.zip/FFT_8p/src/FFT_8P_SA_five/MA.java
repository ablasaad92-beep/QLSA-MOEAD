package FFT_8P_SA_five;

import java.util.*;
import java.util.concurrent.ThreadLocalRandom;

public class MA {
    public static int nofprocessors = 8;
    public int[] execution_order;
    public int[] processor_num;
    public double[][] cost, est, ast, eft, avail;
    public double[] aveCost, aft;
    GraphSimulation xx = new GraphSimulation();

    public MA() {
        resetMachine();
    }

    public void resetMachine() {
        execution_order = new int[GraphSimulation.noftasks];
        processor_num = new int[GraphSimulation.noftasks];
        cost = new double[GraphSimulation.noftasks][nofprocessors];
        est = new double[GraphSimulation.noftasks][nofprocessors];
        ast = new double[GraphSimulation.noftasks][nofprocessors];
        eft = new double[GraphSimulation.noftasks][nofprocessors];
        aft = new double[GraphSimulation.noftasks];
        avail = new double[GraphSimulation.noftasks][nofprocessors];
        aveCost = new double[GraphSimulation.noftasks];
        xx.fill_Communication();
    }

    public void calculateCost() {
        for (int i = 0; i < GraphSimulation.noftasks; i++) {
            for (int j = 0; j < nofprocessors; j++) {
               // cost[i][j] = ThreadLocalRandom.current().nextDouble(5, 30);
               //  cost[i][j] = ThreadLocalRandom.current().nextDouble(10, 20);
                  cost[i][j] = ThreadLocalRandom.current().nextDouble(10, 20);
                //   cost[i][j] = ThreadLocalRandom.current().nextDouble(5, 10);
 
            }
        }
    }

    public void calculateAveCost() {
        for (int i = 0; i < GraphSimulation.noftasks; i++) {
            double sum = 0;
            for (int j = 0; j < nofprocessors; j++) {
                sum += cost[i][j];
            }
            aveCost[i] = sum / nofprocessors;
        }
    }

   public int calculateEST(int taskIndex, int processorIndex) {
    int taskId = execution_order[taskIndex];

    if (xx.check_Start(taskId)) return 0;

    int[][] preds = xx.predecessor(taskId);
    double[] times = new double[preds[0].length];

    for (int i = 0; i < preds[0].length; i++) {
        int predTask = preds[1][i];
        int predIndex = getTaskIndex(predTask);

        if (predIndex == -1) {
            System.err.println("❌ [calculateEST] Skipping unknown predecessor task " + predTask + " (not found in execution_order)");
            times[i] = 0;  // تجاهل التأثير
            continue;
        }

        if (processor_num[predIndex] == processorIndex) {
            times[i] = aft[predIndex];
        } else {
            times[i] = aft[predIndex] + xx.communication[preds[0][i]];
        }
    }

    return (int) Arrays.stream(times).max().orElse(0.0);
}

    public double calculateAST(int taskIndex, int processorIndex) {
        if (xx.check_Start(execution_order[taskIndex])) return est[taskIndex][processorIndex];
        return Math.max(est[taskIndex][processorIndex], avail[Math.max(0, taskIndex - 1)][processorIndex]);
    }

    public double calculateEFT(int taskIndex, int processorIndex) {
        return ast[taskIndex][processorIndex] + cost[execution_order[taskIndex]][processorIndex];
    }

    public void setAFT(int taskIndex, int processorIndex) {
        processor_num[taskIndex] = processorIndex;
        aft[taskIndex] = eft[taskIndex][processorIndex];
        for (int i = 0; i < nofprocessors; i++) {
            avail[taskIndex][i] = (i == processorIndex)
                    ? aft[taskIndex]
                    : (taskIndex == 0 ? 0 : avail[taskIndex - 1][i]);
        }
    }

    public void assignTask(int taskIndex, int taskId, int processor) {
        execution_order[taskIndex] = taskId;
        for (int i = 0; i < nofprocessors; i++) {
            est[taskIndex][i] = calculateEST(taskIndex, i);
            ast[taskIndex][i] = calculateAST(taskIndex, i);
            eft[taskIndex][i] = calculateEFT(taskIndex, i);
        }
        setAFT(taskIndex, processor);
    }

    public double getFinalMakespan() {
        return Arrays.stream(aft).max().orElse(0.0);
    }

private int getTaskIndex(int taskId) {
    for (int i = 0; i < execution_order.length; i++) {
        if (execution_order[i] == taskId) return i;
    }
    System.err.println("⚠️ Task ID not found in execution_order: " + taskId);
    return -1; // ⚠️ يجب التأكد من معالجة هذه القيمة
}

    public double evaluateSchedule(List<Integer> schedule) {
    resetMachine();               // إعادة تعيين الآلة بالكامل
    calculateCost();             // استخدام نفس طريقة التوليد للتكاليف
    calculateAveCost();          // حساب التكلفة المتوسطة

    for (int taskIndex = 0; taskIndex < schedule.size(); taskIndex++) {
        int taskId = schedule.get(taskIndex);
        execution_order[taskIndex] = taskId;

        for (int p = 0; p < nofprocessors; p++) {
            est[taskIndex][p] = calculateEST(taskIndex, p);
            ast[taskIndex][p] = calculateAST(taskIndex, p);
            eft[taskIndex][p] = calculateEFT(taskIndex, p);
        }

        int bestProcessor = getFittestProcessorForEFT(taskIndex);
        setAFT(taskIndex, bestProcessor);
    }

    return Arrays.stream(aft).max().orElse(0.0);  // إرجاع الـ Makespan
}
public int getFittestProcessorForEFT(int taskIndex) {
    double minEFT = Double.MAX_VALUE;
    int bestProcessor = 0;
    for (int p = 0; p < nofprocessors; p++) {
        if (eft[taskIndex][p] < minEFT) {
            minEFT = eft[taskIndex][p];
            bestProcessor = p;
        }
    }
    return bestProcessor;
}
// Objective function NO.2: Load balancing (Beta)
double calculateBeta(int nOfProcessors) {
    double beta = 0.0;
    int[] nOfJobs = new int[nOfProcessors];

    for (int processor = 0; processor < nOfProcessors; processor++) {
        int jobsCount = 0;
        for (int task = 0; task < GraphSimulation.noftasks; task++) {
            if (processor_num[task] == processor) {
                jobsCount++;
            }
        }
        nOfJobs[processor] = jobsCount;
    }

    double[] processorsCapacity = new double[nOfProcessors];
    for (int processor = 0; processor < nOfProcessors; processor++) {
        processorsCapacity[processor] = Math.abs(((double) GraphSimulation.noftasks / nOfProcessors) - nOfJobs[processor]);
    }

    double imbalanceSum = ArrayUtils.getArraySum(processorsCapacity);
    beta = (imbalanceSum == 0) ? Double.POSITIVE_INFINITY : 1.0 / imbalanceSum;

    return beta;
}

public double calculateCCR() {
    calculateCost();         // تأكد من وجود هذا السطر
    calculateAveCost();
    xx.fill_Communication();

    double computation = 0.0;
    double communication = 0.0;

    for (int p = 0; p < GraphSimulation.noftasks; p++) {
        computation += aveCost[p];
    }

    double avgComputation = computation / GraphSimulation.noftasks;

    for (int e = 0; e < GraphSimulation.nofedges; e++) {
        communication += xx.communication[e];
    }

    double avgCommunication = communication / GraphSimulation.nofedges;

    if (avgComputation == 0.0) {
        System.err.println("❌ avgComputation = 0. CCR is undefined.");
        return Double.POSITIVE_INFINITY; // اخرج من الدالة فوراً
    }

    double ccR = avgCommunication / avgComputation;
    System.out.println("✅ CCR = " + ccR);
    return ccR;
}


public static void main(String[] args) {
    MA machine = new MA();

    // احسب CCR
    double ccr = machine.calculateCCR();
    System.out.println("✅ CCR = " + ccr);

    // مثال: تعيين جدول وهمي لتجربة beta
    machine.processor_num = new int[GraphSimulation.noftasks];
    for (int i = 0; i < GraphSimulation.noftasks; i++) {
        machine.processor_num[i] = i % nofprocessors; // توزيع دائري
    }

    double beta = machine.calculateBeta(nofprocessors);
    System.out.println("✅ Beta = " + beta);
}

}
