/*
\
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package FFT_8P_SA_five;

/**
 * @author AblaSaad
 */


import java.util.Arrays;
import java.util.List;

public class HypervolumeCalculator {

    public static void main(String[] args) {
        // Example: create a list of points (objectives) for a Pareto front


        double[][] paretoFront = {
                {100, 0.3},
                {8, 0.1},
                {89, 0.7},
                {120, 0.8},

        };
         //Set reference point for hypervolume calculation
        double[] referencePoint = calculateReferencePoint(paretoFront);
        System.out.println("Reference Point: " + Arrays.toString(referencePoint));
        double hypervolume = calculateHypervolume(paretoFront, referencePoint);
        System.out.println("Hypervolume: " + hypervolume);


    }

    // Calculate the reference point for maximizing makespan and minimizing resource utilization
    public static double[] calculateReferencePoint(double[][] paretoFront) {
        double maxMakespan = Double.MIN_VALUE;
        double minResourceUtilization = Double.MAX_VALUE;

        // Find the maximum makespan and minimum resource utilization
        for (double[] solution : paretoFront) {
            maxMakespan = Math.max(maxMakespan, solution[0]);
            minResourceUtilization = Math.min(minResourceUtilization, solution[1]);
        }

        // Create the reference point
        double[] referencePoint = {maxMakespan, minResourceUtilization};

        return referencePoint;
    }

  public static double[] calculateReferencePoint(List<ParetoSolution> optimal) {
        int size = optimal.size();
        double[][] paretoFront = new double[size][2];
        for (int i = 0; i < size; i++) {
            ParetoSolution s = optimal.get(i);
            if (s != null) {
                paretoFront[i][0] = s.minimizeObjective;
                paretoFront[i][1] = s.maximizeObjective;
            }
        }

        double maxMakespan = Double.MIN_VALUE;
        double minResourceUtilization = Double.MAX_VALUE;

        // Find the maximum makespan and minimum resource utilization
        for (double[] solution : paretoFront) {
            maxMakespan = Math.max(maxMakespan, solution[0]);
            minResourceUtilization = Math.min(minResourceUtilization, solution[1]);
        }

        // Create the reference point
        double[] referencePoint = {maxMakespan, minResourceUtilization};

        return referencePoint;
    }





    public static double calculateHypervolume(double[][] paretoFront, double[] referencePoint) {
    // ترتيب الحلول بناءً على القيمة الأولى (makespan) بترتيب تنازلي
    Arrays.sort(paretoFront, (a, b) -> Double.compare(b[0], a[0]));

    double hypervolume = 0.0;
    double lastX = referencePoint[0];
    double lastY = referencePoint[1];

    // تتبع آخر قيم X و Y
    double prevX = referencePoint[0];
    double prevY = referencePoint[1];

    for (double[] solution : paretoFront) {
        double width = Math.max(0, prevX - solution[0]);  // منع القيم السالبة
        double height = Math.max(0, prevY - solution[1]);  // منع القيم السالبة
        if (width > 0 && height > 0) {
            hypervolume += width * height;
        }
        // تحديث القيم السابقة
        prevX = solution[0];
        prevY = solution[1];
    }

    // إضافة المساحة بين آخر نقطة وحافة الرسم البياني
    double finalWidth = Math.abs(prevX - lastX);
    double finalHeight = Math.abs(lastY - prevY);
    hypervolume += finalWidth * finalHeight;

    return hypervolume;
}

}