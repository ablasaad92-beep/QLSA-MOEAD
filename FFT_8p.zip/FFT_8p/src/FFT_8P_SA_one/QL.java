package FFT_8P_SA_one;

import java.util.*;

public class QL {
    static int episodes = 300;  // Reduced for faster learning
    static double alpha = 0.5;
    static double gamma = 0.9;
    static double epsilon = 1.0;
    static double minEpsilon = 0.01;
    static double decayRate = 0.995;

    static Map<Integer, double[]> Q = new HashMap<>();
    static MA machine = new MA();
    static GraphSimulation graph = new GraphSimulation();

    static List<Integer> bestSchedule = new ArrayList<>();
    static double bestMakespan = Double.MAX_VALUE;

    static final Random rand = new Random();

    public static void main(String[] args) {
         int avgRunTime = 0;
        long totalTime = 0;
         int noRuns = 20;
        for (int run = 0; run < noRuns; run++) {
        long startTime = System.currentTimeMillis();
        learnSchedule();
         long endTime = System.currentTimeMillis();
            long time = endTime - startTime;
            totalTime += time;
        }
             avgRunTime = (int) (totalTime / 20);
        System.out.println("Avg Running Time \t:: " + avgRunTime);   

    }

    public static void learnSchedule() {
        for (int ep = 0; ep < episodes; ep++) {
            machine.resetMachine();
            machine.calculateCost();
            machine.calculateAveCost();

            List<Integer> schedule = new ArrayList<>();
            Set<Integer> availableTasks = new HashSet<>();
            for (int i = 0; i < GraphSimulation.noftasks; i++) {
                if (graph.check_Start(i)) {
                    availableTasks.add(i);
                }
            }

            int taskIndex = 0;
            while (schedule.size() < GraphSimulation.noftasks) {
                int stateKey = taskIndex * 1000 + schedule.hashCode();
                Q.putIfAbsent(stateKey, new double[GraphSimulation.noftasks]);

                int selectedTask = (rand.nextDouble() < epsilon)
                        ? getRandomTask(availableTasks)
                        : getBestTask(stateKey, availableTasks);

                int bestProcessor = getBestProcessor(schedule.size(), selectedTask);

                schedule.add(selectedTask);
                availableTasks.remove(selectedTask);
                machine.assignTask(taskIndex, selectedTask, bestProcessor);

                for (int i = 0; i < GraphSimulation.noftasks; i++) {
                    if (!schedule.contains(i)) {
                        int[][] preds = graph.predecessor(i);
                        boolean allDone = true;
                        for (int j = 0; j < preds[1].length; j++) {
                            if (!schedule.contains(preds[1][j])) {
                                allDone = false;
                                break;
                            }
                        }
                        if (allDone) availableTasks.add(i);
                    }
                }

                double finalMake = machine.evaluateSchedule(schedule);
                double reward = -finalMake;
                double oldQ = Q.get(stateKey)[selectedTask];
                double maxNextQ = 0.0;

                if (schedule.size() < GraphSimulation.noftasks) {
                    int nextStateKey = (taskIndex + 1) * 1000 + schedule.hashCode();
                    Q.putIfAbsent(nextStateKey, new double[GraphSimulation.noftasks]);
                    maxNextQ = Arrays.stream(Q.get(nextStateKey)).max().orElse(0.0);
                }

                Q.get(stateKey)[selectedTask] = oldQ + alpha * (reward + gamma * maxNextQ - oldQ);
                taskIndex++;
            }

            double finalMake = machine.evaluateSchedule(schedule);
            if (finalMake < bestMakespan) {
                bestMakespan = finalMake;
                bestSchedule = new ArrayList<>(schedule);
            }

            if (epsilon > minEpsilon) epsilon = Math.max(minEpsilon, epsilon * decayRate);
        }

        System.out.println("\nBest Makespan Achieved: " + bestMakespan);
        for (int i = 0; i < bestSchedule.size(); i++) {
            System.out.println("Task " + bestSchedule.get(i) + " -> Processor " + machine.processor_num[i]);
        }
    }

    static int getRandomTask(Set<Integer> tasks) {
        int i = rand.nextInt(tasks.size());
        return new ArrayList<>(tasks).get(i);
    }

    static int getBestTask(int stateKey, Set<Integer> tasks) {
        double[] qValues = Q.get(stateKey);
        return tasks.stream()
            .max(Comparator.comparingDouble(t -> qValues[t]))
            .orElseGet(() -> getRandomTask(tasks));
    }

    static int getBestProcessor(int taskIndex, int task) {
        int bestProcessor = 0;
        double bestTime = Double.MAX_VALUE;
        for (int p = 0; p < MA.nofprocessors; p++) {
            int est = machine.calculateEST(taskIndex, p);
            double ast = Math.max(est, taskIndex == 0 ? 0 : machine.avail[taskIndex - 1][p]);
            double eft = ast + machine.cost[task][p];
            if (eft < bestTime) {
                bestTime = eft;
                bestProcessor = p;
            }
        }
        return bestProcessor;
    }

    public static double calculateReward(List<Integer> schedule) {
        return -machine.evaluateSchedule(schedule);
    }

    static boolean isTrained = false;

    public static void train() {
        if (!isTrained) {
            learnSchedule();
            isTrained = true;
        }
    }

    public static List<Integer> getBestSchedule() {
        if (bestSchedule == null || bestSchedule.size() != GraphSimulation.noftasks) {
            System.err.println("❌ Best schedule is null or incomplete.");
            return Collections.emptyList();
        }

        Set<Integer> unique = new HashSet<>(bestSchedule);
        if (unique.size() != bestSchedule.size()) {
            System.err.println("❌ Duplicate tasks detected in best schedule.");
            return Collections.emptyList();
        }

        for (int i = 0; i < bestSchedule.size(); i++) {
            int task = bestSchedule.get(i);
            int[][] preds = new GraphSimulation().predecessor(task);
            for (int j = 0; j < preds[1].length; j++) {
                int pred = preds[1][j];
                if (bestSchedule.indexOf(pred) > i) {
                    System.err.println("❌ Invalid task order: Task " + task + " precedes its predecessor " + pred);
                    return Collections.emptyList();
                }
            }
        }

        return bestSchedule;
    }
}
