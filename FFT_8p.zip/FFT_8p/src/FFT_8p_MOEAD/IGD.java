package FFT_8p_MOEAD;

import java.util.ArrayList;
import java.util.List;

public class IGD {

    public static void main(String[] args) {
        // قائمة الحلول التي تم العثور عليها (Obtained Solutions)
        List<ParetoSolution> obtainedSolutions = new ArrayList<>();
        obtainedSolutions.add(new ParetoSolution(10, 0.8));
        obtainedSolutions.add(new ParetoSolution(8, 0.9));
        obtainedSolutions.add(new ParetoSolution(12, 0.7));

        // قائمة الحلول المرجعية (Reference Pareto Front)
        List<ParetoSolution> referenceSolutions = new ArrayList<>();
        referenceSolutions.add(new ParetoSolution(9, 0.85));
        referenceSolutions.add(new ParetoSolution(11, 0.75));
        referenceSolutions.add(new ParetoSolution(7, 0.95));

        // حساب IGD+
        double igdPlus = calculateIGDPlus(referenceSolutions, obtainedSolutions);
        System.out.println("Inverted Generational Distance Plus (IGD+): " + igdPlus);
    }

    // حساب IGD+
    static double calculateIGDPlus(List<ParetoSolution> referenceSolutions, List<ParetoSolution> obtainedSolutions) {
        double sumDistances = 0.0;
        int validDistances = 0;

        for (ParetoSolution referenceSolution : referenceSolutions) {
            double minDistance = Double.MAX_VALUE;

            for (ParetoSolution obtainedSolution : obtainedSolutions) {
                double distance = directedDistance(referenceSolution, obtainedSolution);
                if (distance < minDistance) {
                    minDistance = distance;
                }
            }

            // التأكد من عدم استخدام قيم غير منطقية
            if (minDistance != Double.MAX_VALUE) {
                sumDistances += minDistance;
                validDistances++;
            }
        }

        // تجنب القسمة على صفر وإعطاء قيمة معقولة بدلاً من 1000
        return validDistances == 0 ? Double.MAX_VALUE : sumDistances / validDistances;
    }

    // حساب المسافة الموجهة لـ IGD+ مع التأكد من عدم السلبية
    private static double directedDistance(ParetoSolution reference, ParetoSolution obtained) {
        double diff1 = obtained.minimizeObjective - reference.minimizeObjective;
        double diff2 = reference.maximizeObjective - obtained.maximizeObjective;

        // استخدام Math.max(0, value) لتجنب القيم السالبة
        return Math.sqrt(Math.max(0, diff1 * diff1) + Math.max(0, diff2 * diff2));
    }
}

