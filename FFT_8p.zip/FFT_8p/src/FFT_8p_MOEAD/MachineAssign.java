package FFT_8p_MOEAD;

/**
 * @author Aplaa Saad
 */

import java.util.Arrays;
import java.util.Collections;
import java.util.Random;
import java.util.Scanner;
import java.util.concurrent.ThreadLocalRandom;

public class MachineAssign {
 Random randomGenerator = new Random();
    public static int nofprocessors; // number of processors
    private final Scanner in = new Scanner(System.in);
    public int[] execution_order;// = {1, 0, 3, 2, 6, 4, 10, 5, 9, 7, 8}
    GraphSimulation xx;
    int[] assign_processor;
    int[] processor_num;
    int[] task_executed;
    boolean[] runnigFlag;   // processors state
    double[] End_Time;
    double[] Start_Time;
    double[] Wait_Time;

    double makespan;
    int Resource_Utilization;
    int Timer = 0;
    double[][] speed;
    double[][] cost;
    double[] aveCost;

    double[][] est;
    double[][] ast;
    double[][] eft;
    double[] aft;

    double[][] avail;

    public MachineAssign() {
        xx = new GraphSimulation();
//        System.out.print("Enter number of Processors:	");
        nofprocessors = 8;//in.nextInt();
//        System.out.println("");
        execution_order = new int[GraphSimulation.noftasks];
        assign_processor = new int[GraphSimulation.noftasks];
        processor_num = new int[GraphSimulation.noftasks];
        task_executed = new int[GraphSimulation.noftasks];
        runnigFlag = new boolean[nofprocessors];
        End_Time = new double[GraphSimulation.noftasks];
        Start_Time = new double[GraphSimulation.noftasks];
        Wait_Time = new double[GraphSimulation.noftasks];
        xx.fill_Communication();

        speed = new double[GraphSimulation.noftasks][nofprocessors];
        cost = new double[GraphSimulation.noftasks][nofprocessors];
        aveCost = new double[GraphSimulation.noftasks];

        est = new double[GraphSimulation.noftasks][nofprocessors];
        ast = new double[GraphSimulation.noftasks][nofprocessors];
        eft = new double[GraphSimulation.noftasks][nofprocessors];
        aft = new double[GraphSimulation.noftasks];
        avail = new double[GraphSimulation.noftasks][nofprocessors];
    }

    public static void main(String[] args) {
        for(int r=0;r<20;r++){
        MachineAssign x = new MachineAssign();

        GraphUtils g = new GraphUtils();
      //  int[] executionOrder = new int[GraphSimulation.noftasks];
      //  int[] exectionOrder = {0, 2, 1, 5, 4, 3, 7, 9, 8, 6};
           x.calculateCost();
        x.calculateAveCost();
      //  x.Assigning(exectionOrder);
        x.CCR();
         x.Assigning(g.Bottom_Descending());
//        // x.Assigning(g.Top_Ascending());
//        // x.Assigning(g.CriticalPath_Descending());
//        System.out.println("================== est =======================");
//        for (int i = 0; i < GraphSimulation.noftasks; i++) {
//            for (int j = 0; j < nofprocessors; j++) {
//                System.out.print(x.est[i][j] + "   ");
//            }
//            System.out.println();
//        }
//
//        System.out.println("================== eft =======================");
//        for (int i = 0; i < GraphSimulation.noftasks; i++) {
//            for (int j = 0; j < nofprocessors; j++) {
//                System.out.print(x.eft[i][j] + "   ");
//            }
//            System.out.println();
//        }
//
//        System.out.println("================== avail =======================");
//        for (int i = 0; i < GraphSimulation.noftasks; i++) {
//            for (int j = 0; j < nofprocessors; j++) {
//                System.out.print(x.avail[i][j] + "   ");
//            }
//            System.out.println();
//        }
//
//        System.out.println(x.makespan);

    }
    }
    boolean isIdle() {
        return Collections.singletonList(execution_order).isEmpty();
    }

    void resetMachine() {
        execution_order = new int[GraphSimulation.noftasks];
        assign_processor = new int[GraphSimulation.noftasks];
        processor_num = new int[GraphSimulation.noftasks];
        task_executed = new int[GraphSimulation.noftasks];
        runnigFlag = new boolean[nofprocessors];
        End_Time = new double[GraphSimulation.noftasks];
        Start_Time = new double[GraphSimulation.noftasks];
        Wait_Time = new double[GraphSimulation.noftasks];
        xx.fill_Communication();

        speed = new double[GraphSimulation.noftasks][nofprocessors];
        cost = new double[GraphSimulation.noftasks][nofprocessors];
        aveCost = new double[GraphSimulation.noftasks];

        est = new double[GraphSimulation.noftasks][nofprocessors];
        ast = new double[GraphSimulation.noftasks][nofprocessors];
        eft = new double[GraphSimulation.noftasks][nofprocessors];
        aft = new double[GraphSimulation.noftasks];
        avail = new double[GraphSimulation.noftasks][nofprocessors];
    }

    // fill speed of processors
    /*  public void fill_speed() {

        for (int row = 0; row < xx.noftasks; row++) {
            for (int col = 0; col < nofprocessors; col++) {
                // Row-1
                speed[0][0] = 1;
                speed[0][1] = 0.85;
                speed[0][2] = 1.22;
                // Row-2
                speed[1][0] = 1.20;
                speed[1][1] = 0.80;
                speed[1][2] = 1.09;
                // Row-3
                speed[2][0] = 1.33;
                speed[2][1] = 1.00;
                speed[2][2] = 0.86;
                // Row-4
                speed[3][0] = 1.18;
                speed[3][1] = 0.81;
                speed[3][2] = 1.30;
                // row-5
                speed[4][0] = 1.00;
                speed[4][1] = 1.37;
                speed[4][2] = 0.79;
                // row-6
                speed[5][0] = 0.75;
                speed[5][1] = 1.00;
                speed[5][2] = 1.79;
                // row-7
                speed[6][0] = 1.30;
                speed[6][1] = 0.93;
                speed[6][2] = 1.00;
                // row-8
                speed[7][0] = 1.09;
                speed[7][1] = 0.80;
                speed[7][2] = 1.20;
            }
        }
    }
     */
    // calculate cost
    /* public void calculateCost() {

        for (int row = 0; row < GraphSimulation.noftasks; row++) {
            for (int col = 0; col < this.nofprocessors; col++) {
                cost[row][col] = xx.execution[row] / speed[row][col];
                // System.err.print("cost\t"+cost[row][col]+"\n ");

            }
        }
    }
     */
    public void calculateCost() {


  for (int row = 0; row < GraphSimulation.noftasks; row++) {
            for (int col = 0; col < this.nofprocessors; col++) {
        Random randomGenerator = new Random();
      // cost[row][col]=randomGenerator .nextInt((30 - 5) + 1) +5;
    cost[row][col]=randomGenerator .nextInt((20 - 10) + 1) +10;
    // cost[row][col]=randomGenerator .nextInt((20 - 10) + 1) +10;
     //  cost[row][col]=randomGenerator .nextInt((10 - 5) + 1) +5;  
       }
    }
    }
    public void calculateAveCost() {
      
        for (int row = 0; row < GraphSimulation.noftasks; row++) {
            double _cost = 0.0;
            for (int col = 0; col < MachineAssign.nofprocessors; col++) {
                _cost += cost[row][col];
            }
            aveCost[row] = _cost / MachineAssign.nofprocessors;
            //   System.out.println(aveCost[row]+"   ");
        }
        // System.out.println("");

    }

    // this function will return the EST value make sure you store it in est array
    int calculateEST(int taskIndex, int processorIndex) {
        // if entry task, then EST = 0
        // if all predecessors on the same processor, then maximize AFT for all predecessors.
        // if task's predessors on different processors, then maximize (AFT for all predecessors + communication time)

        if (xx.check_Start(taskIndex)) {
            return 0;
        } else {
            int[][] x = xx.predecessor(execution_order[taskIndex]);
            double[] temp = new double[x[0].length];
            for (int i = 0; i < x[1].length; i++) {
                if (processor_num[ArrayUtils.getIndex(execution_order, x[1][i])] == processorIndex) {
                    temp[i] = aft[ArrayUtils.getIndex(execution_order, x[1][i])];
                } else {
                    temp[i] = aft[ArrayUtils.getIndex(execution_order, x[1][i])] + xx.communication[x[0][i]];
                }
            }
            int _est = new Double(temp[ArrayUtils.getIndexOfMaximum(temp)]).intValue();
            return _est;
        }
    }

    // this function will return the AST value make sure you store it in ast array
    double calculateAST(int taskIndex, int processorIndex) {
        if (xx.check_Start(taskIndex)) {
            return est[taskIndex][processorIndex];
        } else {
            if (est[taskIndex][processorIndex] > avail[taskIndex - 1][processorIndex]) {
                return est[taskIndex][processorIndex];
            } else {
                return avail[taskIndex - 1][processorIndex];
            }
        }
    }

    // this function will return the EFT value make sure you store it in eft array
    double calculateEFT(int taskIndex, int processorIndex) {
        return ast[taskIndex][processorIndex] + cost[execution_order[taskIndex]][processorIndex];
    }

    // this function will return the index of fittest processor for execution
    int getFittestProcessorForAFT(int taskIndex) {
        return ArrayUtils.getIndexOfMinimum(eft[taskIndex]);
    }

    void setAFT(int taskIndex, int processorIndex) {
        processor_num[taskIndex] = processorIndex;
        aft[taskIndex] = eft[taskIndex][processorIndex];
        for (int i = 0; i < nofprocessors; i++) {
            if (i == processorIndex) {
                avail[taskIndex][i] = aft[taskIndex];
            } else {
                if (taskIndex == 0) {
                    avail[taskIndex][i] = 0;
                } else {
                    avail[taskIndex][i] = avail[taskIndex - 1][i];
                }
            }

        }
    }

    public void Assigning(int[] a) {
        //   fill_speed();
        calculateCost();
        calculateAveCost();
        execution_order = a;
        for (int task = 0; task < GraphSimulation.noftasks; task++) {
            for (int processor = 0; processor < nofprocessors; processor++) {
                est[task][processor] = calculateEST(task, processor);
                ast[task][processor] = calculateAST(task, processor);
                eft[task][processor] = calculateEFT(task, processor);
            }
            int assignedProcessorIndex = getFittestProcessorForAFT(task);
            setAFT(task, assignedProcessorIndex);
        }
        makespan = aft[GraphSimulation.noftasks - 1];
    }

    // calculate Multi-Objectives

    //   Objective function NO.2
    double calculateBeta(int nOfProcessors) {
        double beta = 0.0;
        int[] nOfJobs = new int[nOfProcessors];
        for (int processor = 0; processor < nofprocessors; processor++) {
            int jobsCount = 0;
            for (int task = 0; task < GraphSimulation.noftasks; task++) {
                if (processor_num[task] == processor) {
                    jobsCount++;
                }
            }
            nOfJobs[processor] = jobsCount;
        }
        double[] processorsCapacity = new double[nOfProcessors];

        for (int processor = 0; processor < nofprocessors; processor++) {
            processorsCapacity[processor] = Math.abs(((GraphSimulation.noftasks / nofprocessors) - nOfJobs[processor]));
        }
        // System.out.println("test");
        //  System.out.println(ArrayUtils.getArraySum(processorsCapacity));
        beta = 1 / ArrayUtils.getArraySum(processorsCapacity);
        //    System.out.println(beta);
        return beta;
    }

    /* double calculateMOF(double makespan, double beta) {
      double lambda = Math.random();
      System.out.println("lambda: "+lambda);
      double mof = lambda * makespan + (1 - lambda) * (1 / beta);
      return mof;
  }*/
    double calculateMOF(double makespan, double beta) {
        double[] lambdaValues = {0.0, 0.1, 0.2, 0.3, 0.4, 0.5, 0.6, 0.7, 0.8, 0.9, 1.0};
        double lambda = lambdaValues[getRandomNumberInRange(0, 10)];
        System.out.print(lambda + " \t");
        double mof = lambda * makespan + (1 - lambda) * (1 / beta);
        return mof;
    }

    public int getRandomNumberInRange(int min, int max) {
        if (min >= max) {
            throw new IllegalArgumentException("max must be greater than min");
        }
        Random r = new Random();
        return r.nextInt((max - min) + 1) + min;
    }

    // calculate CCR
    public void CCR() {
        calculateAveCost();
        xx.fill_Communication();
        double ccR = 0.0;
        double computation = 0.0;
        double communicatin = 0.0;
        for (int p = 0; p < GraphSimulation.noftasks; p++) {
            computation += aveCost[p];

        }

        double avgComputation = computation / GraphSimulation.noftasks;
      //  System.out.println(avgComputation + "   ");

        for (int e = 0; e < GraphSimulation.nofedges; e++) {
            communicatin += xx.communication[e];
        }
        double avgCommunication = communicatin / GraphSimulation.nofedges;
      //  System.out.println(avgCommunication + "   ");
        ccR = (avgCommunication / avgComputation);
        System.out.println(ccR + "   ");


    }

}
