package FFT_8p_HACG;
import java.io.*;
import java.util.*;


public class PFHACG_TS {
    public static void main(String[] args) {
        String filePath = "optimalset_FFT_8p_0.5_HACG.txt";
        List<ParetoSolution> solutions = readDataFromFile(filePath);
        Set<ParetoSolution> paretoFront = findParetoFront(solutions);
        
        System.out.println("Pareto Front:");
        for (ParetoSolution s : paretoFront) {
            System.out.println(s.minimizeObjective + " " + s.maximizeObjective);
        }
    }

    public static List<ParetoSolution> readDataFromFile(String filePath) {
        List<ParetoSolution> solutions = new ArrayList<>();
        try (BufferedReader br = new BufferedReader(new FileReader(filePath))) {
            String line;
            while ((line = br.readLine()) != null) {
                line = line.trim();
                if (!line.isEmpty() && !line.contains("---")) { 
                    String[] parts = line.split(", ");
                    double obj1 = Double.parseDouble(parts[0]);
                    double obj2 = Double.parseDouble(parts[1]);
                    solutions.add(new ParetoSolution(obj1, obj2));
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
        return solutions;
    }

    public static Set<ParetoSolution> findParetoFront(List<ParetoSolution> solutions) {
        Set<ParetoSolution> paretoFront = new HashSet<>();
        for (ParetoSolution candidate : solutions) {
            boolean dominated = false;
            for (ParetoSolution other : solutions) {
                if ((other.minimizeObjective <= candidate.minimizeObjective&& other.maximizeObjective >= candidate.maximizeObjective) &&
                    (other.minimizeObjective< candidate.minimizeObjective|| other.maximizeObjective> candidate.maximizeObjective)) {
                    dominated = true;
                    break;
                }
            }
            if (!dominated) {
                paretoFront.add(candidate); // Using Set to prevent duplicates
            }
        }
        return paretoFront;
    }
}
