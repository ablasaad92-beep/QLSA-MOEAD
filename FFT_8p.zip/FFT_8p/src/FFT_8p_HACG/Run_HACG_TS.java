/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package FFT_8p_HACG;

import java.io.*;

import java.util.*;


/**
 *
 * @author PC8-AI
 */
public class Run_HACG_TS {

  
    public static void main(String[] args) throws IOException, CloneNotSupportedException {
        String paretofile = "8P_Paretofront-FFT-1.0-HACG.txt";
        String allRunsfile = "8P_allruns-FFT-1.0-HACG.txt";
        String MetricsFile = "8P_Metrics-FFT-1.0-HACG.txt";
        String optimalfile="./output/8pFFT/data/optimal_FFT_10.txt";

       ArrayList<ArrayList<ParetoSolution>> allRuns = new ArrayList<>();
              int avgRunTime = 0;
              long totalTime = 0;
        ArrayList<Double> HV = new ArrayList<>();
        ArrayList<Double> GD = new ArrayList<>();
        ArrayList<Double> invGD = new ArrayList<>();
         List<String> runData = new ArrayList<>();
       List<ParetoSolution> allSolutions = new ArrayList<>();
              long startTime = System.currentTimeMillis();
              try {
    // مسح محتوى الملف عند بدء التشغيل
    new FileWriter(allRunsfile, false).close();  
  //  System.out.println("✅ تم مسح محتوى الملف: " + allRunsfile);
} catch (IOException e) {
 //   System.err.println("❌ خطأ أثناء مسح الملف: " + e.getMessage());
}
            for (int run = 1; run <= 20; run++) {
                HACG_TS_Algorithm algorithm = new HACG_TS_Algorithm();
                runData.clear(); 
                 long endTime = System.currentTimeMillis();
                 long time = endTime - startTime;
                 totalTime += time;
                 algorithm.runAlgorithm(runData);
                List<ParetoSolution> solutions = parseData(runData);
              //  System.out.println("عدد الحلول في التشغيل " + run + ": " + solutions.size());
                allSolutions.addAll(solutions);
                try (BufferedWriter write = new BufferedWriter(new FileWriter(allRunsfile, true))) { // append mode
    for (ParetoSolution sol : solutions) {
        write.write(sol.minimizeObjective + ", " + sol.maximizeObjective);
        write.newLine();
    }
} catch (IOException e) {
    e.printStackTrace();
}
//                for (ParetoSolution sol : solutions) {
//                    System.out.println(sol.minimizeObjective + ", " + sol.maximizeObjective);
//      
//    }
//System.out.println("تمت كتابة " + solutions.size() + " حلول إلى الملف في التشغيل " + run);

             List<ParetoSolution> Optimal = EfficientOptimalSet.readParetoSolutionsFromFile(optimalfile);                          
              System.out.println("Run " + run + " completed ");
              
              double[][] paretoFront = convertSolutionsToArray(solutions);
                   // Set reference point for hyperVolume calculation
            double[] referencePoint = HypervolumeCalculator.calculateReferencePoint(Optimal);
           //   System.out.println("Reference Point: " + Arrays.toString(referencePoint));
            double hyperVolume = HypervolumeCalculator.calculateHypervolume(paretoFront, referencePoint);
           System.out.println("Hyper Volume: " + hyperVolume ); 
            HV.add(hyperVolume);

            ///////////////////Calculate   GD /////////////////////////
            // Find all optimal solutions           
            double generationalDistance = GenerationalDistanceCalculator.calculateGenerationalDistance(solutions, Optimal);
            GD.add(generationalDistance);
          //  System.out.println("Generational Distance: " + generationalDistance);
             
          // Inverted Generational Distance
        double invgenerationalDistance = IGD.calculateIGDPlus(Optimal,solutions);
            invGD.add(invgenerationalDistance);
      
          }
//          List<ParetoSolution> allSolutions = readSolutionsFromFile("./allruns/Montage_0.5/data/HACG.txt");
System.out.println("تمت قراءة " + allSolutions.size() + allRunsfile);
         
////////////////    Standard Deviation of Hyper Volume ///////////////////
            double sumOfhypervolume = 0;
            for (double d : HV) {
                sumOfhypervolume += d;
            }
            double avghypervolume = sumOfhypervolume / 20;

            // Step 2: Calculate the squared differences
            ArrayList<Double> squaredDifferences = new ArrayList<>();
            for (double num : HV) {
                double difference = num - avghypervolume;
                squaredDifferences.add(difference * difference);
            }

            // Step 3: Calculate the mean of squared differences
            double squaredDifferencesSum = 0.0;
            for (double squaredDifference : squaredDifferences) {
                squaredDifferencesSum += squaredDifference;
            }
            double meanSquaredDifferences = squaredDifferencesSum / HV.size();

            // Step 4: Take the square root to get the standard deviation
            double standardDeviation = Math.sqrt(meanSquaredDifferences);
        
           
 
    
////////////////    Standard Deviation of Generational Distance ///////////////////

       double sumOfGD = 0;
            for (double G : GD) {
                sumOfGD += G;
            }
            double avgGD = sumOfGD / 20;

            // Step 2: Calculate the squared differences
            ArrayList<Double> squaredDifferencesGD = new ArrayList<>();
            for (double n : GD) {
                double differenceGD = n - avgGD;
                squaredDifferencesGD.add(differenceGD * differenceGD);
            }

            // Step 3: Calculate the mean of squared differences
            double squaredDifferencesSumGD = 0.0;
            for (double squaredDifferenceGD : squaredDifferencesGD) {
                squaredDifferencesSumGD += squaredDifferenceGD;
            }
            double meanSquaredDifferencesGD = squaredDifferencesSumGD / GD.size();

            // Step 4: Take the square root to get the standard deviation
            double standardDeviationGD = Math.sqrt(meanSquaredDifferencesGD);
            
      ///////////////////////   inverted Generational Distance ////////////////////////////////
 double sumOfinvGD = 0;
            for (double G : invGD) {
                sumOfinvGD += G;
            }
            double avginvGD = sumOfinvGD / 20;

            // Step 2: Calculate the squared differences
            ArrayList<Double> squaredDifferencesinvGD = new ArrayList<>();
            for (double n : GD) {
                double differenceinvGD = n - avginvGD;
                squaredDifferencesinvGD.add(differenceinvGD * differenceinvGD);
            }

            // Step 3: Calculate the mean of squared differences
            double squaredDifferencesSuminvGD = 0.0;
            for (double squaredDifferenceinvGD : squaredDifferencesinvGD) {
                squaredDifferencesSuminvGD += squaredDifferenceinvGD;
            }
            double meanSquaredDifferencesinvGD = squaredDifferencesSuminvGD / invGD.size();
            // Step 4: Take the square root to get the standard deviation
            double standardDeviationinvGD = Math.sqrt(meanSquaredDifferencesinvGD);
          ///////       pareto front /////////////////////
         
          // قراءة جميع الحلول المخزنة في allruns
allSolutions = readSolutionsFromFile(allRunsfile);

// استخراج الحلول غير المسيطر عليها
List<ParetoSolution> paretoFront = Filter.filterNonDominated(allSolutions);

// حفظ Pareto Front في Paretofront/HACG.txt
writeParetoFrontToFile(paretoFront,paretofile);

//System.out.println("Pareto front extracted and saved successfully.");

                             

    avgRunTime = (int) (totalTime / 20);  
     // hyper volume           
System.out.println("Avg hyper volume ::" + avghypervolume + " \t Standard Diviation ::" + standardDeviation);
// GD
System.out.println("Avg Generational Distance ::" + avgGD + " \t Standard Diviation of GD ::" + standardDeviationGD);

// IGD
System.out.println("Avg invGenerational Distance ::" + avginvGD + " \t Standard Diviation of invGD ::" + standardDeviationinvGD);
System.out.println("Avg Running Time \t:: " + avgRunTime);
  
         
          
try (BufferedWriter writer = new BufferedWriter(new FileWriter(MetricsFile))) {
            writer.write("Average Hypervolume: " + avghypervolume+ "\n");
            writer.write("Standard Deviation Hypervolume: " + standardDeviation + "\n");
            writer.write("Average Generational Distance: " + avgGD + "\n");
            writer.write("Standard Deviation Generational Distance: " + standardDeviationGD+ "\n");
            writer.write("Average Inverted Generational Distance: " + avginvGD + "\n");
            writer.write("Standard Deviation Inverted Generational Distance: " + standardDeviationinvGD + "\n");
            writer.write("Average Run Time: " + avgRunTime + " ms\n");
       

}
}

   
   
   
   
   
   
   
   
   
   
   
    public static void saveListDataToFile(ArrayList<Solution> dataList, String filePath) {
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(filePath))) {
            for (Solution data : dataList) {
                writer.write(data.toString());
                writer.newLine(); // Add a newline for each item in the list
            }
            //  System.out.println("List of data saved to file.");
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public static void appendDoubleValueToFile(double value, String filePath) {
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(filePath, true))) {
            writer.write(String.valueOf(value));
            writer.newLine(); // Add a newline for the new value
            //  System.out.println("Additional double value added to the file.");
        } catch (IOException e) {
            e.printStackTrace();
        }
    
    }

  
    
   static List<ParetoSolution> parseData(List<String> data) {
       List<ParetoSolution> solutions = new ArrayList<>();
       for (String line : data) {
           line = line.trim();
           if (line.isEmpty()) continue;

        
        String[] values = line.split("\\s*[ ,]\\s*");
           if (values.length < 2) continue;

           try {
               double minimizeObjective = Double.parseDouble(values[0].trim());
               double maximizeObjective = Double.parseDouble(values[1].trim());
               solutions.add(new ParetoSolution(minimizeObjective, maximizeObjective));
           } catch (NumberFormatException e) {
               System.err.println("تخطي سطر غير صالح: " + line);
           }
       }
       return solutions;
   }

    static List<ParetoSolution> filterNonDominated(List<ParetoSolution> solutions) {
        List<ParetoSolution> nonDominatedSet = new ArrayList<>();
        
        for (ParetoSolution candidate : solutions) {
            if (!isDominated(candidate, nonDominatedSet)) {
                nonDominatedSet.add(candidate);
            }
        }
        return nonDominatedSet;
    }

    static boolean isDominated(ParetoSolution candidate, List<ParetoSolution> existingSet) {
        for (ParetoSolution solution : existingSet) {
            if (solution.minimizeObjective <= candidate.minimizeObjective
                    && solution.maximizeObjective >= candidate.maximizeObjective) {
                return true;
            }
        }
        return false;
    }
    
        private static String readFile(String filename) {
        StringBuilder content = new StringBuilder();
        try (BufferedReader reader = new BufferedReader(new FileReader(filename))) {
            String line;
            while ((line = reader.readLine()) != null) {
                content.append(line).append("\n");
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
        return content.toString();
    }
   public static Set<ParetoSolution> findParetoFront(List<ParetoSolution> solutions) {
    Set<ParetoSolution> paretoFront = new HashSet<>();
    
    for (ParetoSolution candidate : solutions) {
        boolean dominated = false;
        
        for (ParetoSolution other : solutions) {
            if ((other.minimizeObjective <= candidate.minimizeObjective && other.maximizeObjective >= candidate.maximizeObjective)) {
                if (other.minimizeObjective < candidate.minimizeObjective || other.maximizeObjective > candidate.maximizeObjective) {
                    dominated = true;
                    break;
                }
            }
        }
        
        if (!dominated) {
            paretoFront.add(candidate);
            System.out.println("Added to Pareto Front: " + candidate.minimizeObjective + ", " + candidate.maximizeObjective);
        }
    }
    
    System.out.println("Final Pareto Front size: " + paretoFront.size());
    return paretoFront;
}

public static List<ParetoSolution> readDataFromFile(String filePath) {
    List<ParetoSolution> solutions = new ArrayList<>();
    try (BufferedReader br = new BufferedReader(new FileReader(filePath))) {
        String line;
        while ((line = br.readLine()) != null) {
            line = line.trim();
            if (!line.isEmpty() && !line.contains("---")) {
                String[] parts = line.split("\\s*[ ,]\\s*");
                
        
                // التحقق من أن السطر يحتوي على قيمتين قبل التحليل
                if (parts.length < 2) {
                    System.err.println("Skipping invalid line: " + line);
                    continue;
                }

                try {
                    double obj1 = Double.parseDouble(parts[0].trim());
                    double obj2 = Double.parseDouble(parts[1].trim());
                    solutions.add(new ParetoSolution(obj1, obj2));
                } catch (NumberFormatException e) {
                    System.err.println("Skipping line due to format error: " + line);
                }
            }
        }
    } catch (IOException e) {
        e.printStackTrace();
    }
    return solutions;
}

public static void writeParetoFrontToFile(Set<ParetoSolution> paretoFront, String filePath) {
    try (BufferedWriter writer = new BufferedWriter(new FileWriter(filePath))) {
        for (ParetoSolution s : paretoFront) {
            writer.write(s.minimizeObjective + ", " + s.maximizeObjective);
            writer.newLine();
        }
    } catch (IOException e) {
        e.printStackTrace();
    }
}
public static double[][] convertSolutionsToArray(List<ParetoSolution> solutions) {
    double[][] array = new double[solutions.size()][2]; // مصفوفة بحجم الحلول
    for (int i = 0; i < solutions.size(); i++) {
        array[i][0] = solutions.get(i).minimizeObjective;
        array[i][1] = solutions.get(i).maximizeObjective;
    }
    return array;
}
public static void writeParetoFrontToFile(List<ParetoSolution> paretoFront, String filePath) {
    try (BufferedWriter writer = new BufferedWriter(new FileWriter(filePath))) {
        for (ParetoSolution sol : paretoFront) {
            writer.write(sol.minimizeObjective + ", " + sol.maximizeObjective);
            writer.newLine();
        }
    } catch (IOException e) {
        e.printStackTrace();
    }
}
public static List<ParetoSolution> readSolutionsFromFile(String filePath) {
    List<ParetoSolution> solutions = new ArrayList<>();
    try (BufferedReader br = new BufferedReader(new FileReader(filePath))) {
        String line;
        while ((line = br.readLine()) != null) {
            line = line.trim();
            if (line.isEmpty()) continue;

            String[] parts = line.split("\\s*,\\s*"); // يفصل باستخدام الفاصلة
            if (parts.length < 2) continue;

            try {
                double obj1 = Double.parseDouble(parts[0]);
                double obj2 = Double.parseDouble(parts[1]);
                solutions.add(new ParetoSolution(obj1, obj2));
            } catch (NumberFormatException e) {
                System.err.println("Skipping invalid line: " + line);
            }
        }
    } catch (IOException e) {
        e.printStackTrace();
    }
    return solutions;
}

}
