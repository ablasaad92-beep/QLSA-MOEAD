 /*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package FFT_8p_TS;



import java.util.*;


/**
 * @author AblaSaad
 */
public class GReedy_TabuSearch {

    int cl[];
    public int RCL[];
    public int[] finalRCL;
    public double alpha = 0.4;

    int[] bestSol;
    double bestMake;
     double ResUti;
    int[] constructionSolution;

    MachineAssign S1;
    ArrayList<Double> probability;
    Set<int[]> solution;
    ArrayList<int[]> options;

    ArrayList<int[]> population;
    ArrayList<Double> pop_make;
     ArrayList<Double> RU;
    int TABU_ITEM_LIFETIME = 10;
    int TABU_LIST_MAX_LENGTH =10;
    int MAX_ITERATION = 10;
    int NO_IMPROVEMENT_LIMIT = 10;
    ArrayList<int[]> TabuList;
    ArrayList<Double > TabuList_makespan;

    public GReedy_TabuSearch() {
        cl = new int[GraphSimulation.noftasks];
        constructionSolution = new int[GraphSimulation.noftasks];
        probability = new ArrayList<>();
        solution = new HashSet<>();
        options = new ArrayList<>();
        bestSol = new int[GraphSimulation.noftasks];
        TabuList = new ArrayList<>();
        population = new ArrayList<>();
        pop_make = new ArrayList<>();
        RU = new ArrayList<>();
        TabuList_makespan=new ArrayList<>();;
    }

    // Validate Any Schedule
    public boolean validateConstruction() {
        boolean valid = true;
        for (int i = 0; i < constructionSolution.length; i++) {
            for (int ii = i + 1; ii < constructionSolution.length; ii++) {
                if ((GraphSimulation.level[constructionSolution[i]] > GraphSimulation.level[constructionSolution[ii]])) {
                    valid = false;
                    break;
                }
            }
        }

        return valid;
    }

    //      Phase 1 Construction Phase
    public void construct(int[] cl) throws Exception {
        if (cl.length < 1) throw new Exception("Empty input");
        GraphUtils obj = new GraphUtils();
        int rclLength = (int) (alpha * cl.length); // RCL length
        finalRCL = new int[GraphSimulation.noftasks];
        for (int i = 0; i < cl.length; i += rclLength) {
            int sliceSize;
            if (i + rclLength < cl.length) {
                sliceSize = rclLength;
            } else {
                sliceSize = cl.length - i;
            }
            int[] slice = Arrays.copyOfRange(cl, i, i + sliceSize);
            ArrayList shuffledSlice = new ArrayList<Integer>();
            int randomTaskIdx = getRandomNumberInRange(0, sliceSize - 1);


            while (shuffledSlice.size() < sliceSize) {
                if (randomTaskIdx >= 0 && randomTaskIdx < sliceSize && !(shuffledSlice.contains(slice[randomTaskIdx]))) {
                    shuffledSlice.add(slice[randomTaskIdx]);
                } else {
                    randomTaskIdx = getRandomNumberInRange(0, sliceSize - 1);
                }
            }

            // swap single slice
            for (int r = 0; r < sliceSize; r++) {
                for (int rr = r + 1; rr < sliceSize; rr++) {
                    if (GraphSimulation.level[(int) shuffledSlice.get(r)] > GraphSimulation.level[(int) shuffledSlice.get(rr)]) {
                        Collections.swap(shuffledSlice, r, rr);
                    }
                }
            }
            for (int r = 0; r < sliceSize; r++) {
                finalRCL[i + r] = (int) shuffledSlice.get(r);
            }
        }
        //ensure finalRCL in the correct order
        for (int r = 0; r < finalRCL.length; r++) {
            for (int rr = r + 1; rr < finalRCL.length; rr++) {
                if (GraphSimulation.level[finalRCL[r]] > GraphSimulation.level[finalRCL[rr]]) {
                    int temp = finalRCL[r];
                    finalRCL[r] = finalRCL[rr];
                    finalRCL[rr] = temp;
                }
            }
        }
        constructionSolution = finalRCL.clone();
    }

    //_________________Tabu-Search_________________//
    public void Tabu_Search() throws Exception {
        MachineAssign S0 = new MachineAssign();
        
        S0.Assigning(constructionSolution);  // intial solution      
        pop_make.add(S0.makespan);    // objective of intial sol
        RU.add(S0.calculateBeta(MachineAssign.nofprocessors));
        int noImprovementIterations = 0;        // Initialize the number of iterations without improvement to 0
        // Repeat until the max number of iterations is reached or there has no improvement
        for (int i = 0; i < MAX_ITERATION && noImprovementIterations<NO_IMPROVEMENT_LIMIT; i++) {
            // Generate a list of all possible Neighbours 
            
           
            for (int ii = GraphSimulation.noftasks - 1; ii >= GraphSimulation.noftasks - 2; ii--) {
                    int temp = 0;
                    if (GraphSimulation.level[constructionSolution[ii]] >= GraphSimulation.level[constructionSolution[ii - 1]]) {
                        temp = constructionSolution[ii];
                        constructionSolution[ii] = constructionSolution[ii - 1];
                        constructionSolution[ii - 1] = temp;
                    }
                } 
            // new solution S1 with make span F(S1)
                S1 = new MachineAssign();
                S1.Assigning(constructionSolution);
                pop_make.add(S1.makespan);
                 RU.add(S1.calculateBeta(MachineAssign.nofprocessors));
                //   System.out.println(+S1.makespan + "\t" + S1.flowtime);
                    int rand1 = 0;
                    int rand2 = 0;
                    do {

                        rand1 = getRandomNumberInRange(0, GraphSimulation.noftasks - 1);
                        rand2 = getRandomNumberInRange(0, GraphSimulation.noftasks - 1);

                    } while (rand1 == rand2 || (!(GraphSimulation.level[rand1] == GraphSimulation.level[rand2])));

                    int temp2 = constructionSolution[rand1];
                    constructionSolution[rand1] = constructionSolution[rand2];
                    constructionSolution[rand2] = temp2;

                    S1 = new MachineAssign();
                    S1.Assigning(constructionSolution);                   
                    pop_make.add(S1.makespan);
                     RU.add(S1.calculateBeta(MachineAssign.nofprocessors));
                    //  pop_make.add(S1.makespan);
                    // System.out.println(+S1.makespan + "\t" + S1.flowtime);

              

            // fill tabuList and Update the best solution and best cost if the current solution is better 
            double d = S0.makespan - S1.makespan;
            if (!TabuList.contains(S1.makespan) && d > 0) {
                   S0.makespan = S1.makespan;
                   TabuList.add(constructionSolution);
                   pop_make.add(S0.makespan);
                   RU.add( S0.calculateBeta(MachineAssign.nofprocessors));
                noImprovementIterations = 0;              
            } else {
                 noImprovementIterations++;
            }



            // If the tabu list is full, remove the oldest element
            if (TabuList.size() > TABU_LIST_MAX_LENGTH) {                
                TabuList.remove(0);
            }
        }
                 
               
                bestMake = pop_make.get(0);
            for (int i = 1; i < pop_make.size(); i++) {
            if (bestMake > pop_make.get(i)) {
                bestMake = pop_make.get(i);
                
            }
        }
          
    }


    // random number generation
    public int getRandomNumberInRange(int min, int max) {
        if (min >= max) {
            throw new IllegalArgumentException("max must be greater than min");
        }
        Random r = new Random();
        return r.nextInt((max - min) + 1) + min;
    }

  double [][] getMakeSpanUtilization(ArrayList<Solution> pop) {   
        double[][] arr = new double[pop.size()][2];
         for (int i = 0; i < pop.size(); i++) {     
         Solution s = pop.get(i);
           arr[i][0]= s.makeSpan;      
           arr[i][1] = s.resourceUtilization;
           }    return arr;
             }
    public static void main(String[] args) {
          ArrayList<Double> HV = new ArrayList<>(); 

//          int avgRunTime = 0;
//          int avgMake = 0;
//          long totalTime = 0;
        ArrayList<Double> bestMake = new ArrayList<>();
        ArrayList<Double> ResourceUT = new ArrayList<>();
       
        // long startTime = System.currentTimeMillis();
        int noRuns = 20;
        try {
            for (int i = 0; i < noRuns; i++) {
                // Run to generate 100 solution 
                for (int sol=0;sol<100;sol++){
                    
               // System.out.println("run: #" + (i + 1) + " processing...");
//                long startTime = System.currentTimeMillis();
              
                GReedy_TabuSearch cp = new GReedy_TabuSearch();
                MachineAssign m= new MachineAssign();
                int[] input = new GraphUtils().Bottom_Descending().clone();
//                int[] input = new GraphUtils().Top_Ascending().clone();
//                int[] input = new GraphUtils().CriticalPath_Descending().clone();
                cp.construct(input);
                cp.Tabu_Search();
                bestMake.add(cp.bestMake);

//                long endTime = System.currentTimeMillis();
//                long time = endTime - startTime;
//                totalTime += time;
//                System.out.print(  totalTime+"\t");
                System.out.println("run: #" + (i + 1) + " Solution Number");
            }}
        } catch (Exception e) {
            e.printStackTrace();
        }
      
        
        
        
        
//       double[][] paretoFront = {{bestMake,RU}};
//        HypervolumeCalculator hp=new HypervolumeCalculator();
//                 // Set reference point for hypervolume calculation
//         double[]referencePoint = hp.calculateReferencePoint(paretoFront);
//        System.out.println("Reference Point: " + Arrays.toString(referencePoint));
//        double hypervolume = hp.calculateHypervolume(paretoFront, referencePoint);            
//        System.out.println("Hyper Volume: " + hypervolume ); 
//        HV.add(hypervolume);
//
//        double sumOfhypervolume = 0;
//        for (double d : HV) {
//            sumOfhypervolume += d;
//        }
//        double avghypervolume = sumOfhypervolume / noRuns;
//        
//      // Step 2: Calculate the squared differences
//        ArrayList<Double> squaredDifferences = new ArrayList<>();
//        for (double num : HV) {
//            double difference = num - avghypervolume;
//            squaredDifferences.add(difference * difference);
//        }
//        
//         // Step 3: Calculate the mean of squared differences
//        double squaredDifferencesSum = 0.0;
//        for (double squaredDifference : squaredDifferences) {
//            squaredDifferencesSum += squaredDifference;
//        }
//        double meanSquaredDifferences = squaredDifferencesSum / HV.size();
//
//         // Step 4: Take the square root to get the standard deviation
//        double standardDeviation = Math.sqrt(meanSquaredDifferences);
//     
//        System.out.println("Avg hyper volume ::" + avghypervolume + " \t Standard Diviation ::" + standardDeviation );
        
      
        
        
        
        
        
        
        
      
    
    }
    
 

    //  }
}