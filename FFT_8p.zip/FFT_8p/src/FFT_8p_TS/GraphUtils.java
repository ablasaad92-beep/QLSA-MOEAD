
package FFT_8p_TS;




import java.util.*;

/**
 *
 * @author Eng.Aplaa Saad
 */
/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
public class GraphUtils {

    GraphSimulation xx = new GraphSimulation();
    MachineAssign p = new MachineAssign();
    double[] listmemoization; // for recursion memoization
   double[] tlevels;

    public GraphUtils() {

        listmemoization = new double[xx.noftasks];
        tlevels = new double[xx.noftasks];
        Bottoms();
        Tops();

    }

    
    
    
    
    public void Tops() {
        xx.fill_Communication();
     
        xx.fill_Incedence();
        p.calculateAveCost();
        for (int i = 0; i < xx.execution.length; i++) {
            if (xx.check_Start(i)) {
                tlevels[i] =  p.aveCost[i];
            } else {
                int predecessor[][] = xx.predecessor(i);
                double level[] = new double[xx.degreeIn(i)];
                for (int j = 0; j < xx.degreeIn(i); j++) {
                    level[j] = tlevels[predecessor[1][j]] + xx.communication[predecessor[0][j]];
                }

               double max = level[0];
                for (int j = 1; j < xx.degreeIn(i); j++) {
                    if (level[j] > max) {
                        max = level[j];
                    }
                }
                tlevels[i] =  (max + p.aveCost[i]);
            }
        }

    }

    //********* Top Level ***********//
   public double TOP_Level(int node) {

       double Toplevel;
        xx.fill_Incedence();
        p.calculateAveCost();
        xx.fill_Communication();
        int x[][] = xx.predecessor(node);
        double level[] = new double[xx.degreeIn(node)];

        if (xx.check_Start(node) == true) {
            Toplevel = 0;
        } else {

            for (int i = 0; i < xx.degreeIn(node); i++) {
                level[i] =  (TOP_Level(x[1][i]) + p.aveCost[x[1][i]] + xx.communication[x[0][i]]);

            }
            double max = level[0];
            for (int j = 1; j < xx.degreeIn(node); j++) {
                if (level[j] > max) {
                    max = level[j];
                }
            }

            Toplevel = max;
        }
        return Toplevel;

    }
   // ---------- Sotring top leval as Ascending-------------
    public int[] Top_Ascending() {
        Tops();
        int[][] Topascending = new int[2][xx.noftasks]; //1st >> #task, 2nd >> T-level

        for (int i = 0; i <xx. noftasks; i++) {
           Topascending[0][i] = i;
           Topascending[1][i] = (int) TOP_Level(i);

        }
       
        for (int i = 0; i < xx.noftasks; i++) {
            for (int ii = i + 1; ii < xx.noftasks; ii++) {
                if (Topascending[1][i] >Topascending[1][ii]) {
                    int tempbottom = Topascending[1][i];
                    Topascending[1][i] = Topascending[1][ii];
                   Topascending[1][ii] = tempbottom;

                    double tempOrder = Topascending[0][i];
                   Topascending[0][i] = Topascending[0][ii];
                   Topascending[0][ii] = (int) tempOrder;

                }
            }
    //  System.out.println("top_Ascending Periority");
     //  System.out.println(Topascending[0][i] + "\t" + "\t" + Topascending[1][i]);

        }

        return Topascending[0];
        
    }


    public void Bottoms() {
       
        xx.fill_Communication();
        p.calculateCost();
        p.calculateAveCost();
        xx.fill_Incedence();
        for (int i = p.aveCost.length - 1; i >= 0; i--) {
            if (xx.check_End(i)) {
                listmemoization[i] = p.aveCost[i];
            } else {
                int successors[][] = xx.Successor(i);
                double level[] = new double[xx.degreeOut(i)];
                for (int j = 0; j < xx.degreeOut(i); j++) {
                    level[j] =  (listmemoization[successors[1][j]] + xx.communication[successors[0][j]]);
                }

                double max = level[0];
                for (int j = 1; j < xx.degreeOut(i); j++) {
                    if (level[j] > max) {
                        max = level[j];
                    }
                }
                listmemoization[i] = (max + p.aveCost[i]);
            }
        }

    }

    //********* Bottom Level ***********//
    public double Bottom_Level(int node) {
        return listmemoization[node];
    }

    public int[] Bottom_Descending() {
        Bottoms();
        int[][] bottomDescending = new int[2][xx.noftasks]; //1st >> #task, 2nd >> b-level

        for (int i = 0; i < xx.noftasks; i++) {
            bottomDescending[0][i] = i;
            bottomDescending[1][i] =  (int) listmemoization[i];

        }
        for (int i = 0; i < xx.noftasks; i++) {
            for (int ii = i + 1; ii < xx.noftasks; ii++) {
                if (bottomDescending[1][i] < bottomDescending[1][ii]) {
                    double tempbottom = bottomDescending[1][i];
                    bottomDescending[1][i] = bottomDescending[1][ii];
                    bottomDescending[1][ii] = (int) tempbottom;

                   int tempOrder = bottomDescending[0][i];
                    bottomDescending[0][i] = bottomDescending[0][ii];
                    bottomDescending[0][ii] = tempOrder;

                }

            }
         //  System.out.println(bottomDescending[0][i] + "\t" + "\t" + bottomDescending[1][i]);

        }

        return bottomDescending[0];
    }
    
    
    //   Get Critical path --------------------
     
         int[] getTopsAndBottoms(double[] tops, double[] bottoms) {
        int _values[] = new int[xx.noftasks];
        for (int t = 0; t < xx.noftasks; t++) {
            _values[t] = (int) (tops[t] + bottoms[t]);
            System.out.println( "Critical_path \t " + t +"\t"+_values[t] );
        }
        return _values;
    }

    int[] getCriticalPath(int[] topsAndBottoms) {
    int maximum = topsAndBottoms[0];   // start with the first value
        for (int i = 1; i < topsAndBottoms.length; i++) {
            if (topsAndBottoms[i] > maximum) {
                maximum = topsAndBottoms[i];   // new maximum
            }
        }

        LinkedList<Integer> criticalPath = new LinkedList<Integer>();
        for (int i = 0; i < topsAndBottoms.length; i++) {
            if (topsAndBottoms[i] == maximum) {
                criticalPath.add(i);   // new maximum
            }
        }
        Object[] array = criticalPath.toArray();

        int[] result = new int[array.length];

        // copy elements from object array to integer array
        for (int i = 0; i < array.length; i++) {
            result[i] = (int) array[i];
        }

        return result;

    }
 public int[] CriticalPath_Descending() {
        
        int[][] CriticalDescending = new int[2][xx.noftasks]; //1st >> #task, 2nd >> b-level
   double Top[] = new double[GraphSimulation.noftasks];
       double Bot[] = new double[GraphSimulation.noftasks];
        for (int i = 0; i < xx.noftasks; i++) {
            Top[i] = TOP_Level(i);
             Bot[i] =  Bottom_Level(i);
            CriticalDescending[0][i] = i;
            CriticalDescending[1][i] =  (int)  ( Top[i] + Bot[i]);

        }
        for (int i = 0; i < xx.noftasks; i++) {
            for (int ii = i + 1; ii < xx.noftasks; ii++) {
                if (CriticalDescending[1][i] < CriticalDescending[1][ii]) {
                    double tempbottom = CriticalDescending[1][i];
                    CriticalDescending[1][i] = CriticalDescending[1][ii];
                    CriticalDescending[1][ii] = (int) tempbottom;

                   int tempOrder = CriticalDescending[0][i];
                    CriticalDescending[0][i] = CriticalDescending[0][ii];
                    CriticalDescending[0][ii] = tempOrder;

                }

            }
         //  System.out.println(CriticalDescending[0][i] + "\t" + "\t" + CriticalDescending[1][i]);

        }

        return CriticalDescending[0];
    }
 
 //    Random population
     public int[] random_population() {
        int[] randomOrder = new int[GraphSimulation.noftasks];
        Arrays.fill(randomOrder, -1);
        for (int j = 0; j < GraphSimulation.noftasks; j++) {
            int rand = getRandomNumberInRange(0, GraphSimulation.noftasks - 1);
            for (int a = 0; a < j; a++) {
                while (randomOrder[a] == rand) {
                    rand = getRandomNumberInRange(0,GraphSimulation. noftasks - 1);
                    a = 0;
                }
            }
            randomOrder[j] = rand;
        }

        for (int i = 0; i < GraphSimulation.noftasks; i++) {
            for (int j = i + 1; j < GraphSimulation.noftasks; j++) {
                if (GraphSimulation.level[randomOrder[i]] > GraphSimulation.level[randomOrder[j]]) {
                    int temp = randomOrder[i];
                    randomOrder[i] = randomOrder[j];
                    randomOrder[j] = temp;
                }
            }
        }
        return randomOrder;
    }
     
     public int getRandomNumberInRange(int min, int max) {

        if (min >= max) {
            throw new IllegalArgumentException("max must be greater than min");
        }

        Random r = new Random();
        return r.nextInt((max - min) + 1) + min;
    } 
   // ---------- Sotring top leval as Ascending-------------
    public int[] Level_Ascending() {
       xx.fill_levels();
        int[][] levelascending = new int[2][xx.noftasks]; //1st >> #task, 2nd >> T-level

        for (int i = 0; i <xx. noftasks; i++) {
           levelascending[0][i] = i;
           levelascending[1][i] = xx.level[i];

        }
       
        for (int i = 0; i < xx.noftasks; i++) {
            for (int ii = i + 1; ii < xx.noftasks; ii++) {
                if (levelascending[1][i] >levelascending[1][ii]) {
                    int tempbottom = levelascending[1][i];
                    levelascending[1][i] = levelascending[1][ii];
                   levelascending[1][ii] = tempbottom;

                    double tempOrder = levelascending[0][i];
                   levelascending[0][i] = levelascending[0][ii];
                  levelascending[0][ii] = (int) tempOrder;

                }
            }
    //  System.out.println("top_Ascending Periority");
     //  System.out.println(Topascending[0][i] + "\t" + "\t" + Topascending[1][i]);

        }

        return levelascending[0];
        
    }


    public static void main(String[] args) {
        GraphUtils o = new GraphUtils();
        GraphSimulation x = new GraphSimulation();
        o.Tops();
        o.Bottoms();
        o.Bottom_Descending();
        o.Top_Ascending();
     o.CriticalPath_Descending();

       double Top[] = new double[x.noftasks];
       double Bot[] = new double[x.noftasks];
       
        for (int t = 0; t < x.noftasks; t++) {
            Top[t] =  o.TOP_Level(t);
             Bot[t] =  o.Bottom_Level(t);
               
              System.out.print("task" + (t) + "\t top: \t" + Top[t] + "\n");
        }
        for (int b = 0; b < x.noftasks; b++) {
         System.out.print("task" + (b) + "\t Bottomlevels: \t" + Bot[b] + "\n");  
        }
        
        
        // x.critical_path();
      
   
        int topsAndBottoms[] = o.getTopsAndBottoms(Top, Bot);
         int criticalPath[] = o.getCriticalPath(topsAndBottoms);
             System.out.println("-----------------------------------------");
        System.out.print("Critical Path: ");

          for (int bl = 0; bl < criticalPath.length; bl++) {
            System.out.print(criticalPath[bl] + "   ");
        }
        System.out.println("\n--------------------------------------");
      
    }

}
