package FFT_8p_GTS;




import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Stream;

public class EfficientOptimalSet {
    // Specify the file path

    public static void main(String[] args) {
        String filePath = "./output/8pFFT/data/set_FFT_0.5.txt";
        int noRuns =50;
        int N = 100; // population size
        int neighborSize = 10; // neighbour size of population
        MOEAD b = new MOEAD();
        MachineAssign MO = new MachineAssign();
        ArrayList<ArrayList<ParetoSolution>> allRuns = new ArrayList<>();
        for (int run = 0; run < noRuns; run++) {
            // 1.1 initialization for population
            b.initialization(MO);
            b.generatePopulationWeights(); // generate weights for population solutions
            //   System.out.println("\n * Initial Population: ");
            //   for (Solution s : b.population) {
            //       System.out.println(s.toString());
            //   }
            //   System.out.println("------------------------------------------------\n\n");
            int[][] allNeighbors = MOEAD.findAllNeighbors(N, neighborSize);
            int iteration = 0;
            do {
                // 11.2 randomly  selection two solutions from all  population
                b.selection();

                // 1.2 by generating a random number for Probability less than 0.7 applying cross over on the two selected solution
                // maximum crossover probabilities
                double maxCrossoverProbability = 0.7;
                // Randomly generate crossover probability within the range [0, maxCrossoverProbability)
                double Pc = Math.random() * maxCrossoverProbability;
                b.crossOver(Pc);

                // 1.2 by generating a random number for Probability less than 0.3 applying mutation on the solutions Crossed over in step 1.2
                // Minimum and maximum mutation probabilities
                double minMutationProbability = 0.1;
                double maxMutationProbability = 0.3;
                // Randomly generate mutation probability within the specified range
                double Pm = minMutationProbability + (maxMutationProbability - minMutationProbability) * Math.random();
                b.mutation(MO, Pm);

                if (b.first.isValid && b.second.isValid) {
                    try {
                        // comparing the best one from mutation with the neighbour size of its iteration and then update the population
                        Solution bestMutatedSolution;
                        // select best mutated solution
                        if (b.first.getMOF() < b.second.getMOF()) {
                            bestMutatedSolution = b.first.clone();
                        } else {
                            bestMutatedSolution = b.second.clone();
                        }
                        b.compareAndSwapIfMinimized(bestMutatedSolution, allNeighbors, iteration);
                    } catch (Exception e) {
                        // System.out.println("iteration#" + iteration + ": System can't compare unassigned solutions");
                        //TODO: [Aplaa] if you want to retry just comment the above print statement and uncomment the following
                        // System.out.println("iteration#" + iteration + ": System can't compare unassigned solutions, retrying again ...");
                        // continue;
                    }
                } else {
                    //  System.out.println("iteration#" + iteration + ": Sorry, maybe one of both solution isn't valid");
                    //TODO: [Aplaa] same here, if you want to retry just comment the above print statement and uncomment the following
                    // System.out.println("iteration#" + iteration + ": Sorry, maybe one of both solution isn't valid, retrying again ...");
                    // continue;
                }
                iteration++;
            } while (iteration < 100);
            //   System.out.println("=================================================\n\n");
            //   System.out.println("\n * final Population: ");


            ArrayList<ParetoSolution> paretoSolutions = new ArrayList<>();
            for (Solution s : b.population) {
                paretoSolutions.add(new ParetoSolution(s.makeSpan, s.resourceUtilization));
            }
            allRuns.add(paretoSolutions);

        }

        FileIOUtils.writeToFile(allRuns, filePath, false);
        ArrayList<ParetoSolution> cachedOutput = FileIOUtils.readFromFile(filePath);

        List<ParetoSolution> bestSolutions =Filter.filterNonDominated(cachedOutput);
        String optimalMontageFilePath = "./output/8pFFT/data/optimal_FFT_0.5.txt";
        FileIOUtils.writeNonDominatedSolutionsToFile(bestSolutions, optimalMontageFilePath, true);
        // Print all non-dominated solutions
        System.out.println("All Best Solutions:");
        for (ParetoSolution solution : bestSolutions) {
            System.out.println("Minimize Objective: " + solution.minimizeObjective + ", Maximize Objective: " + solution.maximizeObjective);
        }
    }


    public static List<ParetoSolution> readParetoSolutionsFromFile(String filePath) {
        List<ParetoSolution> solutions = new ArrayList<>();

        try (Stream<String> lines = Files.lines(Paths.get(filePath))) {
            lines.forEach(line -> {
                String[] parts = line.split("\\s+"); // Assuming space-separated values
                double minimizeObjective = Double.parseDouble(parts[0]);
                double maximizeObjective = Double.parseDouble(parts[1]);
                solutions.add(new ParetoSolution(minimizeObjective, maximizeObjective));
            });
        } catch (Exception e) {
            e.printStackTrace();
        }

        return solutions;
    }


}
