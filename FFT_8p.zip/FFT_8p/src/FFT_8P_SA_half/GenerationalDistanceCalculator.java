/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package FFT_8P_SA_half;

/**
 * @author AblaSaad
 */




import java.util.ArrayList;
import java.util.List;

// Check [Aplaa] class changed
public class GenerationalDistanceCalculator {

    public static void main(String[] args) {
        // Example solutions (makespan, resource utilization)
        List<ParetoSolution> obtainedSolutions = new ArrayList<>();
        obtainedSolutions.add(new ParetoSolution(10, 0.8));
        obtainedSolutions.add(new ParetoSolution(8, 0.9));
        obtainedSolutions.add(new ParetoSolution(12, 0.7));

        // Reference solutions (known Pareto-optimal solutions)
        List<ParetoSolution> referenceSolutions = new ArrayList<>();
        referenceSolutions.add(new ParetoSolution(9, 0.85));

        // Calculate Generational Distance
        double generationalDistance = calculateGenerationalDistance(obtainedSolutions, referenceSolutions);

        System.out.println("Generational Distance: " + generationalDistance);
    }

    // Calculate Generational Distance given obtained solutions and a reference set
    static double calculateGenerationalDistance(List<ParetoSolution> obtainedSolutions, List<ParetoSolution> referenceSolutions) {
        double sumDistances = 0.0;

        for (ParetoSolution obtainedSolution : obtainedSolutions) {
            double minDistance = Double.MAX_VALUE;

            for (ParetoSolution referenceSolution : referenceSolutions) {
                double distance = euclideanDistance(obtainedSolution, referenceSolution);
                minDistance = Math.min(minDistance, distance);
            }

            sumDistances += minDistance;
        }

        // Calculate average distance
        return sumDistances / obtainedSolutions.size();
    }

    // Calculate Euclidean distance between two points in the objective space
    private static double euclideanDistance(ParetoSolution point1, ParetoSolution point2) {
        double distance1 = Math.pow(point1.minimizeObjective - point2.minimizeObjective, 2);
        double distance2 = Math.pow(point1.maximizeObjective - point2.maximizeObjective, 2);
        return Math.sqrt(distance1 + distance2);
    }
}


