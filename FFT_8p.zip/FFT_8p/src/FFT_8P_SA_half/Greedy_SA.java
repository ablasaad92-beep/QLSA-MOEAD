/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package FFT_8P_SA_half;





import java.util.*;

/**
 * @author Aplaa Saad
 */
public class Greedy_SA {

    int cl[];
    public int RCL[];
    public int[] finalRCL;
    public double alpha = 0.4;
    //    public double beta = 0.7;
    int[] bestSol;
    double bestMake;
    int[] constructionSolution;
    MachineAssign S1;
    ArrayList<Double> probability;
    Set<int[]> solution;
    ArrayList<int[]> options;
    ArrayList<int[]> population;
    ArrayList<Double> pop_make;

    public Greedy_SA() {
        cl = new int[GraphSimulation.noftasks];
        constructionSolution = new int[GraphSimulation.noftasks];
        probability = new ArrayList<>();
        solution = new HashSet<>();
        options = new ArrayList<>();
        bestSol = new int[GraphSimulation.noftasks];
        population = new ArrayList<>();
        pop_make = new ArrayList<>();
    }

    // Validate Any Schedule
    public boolean validateConstruction() {
        boolean valid = true;
        for (int i = 0; i < constructionSolution.length; i++) {
            for (int ii = i + 1; ii < constructionSolution.length; ii++) {
                if ((GraphSimulation.level[constructionSolution[i]] > GraphSimulation.level[constructionSolution[ii]])) {
                    valid = false;
                    break;
                }
            }
        }

        return valid;
    }

    //      Phase 1 Construction Phase
    public void construct(int[] cl) throws Exception {
        if (cl.length < 1) throw new Exception("Empty input");
        GraphUtils obj = new GraphUtils();
        int rclLength = (int) (alpha * cl.length); // RCL length
        finalRCL = new int[GraphSimulation.noftasks];
        for (int i = 0; i < cl.length; i += rclLength) {
            int sliceSize;
            if (i + rclLength < cl.length) {
                sliceSize = rclLength;
            } else {
                sliceSize = cl.length - i;
            }
            int[] slice = Arrays.copyOfRange(cl, i, i + sliceSize);
            ArrayList shuffledSlice = new ArrayList<Integer>();
            int randomTaskIdx = getRandomNumberInRange(0, sliceSize - 1);


            while (shuffledSlice.size() < sliceSize) {
                if (randomTaskIdx >= 0 && randomTaskIdx < sliceSize && !(shuffledSlice.contains(slice[randomTaskIdx]))) {
                    shuffledSlice.add(slice[randomTaskIdx]);
                } else {
                    randomTaskIdx = getRandomNumberInRange(0, sliceSize - 1);
                }
            }

            // swap single slice
            for (int r = 0; r < sliceSize; r++) {
                for (int rr = r + 1; rr < sliceSize; rr++) {
                    if (GraphSimulation.level[(int) shuffledSlice.get(r)] > GraphSimulation.level[(int) shuffledSlice.get(rr)]) {
                        Collections.swap(shuffledSlice, r, rr);
                    }
                }
            }
            for (int r = 0; r < sliceSize; r++) {
                finalRCL[i + r] = (int) shuffledSlice.get(r);
            }
        }
        //ensure finalRCL in the correct order
        for (int r = 0; r < finalRCL.length; r++) {
            for (int rr = r + 1; rr < finalRCL.length; rr++) {
                if (GraphSimulation.level[finalRCL[r]] > GraphSimulation.level[finalRCL[rr]]) {
                    int temp = finalRCL[r];
                    finalRCL[r] = finalRCL[rr];
                    finalRCL[rr] = temp;
                }
            }
        }
        constructionSolution = finalRCL.clone();
    }

    //_________________local Search with Simulated Annealing_________________//
    public void SearchSimulated() {
        // 1.. solution S0 with make span F(S0)
        MachineAssign S0 = new MachineAssign();
        S0.Assigning(constructionSolution);
        population.add(constructionSolution);
        pop_make.add(S0.makespan);
        //System.out.println(+S0.makespan + "\t" + S0.flowtime);

        // 2.. temperature
        int T = 200;  // temperature
        double delta = 0.01, r = 0.99; // small value
        while (T > delta) {
            if (T > delta) {
                // 3.. generate solution S0 with make span F(S0)
                for (int ii = GraphSimulation.noftasks - 1; ii >= GraphSimulation.noftasks - 2; ii--) {
                    int temp = 0;
                    if (GraphSimulation.level[constructionSolution[ii]] >= GraphSimulation.level[constructionSolution[ii - 1]]) {
                        temp = constructionSolution[ii];
                        constructionSolution[ii] = constructionSolution[ii - 1];
                        constructionSolution[ii - 1] = temp;
                    }
                }  // new solution S1 with make span F(S1)
                S1 = new MachineAssign();
                S1.Assigning(constructionSolution);
                population.add(constructionSolution);
                pop_make.add(S1.makespan);
                //   System.out.println(+S1.makespan + "\t" + S1.flowtime);

                double R = Math.random();
                if (R <= 0.49) {
                    int rand1 = 0;
                    int rand2 = 0;
                    do {

                        rand1 = getRandomNumberInRange(0, GraphSimulation.noftasks - 1);
                        rand2 = getRandomNumberInRange(0, GraphSimulation.noftasks - 1);

                    } while (rand1 == rand2 || (!(GraphSimulation.level[rand1] == GraphSimulation.level[rand2])));

                    int temp2 = constructionSolution[rand1];
                    constructionSolution[rand1] = constructionSolution[rand2];
                    constructionSolution[rand2] = temp2;

                    S1 = new MachineAssign();
                    S1.Assigning(constructionSolution);
                    population.add(constructionSolution);
                    pop_make.add(S1.makespan);
                    //  pop_make.add(S1.makespan);
                    // System.out.println(+S1.makespan + "\t" + S1.flowtime);

                } else {
                    int rand1 = 0;
                    int rand2 = 0;

                    do {

                        rand1 = getRandomNumberInRange(0, GraphSimulation.noftasks - 1);
                        rand2 = getRandomNumberInRange(0, GraphSimulation.noftasks - 1);

                    } while (rand1 == rand2 || (!(GraphSimulation.level[rand1] == GraphSimulation.level[rand2])));

                    int temp2 = constructionSolution[rand1];
                    constructionSolution[rand1] = constructionSolution[rand2];
                    constructionSolution[rand2] = temp2;

                    S1 = new MachineAssign();
                    S1.Assigning(constructionSolution);
                    population.add(constructionSolution);
                    pop_make.add(S1.makespan);
                    //   System.out.println(+S1.makespan + "\t" + S1.flowtime);

                }


                // calculate acceptance probability
                double d = S0.makespan - S1.makespan;
                double RR = Math.random();
                if (d > 0) {
                    S0.makespan = S1.makespan;
                    population.add(constructionSolution);
                    pop_make.add(S0.makespan);

                    // System.out.println(+S0.makespan + "\t" + S0.flowtime);
                    T = T - 1;
                    // System.out.println(T + "\t" );

                } else if (RR < Math.exp(d / T)) {
                    S0.makespan = S1.makespan;
                    population.add(constructionSolution);
                    pop_make.add(S0.makespan);
                    // pop_make.add(S0.makespan);

                    //  System.out.println(+S0.makespan + "\t" + S0.flowtime);
                    T = (int) (T * r);
                    //System.out.println(T + "\t" );
                } else {
                    T = (int) (T * r);
                    //    System.out.println(T + "\t" );
                }
                T = (int) (T * r);
                //  System.out.println(T + "\t" );
                // temp decrease
            } else {

                S0.Assigning(constructionSolution);
                population.add(constructionSolution);
                pop_make.add(S0.makespan);

                //  System.out.println(+S0.makespan + "\t" + S0.flowtime);

            }
        }

        bestMake = pop_make.get(0);
        for (int i = 1; i < pop_make.size(); i++) {
            if (bestMake > pop_make.get(i)) {
                bestMake = pop_make.get(i);
            }
        }
//            double Resource_Utilization  = S0.calculateBeta(MachineAssign.nofprocessors); 
//          //  System.out.println("Beta \t"+Resource_Utilization);
//            // System.out.println("================== Multi_objectives =======================");
//             System.out.println(bestMake +"\t" + Resource_Utilization+"\t"+S0.calculateMOF(bestMake, Resource_Utilization) + "\t" );

//
                  
//                   for (int x :constructionSolution){
//         
//                    System.out.print(" T" + x+ "  ");
//                   }
//               MachineAssign  s = new MachineAssign();
//           s.Assigning(constructionSolution);
//           System.out.println(+s.makespan );
                 
//     if (S1.makespan > S0.makespan) {
//                bestSol =  constructionSolution.clone();
//                bestMake = S0.makespan;
//                 System.out.println("    make: " + bestMake );
//               
//          
//    }}
//         if (bestMake > S0.makespan) {
//                bestSol = constructionSolution.clone();
//                bestMake = S0.makespan;
//             System.out.println(+bestMake + "\t");
//             
//                
//            } else if (bestMake > S1.makespan) {
//                bestSol = constructionSolution.clone();
//                bestMake = S1.makespan;
//                  System.out.println(+bestMake + "\t");
//            }
    }


    // random number generation
    public int getRandomNumberInRange(int min, int max) {
        if (min >= max) {
            throw new IllegalArgumentException("max must be greater than min");
        }
        Random r = new Random();
        return r.nextInt((max - min) + 1) + min;
    }


    public static void main(String[] args) {
    //   for(int j=0;j<=20;j++){
//          int avgRunTime = 0;
//          int avgMake = 0;
//          long totalTime = 0;
        ArrayList<Double> bestMake = new ArrayList<>();
        // long startTime = System.currentTimeMillis();
        int noRuns = 20;
        try {
            for (int i = 0; i < noRuns; i++) {
           //     System.out.println("run: #" + (i + 1) + " processing...");
                //  long startTime = System.currentTimeMillis();
                Greedy_SA cp = new Greedy_SA();
               // int[] input = new GraphUtils().Bottom_Descending().clone();
                 // int[] input = new GraphUtils().Top_Ascending().clone();
              int[] input = new GraphUtils().CriticalPath_Descending().clone();
                cp.construct(input);
                cp.SearchSimulated();
                bestMake.add(cp.bestMake);
          
//                long endTime = System.currentTimeMillis();
//                long time = endTime - startTime;
//                totalTime += time;
//                System.out.print(  totalTime+"\t");
               // System.out.println("run: #" + (i + 1) + " processing done");
            }
        } catch (Exception e) {
            e.printStackTrace();
        }

        System.out.println(bestMake + "\t");
        double sumOfBestMake = 0;
        for (double d : bestMake) {
            sumOfBestMake += d;
        }
        double avgBestMake = sumOfBestMake / noRuns;
        System.out.println("Avg Best Make\t:: " + avgBestMake);
        System.out.println("Min Best Make\t:: " + bestMake.get(ArrayUtils.getIndexOfMinimum(bestMake)));
        System.out.println("Max Best Make\t:: " + bestMake.get(ArrayUtils.getIndexOfMaximum(bestMake)));
        // avgRunTime = (int) (totalTime / 30);
        //  System.out.println("Avg Running Time \t:: " + avgRunTime);
        
    }
          
  //  }
}