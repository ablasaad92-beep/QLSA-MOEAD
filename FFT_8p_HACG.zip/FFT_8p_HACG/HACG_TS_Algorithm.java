package FFT_8p_HACG;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;

import java.io.IOException;
import java.io.StringWriter;
import java.util.*;

class Schedule {
    int[] taskOrder;
    double makespan;
    double utilization;
    double fitness;
    double lambda;
    
    public Schedule(int[] taskOrder, double makespan, double utilization, double fitness, double lambda) {
        this.taskOrder = taskOrder;
        this.makespan = makespan;
        this.utilization = utilization;
        this.fitness = fitness;
        this.lambda = lambda;
    }
}

public class HACG_TS_Algorithm {
    private int populationSize = 100;
    private int tournamentSize = 5;
    private GraphUtils graphUtils;
    private MachineAssign machineAssign;
    
    public HACG_TS_Algorithm() {
        this.machineAssign = new MachineAssign();
        this.graphUtils = new GraphUtils();
    }
    
   public void runAlgorithm(List<String> outputData) {
    List<Schedule> population = new ArrayList<>();
    Random random = new Random();
    
    double[] lambdaValues = new double[populationSize];
    for (int i = 0; i < populationSize; i++) {
        lambdaValues[i] = (double) i / (populationSize - 1);
    }

    for (int i = 0; i < populationSize; i++) {
        int[] taskOrder = graphUtils.random_population();
        if (taskOrder == null || taskOrder.length == 0) {
            throw new RuntimeException("Error: random_population() returned null or empty array");
        }

        double lambda = lambdaValues[i];
        machineAssign.Assigning(taskOrder);

        double makespan = machineAssign.makespan;
        double utilization = machineAssign.calculateBeta(MachineAssign.nofprocessors);
        double mof = (lambda * makespan) + ((1 - lambda) * (1 / utilization));

        population.add(new Schedule(taskOrder, makespan, utilization, mof, lambda));
    }

    for (int generation = 0; generation < 100; generation++) {
        population.sort(Comparator.comparingDouble(s -> s.fitness));
        
        Schedule bestSchedule = population.get(0);
        
        // ✅ تخزين القيم في الذاكرة بدلاً من الكتابة في ملف
        outputData.add(bestSchedule.makespan + ", " + bestSchedule.utilization);

        List<Schedule> selectedSchedules = new ArrayList<>();
        for (int i = 0; i < populationSize / 2; i++) {
            selectedSchedules.add(tournamentSelection(population));
        }

        List<Schedule> improvedSchedules = new ArrayList<>();
        for (Schedule schedule : selectedSchedules) {
            improvedSchedules.add(spiralSearch(schedule));
        }

        List<Schedule> crossoverSchedules = new ArrayList<>();
        for (int i = 0; i < improvedSchedules.size() - 1; i += 2) {
            if (random.nextDouble() < 0.7) {
                Schedule[] children = crossover(improvedSchedules.get(i), improvedSchedules.get(i + 1));
                crossoverSchedules.add(children[0]);
                crossoverSchedules.add(children[1]);
            } else {
                crossoverSchedules.add(improvedSchedules.get(i));
                crossoverSchedules.add(improvedSchedules.get(i + 1));
            }
        }

        List<Schedule> mutatedSchedules = new ArrayList<>();
        for (Schedule schedule : crossoverSchedules) {
            if (random.nextDouble() < 0.3) {
                Schedule mutated = mutate(schedule);
                mutatedSchedules.add(mutated);
            } else {
                mutatedSchedules.add(schedule);
            }
        }

        population = new ArrayList<>(mutatedSchedules.subList(0, Math.min(100, mutatedSchedules.size())));
    }
}

    
    private Schedule tournamentSelection(List<Schedule> population) {
        List<Schedule> tournament = new ArrayList<>();
        Random random = new Random();
        for (int i = 0; i < tournamentSize; i++) {
            tournament.add(population.get(random.nextInt(population.size())));
        }
        return Collections.min(tournament, Comparator.comparingDouble(s -> s.fitness));
    }

    private boolean validateConstruction(int[] constructionSolution) {
        if (constructionSolution == null || constructionSolution.length == 0) {
            return false;
        }
        for (int i = 0; i < constructionSolution.length; i++) {
            if (constructionSolution[i] < 0) {
                return false; // تأكد من عدم وجود قيم سلبية
            }
        }
        return checkValid(constructionSolution);
    }
    
    private boolean checkValid(int[] constructionSolution) {
        for (int i = 0; i < constructionSolution.length; i++) {
            for (int ii = i + 1; ii < constructionSolution.length; ii++) {
                if (GraphSimulation.level[constructionSolution[i]] > GraphSimulation.level[constructionSolution[ii]]) {
                    return false;
                }
            }
        }
        return true;
    }
        private Schedule spiralSearch(Schedule schedule) {
        int[] modifiedTaskOrder = schedule.taskOrder.clone();
        Random random = new Random();
        for (int i = 0; i < modifiedTaskOrder.length * 0.2; i++) {
            int idx1 = random.nextInt(modifiedTaskOrder.length);
            int idx2 = random.nextInt(modifiedTaskOrder.length);
            while (idx1 == idx2) {
                idx2 = random.nextInt(modifiedTaskOrder.length);
            }
            int temp = modifiedTaskOrder[idx1];
            modifiedTaskOrder[idx1] = modifiedTaskOrder[idx2];
            modifiedTaskOrder[idx2] = temp;
        }
        if (validateConstruction(modifiedTaskOrder)) {
            machineAssign.Assigning(modifiedTaskOrder);
            double beta = machineAssign.calculateBeta(MachineAssign.nofprocessors);
            return new Schedule(modifiedTaskOrder, machineAssign.makespan, beta, (schedule.lambda * machineAssign.makespan) + ((1 - schedule.lambda) * (1 / beta)), schedule.lambda);
        }
        return schedule;
    }
    
      private Schedule[] crossover(Schedule parent1, Schedule parent2) {
        int length = parent1.taskOrder.length;
        int crossoverPoint = new Random().nextInt(length);
        
        int[] son = new int[length];
        int[] daughter = new int[length];
        
        Arrays.fill(son, -1);
        Arrays.fill(daughter, -1);
        
        System.arraycopy(parent1.taskOrder, 0, son, 0, crossoverPoint);
        System.arraycopy(parent2.taskOrder, 0, daughter, 0, crossoverPoint);
        
        Set<Integer> sonSet = new HashSet<>();
        Set<Integer> daughterSet = new HashSet<>();
        
        for (int i = 0; i < crossoverPoint; i++) {
            sonSet.add(son[i]);
            daughterSet.add(daughter[i]);
        }
        
        int sonIndex = crossoverPoint;
        int daughterIndex = crossoverPoint;
        
        for (int i = 0; i < length; i++) {
            if (!sonSet.contains(parent2.taskOrder[i]) && sonIndex < length) {
                son[sonIndex++] = parent2.taskOrder[i];
                sonSet.add(parent2.taskOrder[i]);
            }
            if (!daughterSet.contains(parent1.taskOrder[i]) && daughterIndex < length) {
                daughter[daughterIndex++] = parent1.taskOrder[i];
                daughterSet.add(parent1.taskOrder[i]);
            }
        }
        
        if (sonIndex < length || daughterIndex < length) {
            throw new RuntimeException("Error: Crossover resulted in incomplete task order");
        }
        
        Schedule child1 = new Schedule(son, parent1.makespan, parent1.utilization, parent1.fitness, parent1.lambda);
        Schedule child2 = new Schedule(daughter, parent2.makespan, parent2.utilization, parent2.fitness, parent2.lambda);
        
        return new Schedule[]{child1, child2};
    }
    
    private Schedule mutate(Schedule schedule) {
        int[] mutatedTaskOrder = schedule.taskOrder.clone();
        Random random = new Random();
        int idx1 = random.nextInt(mutatedTaskOrder.length);
        int idx2 = random.nextInt(mutatedTaskOrder.length);
        while (idx1 == idx2) {
            idx2 = random.nextInt(mutatedTaskOrder.length);
        }
        int temp = mutatedTaskOrder[idx1];
        mutatedTaskOrder[idx1] = mutatedTaskOrder[idx2];
        mutatedTaskOrder[idx2] = temp;
        if (validateConstruction(mutatedTaskOrder)) {
            machineAssign.Assigning(mutatedTaskOrder);
            double beta = machineAssign.calculateBeta(MachineAssign.nofprocessors);
            return new Schedule(mutatedTaskOrder, machineAssign.makespan, beta, (schedule.lambda * machineAssign.makespan) + ((1 - schedule.lambda) * (1 / beta)), schedule.lambda);
        }
        return schedule;
    }
    


   
       
    }  
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    







