package FFT_8p_HACG;


import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.logging.Level;
import java.util.logging.Logger;
import java.util.stream.Stream;

public class EfficientOptimalSet {
    

    public static void main(String[] args) throws IOException, CloneNotSupportedException {
    // Specify the file path
 String allRunsfile = "optimalset_FFT_8p_1.0_HACG.txt";

          List<String> runData = new ArrayList<>();
       List<ParetoSolution> allSolutions = new ArrayList<>();
             
                 // مسح محتوى الملف عند بدء التشغيل
         new FileWriter(allRunsfile, false).close();
         //  System.out.println("✅ تم مسح محتوى الملف: " + allRunsfile);
    

             for (int run = 1; run <= 50; run++) {
                HACG_TS_Algorithm algorithm = new HACG_TS_Algorithm();
                runData.clear(); 
                
                 algorithm.runAlgorithm(runData);
                List<ParetoSolution> solutions = parseData(runData);
              //  System.out.println("عدد الحلول في التشغيل " + run + ": " + solutions.size());
                allSolutions.addAll(solutions);
                try (BufferedWriter write = new BufferedWriter(new FileWriter(allRunsfile, true))) { // append mode
    for (ParetoSolution sol : solutions) {
        write.write(sol.minimizeObjective + ", " + sol.maximizeObjective);
        write.newLine();
    }
} catch (IOException e) {
    e.printStackTrace();
}               

                 System.out.println("Run Comleted  ::"+run);     
             }}
    
 static List<ParetoSolution> parseData(List<String> data) {
       List<ParetoSolution> solutions = new ArrayList<>();
       for (String line : data) {
           line = line.trim();
           if (line.isEmpty()) continue;

        
        String[] values = line.split("\\s*[ ,]\\s*");
           if (values.length < 2) continue;

           try {
               double minimizeObjective = Double.parseDouble(values[0].trim());
               double maximizeObjective = Double.parseDouble(values[1].trim());
               solutions.add(new ParetoSolution(minimizeObjective, maximizeObjective));
           } catch (NumberFormatException e) {
               System.err.println("تخطي سطر غير صالح: " + line);
           }
       }
       return solutions;
   }

    static List<ParetoSolution> filterNonDominated(List<ParetoSolution> solutions) {
        List<ParetoSolution> nonDominatedSet = new ArrayList<>();
        
        for (ParetoSolution candidate : solutions) {
            if (!isDominated(candidate, nonDominatedSet)) {
                nonDominatedSet.add(candidate);
            }
        }
        return nonDominatedSet;
    }

    static boolean isDominated(ParetoSolution candidate, List<ParetoSolution> existingSet) {
        for (ParetoSolution solution : existingSet) {
            if (solution.minimizeObjective <= candidate.minimizeObjective
                    && solution.maximizeObjective >= candidate.maximizeObjective) {
                return true;
            }
        }
        return false;
    }
    
        private static String readFile(String filename) {
        StringBuilder content = new StringBuilder();
        try (BufferedReader reader = new BufferedReader(new FileReader(filename))) {
            String line;
            while ((line = reader.readLine()) != null) {
                content.append(line).append("\n");
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
        return content.toString();
    }
   public static Set<ParetoSolution> findParetoFront(List<ParetoSolution> solutions) {
    Set<ParetoSolution> paretoFront = new HashSet<>();
    
    for (ParetoSolution candidate : solutions) {
        boolean dominated = false;
        
        for (ParetoSolution other : solutions) {
            if ((other.minimizeObjective <= candidate.minimizeObjective && other.maximizeObjective >= candidate.maximizeObjective)) {
                if (other.minimizeObjective < candidate.minimizeObjective || other.maximizeObjective > candidate.maximizeObjective) {
                    dominated = true;
                    break;
                }
            }
        }
        
        if (!dominated) {
            paretoFront.add(candidate);
            System.out.println("Added to Pareto Front: " + candidate.minimizeObjective + ", " + candidate.maximizeObjective);
        }
    }
    
    System.out.println("Final Pareto Front size: " + paretoFront.size());
    return paretoFront;
}

public static List<ParetoSolution> readDataFromFile(String filePath) {
    List<ParetoSolution> solutions = new ArrayList<>();
    try (BufferedReader br = new BufferedReader(new FileReader(filePath))) {
        String line;
        while ((line = br.readLine()) != null) {
            line = line.trim();
            if (!line.isEmpty() && !line.contains("---")) {
                String[] parts = line.split("\\s*[ ,]\\s*");
                
        
                // التحقق من أن السطر يحتوي على قيمتين قبل التحليل
                if (parts.length < 2) {
                    System.err.println("Skipping invalid line: " + line);
                    continue;
                }

                try {
                    double obj1 = Double.parseDouble(parts[0].trim());
                    double obj2 = Double.parseDouble(parts[1].trim());
                    solutions.add(new ParetoSolution(obj1, obj2));
                } catch (NumberFormatException e) {
                    System.err.println("Skipping line due to format error: " + line);
                }
            }
        }
    } catch (IOException e) {
        e.printStackTrace();
    }
    return solutions;
}

public static void writeParetoFrontToFile(Set<ParetoSolution> paretoFront, String filePath) {
    try (BufferedWriter writer = new BufferedWriter(new FileWriter(filePath))) {
        for (ParetoSolution s : paretoFront) {
            writer.write(s.minimizeObjective + ", " + s.maximizeObjective);
            writer.newLine();
        }
    } catch (IOException e) {
        e.printStackTrace();
    }
}
public static double[][] convertSolutionsToArray(List<ParetoSolution> solutions) {
    double[][] array = new double[solutions.size()][2]; // مصفوفة بحجم الحلول
    for (int i = 0; i < solutions.size(); i++) {
        array[i][0] = solutions.get(i).minimizeObjective;
        array[i][1] = solutions.get(i).maximizeObjective;
    }
    return array;
}
public static void writeParetoFrontToFile(List<ParetoSolution> paretoFront, String filePath) {
    try (BufferedWriter writer = new BufferedWriter(new FileWriter(filePath))) {
        for (ParetoSolution sol : paretoFront) {
            writer.write(sol.minimizeObjective + ", " + sol.maximizeObjective);
            writer.newLine();
        }
    } catch (IOException e) {
        e.printStackTrace();
    }
}
public static List<ParetoSolution> readSolutionsFromFile(String filePath) {
    List<ParetoSolution> solutions = new ArrayList<>();
    try (BufferedReader br = new BufferedReader(new FileReader(filePath))) {
        String line;
        while ((line = br.readLine()) != null) {
            line = line.trim();
            if (line.isEmpty()) continue;

            String[] parts = line.split("\\s*,\\s*"); // يفصل باستخدام الفاصلة
            if (parts.length < 2) continue;

            try {
                double obj1 = Double.parseDouble(parts[0]);
                double obj2 = Double.parseDouble(parts[1]);
                solutions.add(new ParetoSolution(obj1, obj2));
            } catch (NumberFormatException e) {
                System.err.println("Skipping invalid line: " + line);
            }
        }
    } catch (IOException e) {
        e.printStackTrace();
    }
    return solutions;
}
public static List<ParetoSolution> readParetoSolutionsFromFile(String filePath) {
        List<ParetoSolution> solutions = new ArrayList<>();

        try (Stream<String> lines = Files.lines(Paths.get(filePath))) {
            lines.forEach(line -> {
                String[] parts = line.split("\\s+"); // Assuming space-separated values
                double minimizeObjective = Double.parseDouble(parts[0]);
                double maximizeObjective = Double.parseDouble(parts[1]);
                solutions.add(new ParetoSolution(minimizeObjective, maximizeObjective));
            });
        } catch (Exception e) {
            e.printStackTrace();
        }

        return solutions;
    }
}




