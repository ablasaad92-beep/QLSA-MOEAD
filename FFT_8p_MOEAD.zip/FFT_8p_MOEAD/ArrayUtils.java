/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package FFT_8p_MOEAD;


import java.util.ArrayList;

/**
 * @author Eng.Aplaa Saad
 */
public class ArrayUtils {
    private ArrayUtils() {
    }

    public static int getIndex(int[] arr, int b) {
        if (arr == null) {
            return -1;
        }
        int len = arr.length;
        int i;
        for (i = 0; i < len; i++) {
            if (arr[i] == b) {
                break;
            }
        }
        if (i == len) {
            return -1;
        } else {
            return i;
        }
    }

    public static int getIndexOfMinimum(double[] arr) {
        if (arr == null) {
            return -1;
        }
        int len = arr.length;
        int minIndex = 0;
        double min = arr[0];
        for (int i = 1; i < len; i++) {
            if (arr[i] < min) {
                min = arr[i];
                minIndex = i;
            }
        }
        return minIndex;
    }

    public static int getIndexOfMinimum(int[] arr) {
        if (arr == null) {
            return -1;
        }
        int len = arr.length;
        int minIndex = 0;
        int min = arr[0];
        for (int i = 1; i < len; i++) {
            if (arr[i] < min) {
                min = arr[i];
                minIndex = i;
            }
        }
        return minIndex;
    }

    public static int getIndexOfMinimum(ArrayList<Double> arr) {
        if (arr == null) {
            return -1;
        }
        int len = arr.size();
        int minIndex = 0;
        double min = arr.get(0);
        for (int i = 1; i < len; i++) {
            if (arr.get(i) < min) {
                min = arr.get(0);
                minIndex = i;
            }
        }
        return minIndex;
    }

    public static int getIndexOfMaximum(double[] arr) {
        if (arr == null) {
            return -1;
        }
        int len = arr.length;
        int maxIndex = 0;
        double max = arr[0];
        for (int i = 1; i < len; i++) {
            if (arr[i] > max) {
                max = arr[i];
                maxIndex = i;
            }
        }
        return maxIndex;
    }

    public static int getIndexOfMaximum(ArrayList<Double> arr) {
        if (arr == null) {
            return -1;
        }
        int len = arr.size();
        int maxIndex = 0;
        double max = arr.get(0);
        for (int i = 1; i < len; i++) {
            if (arr.get(i) > max) {
                max = arr.get(i);
                maxIndex = i;
            }
        }
        return maxIndex;
    }

    public static double getArraySum(double[] arr) {
        if (arr == null) {
            return -1;
        }
        if (arr.length == 0) {
            return 0;
        }
        double sum = arr[0];
        for (int i = 1; i < arr.length; i++) {
            sum += arr[i];
        }
        return sum;
    }

    public static double[][] descendingOrder(double[] arr) {
        double[][] ordered = new double[arr.length][2];
        for (int i = 0; i < arr.length; i++) {
            ordered[i][0] = arr[i];
            ordered[i][1] = i;
        }
        for (int i = 0, j = ordered.length - 1; i < j; i++, j--) {
            if (ordered[i][0] < ordered[j][0]) {
                double tmpVal = ordered[i][0];
                double tmpIndex = ordered[i][1];
                ordered[i][0] = ordered[j][0];
                ordered[i][1] = ordered[j][1];
                ordered[j][0] = tmpVal;
                ordered[j][1] = tmpIndex;
            }
        }
        return ordered;
    }

}
