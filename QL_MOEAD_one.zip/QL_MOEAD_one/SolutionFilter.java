package QL_MOEAD_one;





import java.io.BufferedWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;


/**
 * Represents a solution with minimize and maximize objectives for Pareto optimization.
 */
class ParetoSolution {
    double minimizeObjective;
    double maximizeObjective;

    /**
     * Constructs a ParetoSolution with given minimize and maximize objectives.
     *
     * @param minimizeObjective The minimize objective value.
     * @param maximizeObjective The maximize objective value.
     */
    public ParetoSolution(double minimizeObjective, double maximizeObjective) {
        this.minimizeObjective = minimizeObjective;
        this.maximizeObjective = maximizeObjective;
    }

    /**
     * Converts a list of Solution objects to a list of ParetoSolution objects.
     *
     * @param pop The list of Solution objects.
     * @return A list of ParetoSolution objects converted from the provided Solution objects.
     */
    static List<ParetoSolution> getMakeSpanUtilization(ArrayList<Solution> pop) {
        ArrayList<ParetoSolution> paretoSolutions = new ArrayList<>();

        for (Solution s : pop) {
            paretoSolutions.add(new ParetoSolution(s.makeSpan, s.resourceUtilization));
        }
        return paretoSolutions;
    }

    /**
     * Writes the ParetoSolution to a CSV file.
     *
     * @param writer The BufferedWriter to write to.
     * @throws IOException If an I/O error occurs.
     */
    void writeToFile(BufferedWriter writer) throws IOException {
        writer.write(minimizeObjective + "," + maximizeObjective);
        writer.newLine();
    }


    @Override
    public boolean equals(Object obj) {
        if (this == obj) return true;
        if (obj == null || getClass() != obj.getClass()) return false;

        ParetoSolution that = (ParetoSolution) obj;

        return Double.compare(that.minimizeObjective, minimizeObjective) == 0 && Double.compare(that.maximizeObjective, maximizeObjective) == 0;
    }

    @Override
    public int hashCode() {
        int result;
        long temp;
        temp = Double.doubleToLongBits(minimizeObjective);
        result = (int) (temp ^ (temp >>> 32));
        temp = Double.doubleToLongBits(maximizeObjective);
        result = 31 * result + (int) (temp ^ (temp >>> 32));
        return result;
    }
}

/**
 * Provides methods for filtering solutions based on different criteria in a multi-run Pareto optimization.
 */
public class SolutionFilter {

    /**
     * Finds solutions based on specified criteria in a list of Pareto solutions.
     *
     * @param allRuns               A list of Pareto solutions.
     * @param checkMaxObjectiveOnly Flag indicating whether to include solutions with the maximum objective.
     * @param checkMinObjectiveOnly Flag indicating whether to include solutions with the minimum objective.
     * @param includeBothObjectives Flag indicating whether to include solutions that have both maximum and minimum objectives.
     * @return A list of Pareto solutions based on the specified criteria.
     */
    public static List<ParetoSolution> findBestSolutionsByCriteria(List<ParetoSolution> allRuns, Boolean checkMaxObjectiveOnly, Boolean checkMinObjectiveOnly, Boolean includeBothObjectives) {
        List<ParetoSolution> result = new ArrayList<>();

        if (Boolean.TRUE.equals(checkMaxObjectiveOnly)) {
            result.addAll(findMaxObjectiveSolutions(allRuns));
        }

        if (Boolean.TRUE.equals(checkMinObjectiveOnly)) {
            result.addAll(findMinObjectiveSolutions(allRuns));
        }

        if (Boolean.TRUE.equals(includeBothObjectives)) {
            result.addAll(findMaxOrMinOrBothObjectiveSolutions(allRuns));
        }

        return result;
    }

    /**
     * Finds solutions with the maximum objective in a list of Pareto solutions.
     *
     * @param allRuns A list of Pareto solutions.
     * @return A list of Pareto solutions with the maximum objective.
     */
    public static List<ParetoSolution> findMaxObjectiveSolutions(List<ParetoSolution> allRuns) {
        double maxObjective = Double.NEGATIVE_INFINITY;
        ParetoSolution referenceSolution = allRuns.get(0);

        List<ParetoSolution> maxObjectiveSolutions = new ArrayList<>();

        for (ParetoSolution solution : allRuns) {
            if (solution.maximizeObjective > maxObjective) {
                maxObjective = solution.maximizeObjective;
                referenceSolution = solution;
            } else if (solution.maximizeObjective == maxObjective && solution.minimizeObjective < referenceSolution.minimizeObjective) {
                referenceSolution = solution;
            }
        }

        for (ParetoSolution solution : allRuns) {
            if (solution.maximizeObjective == maxObjective) {
                maxObjectiveSolutions.add(solution);
            }
        }

        return maxObjectiveSolutions;
    }

    /**
     * Finds solutions with the minimum objective in a list of Pareto solutions.
     *
     * @param allRuns A list of Pareto solutions.
     * @return A list of Pareto solutions with the minimum objective.
     */
    public static List<ParetoSolution> findMinObjectiveSolutions(List<ParetoSolution> allRuns) {
        double minObjective = Double.POSITIVE_INFINITY;
        ParetoSolution referenceSolution = allRuns.get(0);

        List<ParetoSolution> minObjectiveSolutions = new ArrayList<>();

        for (ParetoSolution solution : allRuns) {
            if (solution.minimizeObjective < minObjective) {
                minObjective = solution.minimizeObjective;
                referenceSolution = solution;
            } else if (solution.minimizeObjective == minObjective && solution.maximizeObjective > referenceSolution.maximizeObjective) {
                referenceSolution = solution;
            }
        }
        for (ParetoSolution solution : allRuns) {
            if (solution.equals(referenceSolution)) {
                minObjectiveSolutions.add(solution);
            }
        }

        return minObjectiveSolutions;
    }

    /**
     * Finds solutions that have both the maximum and minimum objectives in a list of Pareto solutions.
     *
     * @param allRuns A list of Pareto solutions.
     * @return A list of Pareto solutions that have both maximum and minimum objectives.
     */
    public static List<ParetoSolution> findMaxOrMinOrBothObjectiveSolutions(List<ParetoSolution> allRuns) {
        Set<ParetoSolution> result = new HashSet<>();

        List<ParetoSolution> maxObjectiveSolutions = findMaxObjectiveSolutions(allRuns);
        List<ParetoSolution> minObjectiveSolutions = findMinObjectiveSolutions(allRuns);

        // Include solutions that have both max and min objectives
        for (ParetoSolution maxObjectiveSolution : maxObjectiveSolutions) {
            if (minObjectiveSolutions.contains(maxObjectiveSolution)) {
                result.add(maxObjectiveSolution);
            }
        }

        // Include solutions with max objective
        result.addAll(maxObjectiveSolutions);

        // Include solutions with min objective
        result.addAll(minObjectiveSolutions);

        return new ArrayList<>(result);
    }
}