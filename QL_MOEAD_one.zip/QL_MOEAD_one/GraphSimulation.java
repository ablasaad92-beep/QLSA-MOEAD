/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package QL_MOEAD_one;

/**
 *
 * @author Aplaa Saad
 */


import java.util.Arrays;
import java.util.Random;
import java.util.Scanner;
import java.util.concurrent.ThreadLocalRandom;
//import static phd.ProcessorAssign.nofprocessors;

public class GraphSimulation {
    
     public static int noftasks;
    public static int nofedges;
    public int noflevels;
    public int communication[];
    public int execution[];
    public static int level[];
    int incedence[][];
     int[] listmemoization; // for recursion memoization
    int[] tlevels;
    public int execution_order[];// = {1, 0, 3, 2, 6, 4, 10, 5, 9, 7, 8}
     public int Candidate_List[];
    public String[] cadidatelist;
    private Scanner input = new Scanner(System.in);
     Random randomGenerator = new Random();
    
     // constructor   define attributes .......
    public GraphSimulation() {
//        System.out.print("Enter number of tasks	\n");
        noftasks = 34;// input.nextInt();
//        System.out.print("Enter number of Edges	\n");
        nofedges = 64;//input.nextInt();
        // System.out.print("Enter number of Levels	\n");
        // noflevels = input.nextInt();

        incedence = new int[noftasks][nofedges];
        communication = new int[nofedges];
        execution = new int[noftasks];
        level = new int[noftasks];
        listmemoization = new int[noftasks];
        tlevels = new int[noftasks];
        execution_order = new int[GraphSimulation.noftasks];

        fill_Communication();
//        fill_Execution();
        fill_Incedence();
        fill_levels();
       
    }

    //*****incedence matrix method *****//
    public void fill_Incedence() {

      //  for (int row = 0; row < noftasks; row++) {
       //     for (int col = 0; col < nofedges; col++) {

                incedence[0][0] = 1;
                incedence[0][1] = 1;
                incedence[0][2] = 1;
                incedence[0][3] = 1;
                incedence[0][4] = 1;
                incedence[0][5] = 1;
                incedence[0][6] = 1;
                incedence[0][7] = 1;
                incedence[0][8] = 0;
                incedence[0][9] = 0;
                
                incedence[0][10] = 0;
                incedence[0][11] = 0;
                incedence[0][12] = 0;
                incedence[0][13] = 0;
                incedence[0][14] = 0;
                incedence[0][15] = 0;
                incedence[0][16] = 0;
                incedence[0][17] = 0;
                incedence[0][18] = 0;
                incedence[0][19] = 0;
                
                incedence[0][20] = 0;
                incedence[0][21] = 0;
                incedence[0][22] = 0;
                incedence[0][23] = 0;
                incedence[0][24] = 0;
                incedence[0][25] = 0;
                incedence[0][26] = 0;
                incedence[0][27] = 0;
                incedence[0][28] = 0;
                incedence[0][29] = 0;
               
                incedence[0][30] = 0;
                incedence[0][31] = 0;
                incedence[0][32] = 0;
                incedence[0][33] = 0;
                incedence[0][34] = 0;
                incedence[0][35] = 0;
                incedence[0][36] = 0;
                incedence[0][37] = 0;
                incedence[0][38] = 0;
                incedence[0][39] = 0;

                incedence[0][40] = 0;
                incedence[0][41] = 0;
                incedence[0][42] = 0;
                incedence[0][43] = 0;
                incedence[0][44] = 0;
                incedence[0][45] = 0;
                incedence[0][46] = 0;
                incedence[0][47] = 0;
                incedence[0][48] = 0;
                incedence[0][49] = 0;

                incedence[0][50] = 0;
                incedence[0][51] = 0;
                incedence[0][52] = 0;
                incedence[0][53] = 0;
                incedence[0][54] = 0;
                incedence[0][55] = 0;
                incedence[0][56] = 0;
                incedence[0][57] = 0;
                incedence[0][58] = 0;
                incedence[0][59] = 0;

                incedence[0][60] = 0;
                incedence[0][61] = 0;
                incedence[0][62] = 0;
                incedence[0][63] = 0;
              
               
                /////****1 row

              
                incedence[1][0] = -1;
                incedence[1][1] = 0;
                incedence[1][2] = 0;
                incedence[1][3] = 0;
                incedence[1][4] = 0;
                incedence[1][5] = 0;
                incedence[1][6] = 0;
                incedence[1][7] = 0;
                incedence[1][8] = 1;
                incedence[1][9] = 1;
                
                incedence[1][10] = 0;
                incedence[1][11] = 0;
                incedence[1][12] = 0;
                incedence[1][13] = 0;
                incedence[1][14] = 0;
                incedence[1][15] = 0;
                incedence[1][16] = 0;
                incedence[1][17] = 0;
                incedence[1][18] = 0;
                incedence[1][19] = 0;
                
                incedence[1][20] = 0;
                incedence[1][21] = 0;
                incedence[1][22] = 0;
                incedence[1][23] = 0;
                incedence[1][24] = 0;
                incedence[1][25] = 0;
                incedence[1][26] = 0;
                incedence[1][27] = 0;
                incedence[1][28] = 0;
                incedence[1][29] = 0;
  
                incedence[1][30] = 0;
                incedence[1][31] = 0;
                incedence[1][32] = 0;
                incedence[1][33] = 0;
                incedence[1][34] = 0;
                incedence[1][35] = 0;
                incedence[1][36] = 0;
                incedence[1][37] = 0;
                incedence[1][38] = 0;
                incedence[1][39] = 0;

                incedence[1][40] = 0;
                incedence[1][41] = 0;
                incedence[1][42] = 0;
                incedence[1][43] = 0;
                incedence[1][44] = 0;
                incedence[1][45] = 0;
                incedence[1][46] = 0;
                incedence[1][47] = 0;
                incedence[1][48] = 0;
                incedence[1][49] = 0;

                incedence[1][50] = 0;
                incedence[1][51] = 0;
                incedence[1][52] = 0;
                incedence[1][53] = 0;
                incedence[1][54] = 0;
                incedence[1][55] = 0;
                incedence[1][56] = 0;
                incedence[1][57] = 0;
                incedence[1][58] = 0;
                incedence[1][59] = 0;

                incedence[1][60] = 0;
                incedence[1][61] = 0;
                incedence[1][62] = 0;
                incedence[1][63] = 0;
                
               
               
              
///****2row          

                
                incedence[2][0] = 0;
                incedence[2][1] =-1;
                incedence[2][2] = 0;
                incedence[2][3] = 0;
                incedence[2][4] = 0;
                incedence[2][5] = 0;
                incedence[2][6] = 0;
                incedence[2][7] = 0;
                incedence[2][8] = 0;
                incedence[2][9] = 0;
                
                incedence[2][10] = 1;
                incedence[2][11] = 1;
                incedence[2][12] = 0;
                incedence[2][13] = 0;
                incedence[2][14] = 0;
                incedence[2][15] = 0;
                incedence[2][16] = 0;
                incedence[2][17] = 0;
                incedence[2][18] = 0;
                incedence[2][19] = 0;
                
                incedence[2][20] = 0;
                incedence[2][21] = 0;
                incedence[2][22] = 0;
                incedence[2][23] = 0;
                incedence[2][24] = 0;
                incedence[2][25] = 0;
                incedence[2][26] = 0;
                incedence[2][27] = 0;
                incedence[2][28] = 0;
                incedence[2][29] = 0;
               
                incedence[2][30] = 0;
                incedence[2][31] = 0;
                incedence[2][32] = 0;
                incedence[2][33] = 0;
                incedence[2][34] = 0;
                incedence[2][35] = 0;
                incedence[2][36] = 0;
                incedence[2][37] = 0;
                incedence[2][38] = 0;
                incedence[2][39] = 0;

                incedence[2][40] = 0;
                incedence[2][41] = 0;
                incedence[2][42] = 0;
                incedence[2][43] = 0;
                incedence[2][44] = 0;
                incedence[2][45] = 0;
                incedence[2][46] = 0;
                incedence[2][47] = 0;
                incedence[2][48] = 0;
                incedence[2][49] = 0;

                incedence[2][50] = 0;
                incedence[2][51] = 0;
                incedence[2][52] = 0;
                incedence[2][53] = 0;
                incedence[2][54] = 0;
                incedence[2][55] = 0;
                incedence[2][56] = 0;
                incedence[2][57] = 0;
                incedence[2][58] = 0;
                incedence[2][59] = 0;
                incedence[2][60] = 0;
                incedence[2][61] = 0;
                incedence[2][62] = 0;
                incedence[2][63] = 0;
                
               
               ///****3row 

                incedence[3][0] = 0;
                incedence[3][1] = 0;
                incedence[3][2] = -1;
                incedence[3][3] = 0;
                incedence[3][4] = 0;
                incedence[3][5] = 0;
                incedence[3][6] = 0;
                incedence[3][7] = 0;
                incedence[3][8] = 0;
                incedence[3][9] = 0;
               
                incedence[3][10] =0;
                incedence[3][11] = 0;
                incedence[3][12] =1;
                incedence[3][13] = 1;
                incedence[3][14] = 0;
                incedence[3][15] = 0;
                incedence[3][16] = 0;
                incedence[3][17] = 0;
                incedence[3][18] = 0;
                incedence[3][19] = 0;
                
                incedence[3][20] = 0;
                incedence[3][21] = 0;
                incedence[3][22] = 0;
                incedence[3][23] = 0;
                incedence[3][24] = 0;
                incedence[3][25] = 0;
                incedence[3][26] = 0;
                incedence[3][27] = 0;
                incedence[3][28] = 0;
                incedence[3][29] = 0;
               
                incedence[3][30] = 0;
                incedence[3][31] = 0;
                incedence[3][32] = 0;
                incedence[3][33] = 0;
                incedence[3][34] = 0;
                incedence[3][35] = 0;
                incedence[3][36] = 0;
                incedence[3][37] = 0;
                incedence[3][38] = 0;
                incedence[3][39] = 0;

                incedence[3][40] = 0;
                incedence[3][41] = 0;
                incedence[3][42] = 0;
                incedence[3][43] = 0;
                incedence[3][44] = 0;
                incedence[3][45] = 0;
                incedence[3][46] = 0;
                incedence[3][47] = 0;
                incedence[3][48] = 0;
                incedence[3][49] = 0;

                incedence[3][50] = 0;
                incedence[3][51] = 0;
                incedence[3][52] = 0;
                incedence[3][53] = 0;
                incedence[3][54] = 0;
                incedence[3][55] = 0;
                incedence[3][56] = 0;
                incedence[3][57] = 0;
                incedence[3][58] = 0;
                incedence[3][59] = 0;

                incedence[3][60] = 0;
                incedence[3][61] = 0;
                incedence[3][62] = 0;
                incedence[3][63] = 0;
       
               
              ///****4row

                incedence[4][0] = 0;
                incedence[4][1] = 0;
                incedence[4][2] = 0;
                incedence[4][3] = -1;
                incedence[4][4] = 0;
                incedence[4][5] = 0;
                incedence[4][6] = 0;
                incedence[4][7] = 0;
                incedence[4][8] = 0;
                incedence[4][9] = 0;
                
                incedence[4][10] = 0;
                incedence[4][11] = 0;
                incedence[4][12] = 0;
                incedence[4][13] = 0;
                incedence[4][14] = 1;
                incedence[4][15] = 1;
                incedence[4][16] = 0;
                incedence[4][17] = 0;
                incedence[4][18] = 0;
                incedence[4][19] = 0;
                
                incedence[4][20] = 0;
                incedence[4][21] = 0;
                incedence[4][22] = 0;
                incedence[4][23] = 0;
                incedence[4][24] = 0;
                incedence[4][25] = 0;
                incedence[4][26] = 0;
                incedence[4][27] = 0;
                incedence[4][28] = 0;
                incedence[4][29] = 0;
               
                incedence[4][30] = 0;
                incedence[4][31] = 0;
                incedence[4][32] = 0;
                incedence[4][33] = 0;
                incedence[4][34] = 0;
                incedence[4][35] = 0;
                incedence[4][36] = 0;
                incedence[4][37] = 0;
                incedence[4][38] = 0;
                incedence[4][39] = 0;

                incedence[4][40] = 0;
                incedence[4][41] = 0;
                incedence[4][42] = 0;
                incedence[4][43] = 0;
                incedence[4][44] = 0;
                incedence[4][45] = 0;
                incedence[4][46] = 0;
                incedence[4][47] = 0;
                incedence[4][48] = 0;
                incedence[4][49] = 0;

                incedence[4][50] = 0;
                incedence[4][51] = 0;
                incedence[4][52] = 0;
                incedence[4][53] = 0;
                incedence[4][54] = 0;
                incedence[4][55] = 0;
                incedence[4][56] = 0;
                incedence[4][57] = 0;
                incedence[4][58] = 0;
                incedence[4][59] = 0;

                incedence[4][60] = 0;
                incedence[4][61] = 0;
                incedence[4][62] = 0;
                incedence[4][63] = 0;
    
               
               ///****5row 

              
                incedence[5][0] = 0;
                incedence[5][1] = 0;
                incedence[5][2] = 0;
                incedence[5][3] = 0;
                incedence[5][4] = -1;
                incedence[5][5] = 0;
                incedence[5][6] = 0;
                incedence[5][7] = 0;
                incedence[5][8] = 0;
                incedence[5][9] = 0;
                
                incedence[5][10] = 0;
                incedence[5][11] = 0;
                incedence[5][12] = 0;
                incedence[5][13] = 0;
                incedence[5][14] = 0;
                incedence[5][15] = 0;
                incedence[5][16] = 1;
                incedence[5][17] = 1;
                incedence[5][18] = 0;
                incedence[5][19] = 0;
               
                incedence[5][20] = 0;
                incedence[5][21] = 0;
                incedence[5][22] = 0;
                incedence[5][23] = 0;
                incedence[5][24] = 0;
                incedence[5][25] = 0;
                incedence[5][26] = 0;
                incedence[5][27] = 0;
                incedence[5][28] = 0;
                incedence[5][29] = 0;
               
                incedence[5][30] = 0;
                incedence[5][31] = 0;
                incedence[5][32] = 0;
                incedence[5][33] = 0;
                incedence[5][34] = 0;
                incedence[5][35] = 0;
                incedence[5][36] = 0;
                incedence[5][37] = 0;
                incedence[5][38] = 0;
                incedence[5][39] = 0;

                incedence[5][40] = 0;
                incedence[5][41] = 0;
                incedence[5][42] = 0;
                incedence[5][43] = 0;
                incedence[5][44] = 0;
                incedence[5][45] = 0;
                incedence[5][46] = 0;
                incedence[5][47] = 0;
                incedence[5][48] = 0;
                incedence[5][49] = 0;

                incedence[5][50] = 0;
                incedence[5][51] = 0;
                incedence[5][52] = 0;
                incedence[5][53] = 0;
                incedence[5][54] = 0;
                incedence[5][55] = 0;
                incedence[5][56] = 0;
                incedence[5][57] = 0;
                incedence[5][58] = 0;
                incedence[5][59] = 0;

                incedence[5][60] = 0;
                incedence[5][61] = 0;
                incedence[5][62] = 0;
                incedence[5][63] = 0;
        
                
                ///****6row                          

               
                incedence[6][0] = 0;
                incedence[6][1] = 0;
                incedence[6][2] = 0;
                incedence[6][3] = 0;
                incedence[6][4] = 0;
                incedence[6][5] = -1;
                incedence[6][6] = 0;
                incedence[6][7] = 0;
                incedence[6][8] = 0;
                incedence[6][9] = 0;
                
                incedence[6][10] = 0;
                incedence[6][11] = 0;
                incedence[6][12] = 0;
                incedence[6][13] = 0;
                incedence[6][14] = 0;
                incedence[6][15] = 0;
                incedence[6][16] = 0;
                incedence[6][17] = 0;
                incedence[6][18] =1;
                incedence[6][19] = 1;
                
                incedence[6][20] = 0;
                incedence[6][21] = 0;
                incedence[6][22] = 0;
                incedence[6][23] = 0;
                incedence[6][24] = 0;
                incedence[6][25] = 0;
                incedence[6][26] = 0;
                incedence[6][27] = 0;
                incedence[6][28] = 0;
                incedence[6][29] = 0;
               
                incedence[6][30] = 0;
                incedence[6][31] = 0;
                incedence[6][32] = 0;
                incedence[6][33] = 0;
                incedence[6][34] = 0;
                incedence[6][35] = 0;
                incedence[6][36] = 0;
                incedence[6][37] = 0;
                incedence[6][38] = 0;
                incedence[6][39] = 0;

                incedence[6][40] = 0;
                incedence[6][41] = 0;
                incedence[6][42] = 0;
                incedence[6][43] = 0;
                incedence[6][44] = 0;
                incedence[6][45] = 0;
                incedence[6][46] = 0;
                incedence[6][47] = 0;
                incedence[6][48] = 0;
                incedence[6][49] = 0;

                incedence[6][50] = 0;
                incedence[6][51] = 0;
                incedence[6][52] = 0;
                incedence[6][53] = 0;
                incedence[6][54] = 0;
                incedence[6][55] = 0;
                incedence[6][56] = 0;
                incedence[6][57] = 0;
                incedence[6][58] = 0;
                incedence[6][59] = 0;

                incedence[6][60] = 0;
                incedence[6][61] = 0;
                incedence[6][62] = 0;
                incedence[6][63] = 0;
   
               ///****7row                           
              
               
                incedence[7][0] = 0;
                incedence[7][1] = 0;
                incedence[7][2] = 0;
                incedence[7][3] = 0;
                incedence[7][4] = 0;
                incedence[7][5] = 0;
                incedence[7][6] = -1;
                incedence[7][7] = 0;
                incedence[7][8] = 0;
                incedence[7][9] = 0;
                
                incedence[7][10] = 0;
                incedence[7][11] = 0;
                incedence[7][12] = 0;
                incedence[7][13] = 0;
                incedence[7][14] = 0;
                incedence[7][15] = 0;
                incedence[7][16] = 0;
                incedence[7][17] = 0;
                incedence[7][18] = 0;
                incedence[7][19] = 0;
                
                incedence[7][20] = 1;
                incedence[7][21] = 1;
                incedence[7][22] = 0;
                incedence[7][23] = 0;
                incedence[7][24] = 0;
                incedence[7][25] = 0;
                incedence[7][26] = 0;
                incedence[7][27] = 0;
                incedence[7][28] = 0;
                incedence[7][29] = 0;
               
                incedence[7][30] = 0;
                incedence[7][31] = 0;
                incedence[7][32] = 0;
                incedence[7][33] = 0;
                incedence[7][34] = 0;
                incedence[7][35] = 0;
                incedence[7][36] = 0;
                incedence[7][37] = 0;
                incedence[7][38] = 0;
                incedence[7][39] = 0;

                incedence[7][40] = 0;
                incedence[7][41] = 0;
                incedence[7][42] = 0;
                incedence[7][43] = 0;
                incedence[7][44] = 0;
                incedence[7][45] = 0;
                incedence[7][46] = 0;
                incedence[7][47] = 0;
                incedence[7][48] = 0;
                incedence[7][49] = 0;
                incedence[7][50] = 0;
                incedence[7][51] = 0;
                incedence[7][52] = 0;
                incedence[7][53] = 0;
                incedence[7][54] = 0;
                incedence[7][55] = 0;
                incedence[7][56] = 0;
                incedence[7][57] = 0;
                incedence[7][58] = 0;
                incedence[7][59] = 0;
                incedence[7][60] = 0;
                incedence[7][61] = 0;
                incedence[7][62] = 0;
                incedence[7][63] = 0;
    
               ///****8row


                incedence[8][0] = 0;
                incedence[8][1] = 0;
                incedence[8][2] = 0;
                incedence[8][3] = 0;
                incedence[8][4] = 0;
                incedence[8][5] = 0;
                incedence[8][6] = 0;
                incedence[8][7] =-1;
                incedence[8][8] = 0;
                incedence[8][9] = 0;
                
                incedence[8][10] = 0;
                incedence[8][11] = 0;
                incedence[8][12] = 0;
                incedence[8][13] = 0;
                incedence[8][14] = 0;
                incedence[8][15] = 0;
                incedence[8][16] = 0;
                incedence[8][17] = 0;
                incedence[8][18] = 0;
                incedence[8][19] = 0;
                
                incedence[8][20] = 0;
                incedence[8][21] = 0;
                incedence[8][22] = 1;
                incedence[8][23] = 1;
                incedence[8][24] = 0;
                incedence[8][25] = 0;
                incedence[8][26] = 0;
                incedence[8][27] = 0;
                incedence[8][28] = 0;
                incedence[8][29] = 0;
              
                incedence[8][30] = 0;
                incedence[8][31] = 0;
                incedence[8][32] = 0;
                incedence[8][33] = 0;
                incedence[8][34] = 0;
                incedence[8][35] = 0;
                incedence[8][36] = 0;
                incedence[8][37] = 0;
                incedence[8][38] = 0;
                incedence[8][39] = 0;

                incedence[8][40] = 0;
                incedence[8][41] = 0;
                incedence[8][42] = 0;
                incedence[8][43] = 0;
                incedence[8][44] = 0;
                incedence[8][45] = 0;
                incedence[8][46] = 0;
                incedence[8][47] = 0;
                incedence[8][48] = 0;
                incedence[8][49] = 0;

                incedence[8][50] = 0;
                incedence[8][51] = 0;
                incedence[8][52] = 0;
                incedence[8][53] = 0;
                incedence[8][54] = 0;
                incedence[8][55] = 0;
                incedence[8][56] = 0;
                incedence[8][57] = 0;
                incedence[8][58] = 0;
                incedence[8][59] = 0;

                incedence[8][60] = 0;
                incedence[8][61] = 0;
                incedence[8][62] = 0;
                incedence[8][63] = 0;
    
              ////

                incedence[9][0] = 0;
                incedence[9][1] = 0;
                incedence[9][2] = 0;
                incedence[9][3] = 0;
                incedence[9][4] = 0;
                incedence[9][5] = 0;
                incedence[9][6] = 0;
                incedence[9][7] = 0;
                incedence[9][8] = -1;
                incedence[9][9] = 0;
                
                incedence[9][10] = -1;
                incedence[9][11] = 0;
                incedence[9][12] = 0;
                incedence[9][13] = 0;
                incedence[9][14] = 0;
                incedence[9][15] = 0;
                incedence[9][16] = 0;
                incedence[9][17] = 0;
                incedence[9][18] = 0;
                incedence[9][19] = 0;
                
                incedence[9][20] = 0;
                incedence[9][21] = 0;
                incedence[9][22] = 0;
                incedence[9][23] = 0;
                incedence[9][24] = 1;
                incedence[9][25] = 1;
                incedence[9][26] = 0;
                incedence[9][27] = 0;
                incedence[9][28] = 0;
                incedence[9][29] = 0;
               
                incedence[9][30] = 0;
                incedence[9][31] = 0;
                incedence[9][32] = 0;
                incedence[9][33] = 0;
                incedence[9][34] = 0;
                incedence[9][35] = 0;
                incedence[9][36] = 0;
                incedence[9][37] = 0;
                incedence[9][38] = 0;
                incedence[9][39] = 0;
                incedence[9][40] = 0;
                incedence[9][41] = 0;
                incedence[9][42] = 0;
                incedence[9][43] = 0;
                incedence[9][44] = 0;
                incedence[9][45] = 0;
                incedence[9][46] = 0;
                incedence[9][47] = 0;
                incedence[9][48] = 0;
                incedence[9][49] = 0;

                incedence[9][50] = 0;
                incedence[9][51] = 0;
                incedence[9][52] = 0;
                incedence[9][53] = 0;
                incedence[9][54] = 0;
                incedence[9][55] = 0;
                incedence[9][56] = 0;
                incedence[9][57] = 0;
                incedence[9][58] = 0;
                incedence[9][59] = 0;

                incedence[9][60] = 0;
                incedence[9][61] = 0;
                incedence[9][62] = 0;
                incedence[9][63] = 0;

              ///

                incedence[10][0] = 0;
                incedence[10][1] = 0;
                incedence[10][2] = 0;
                incedence[10][3] = 0;
                incedence[10][4] = 0;
                incedence[10][5] = 0;
                incedence[10][6] = 0;
                incedence[10][7] = 0;
                incedence[10][8] = 0;
                incedence[10][9] = -1;
                
                incedence[10][10] = 0;
                incedence[10][11] = -1;
                incedence[10][12] = 0;
                incedence[10][13] = 0;
                incedence[10][14] = 0;
                incedence[10][15] = 0;
                incedence[10][16] = 0;
                incedence[10][17] = 0;
                incedence[10][18] = 0;
                incedence[10][19] = 0;
                
                incedence[0][20] = 0;
                incedence[10][21] = 0;
                incedence[10][22] = 0;
                incedence[10][23] = 0;
                incedence[10][24] = 0;
                incedence[10][25] = 0;
                incedence[10][26] = 1;
                incedence[10][27] = 1;
                incedence[10][28] = 0;
                incedence[10][29] = 0;
               
                incedence[10][30] = 0;
                incedence[10][31] =0;
                incedence[10][32] = 0;
                incedence[10][33] = 0;
                incedence[10][34] = 0;
                incedence[10][35] = 0;
                incedence[10][36] = 0;
                incedence[10][37] = 0;
                incedence[10][38] = 0;
                incedence[10][39] = 0;

                incedence[10][40] = 0;
                incedence[10][41] = 0;
                incedence[10][42] = 0;
                incedence[10][43] = 0;
                incedence[10][44] = 0;
                incedence[10][45] = 0;
                incedence[10][46] = 0;
                incedence[10][47] = 0;
                incedence[10][48] = 0;
                incedence[10][49] = 0;

                incedence[10][50] = 0;
                incedence[10][51] = 0;
                incedence[10][52] = 0;
                incedence[10][53] = 0;
                incedence[10][54] = 0;
                incedence[10][55] = 0;
                incedence[10][56] = 0;
                incedence[10][57] = 0;
                incedence[10][58] = 0;
                incedence[10][59] = 0;

                incedence[10][60] = 0;
                incedence[10][61] = 0;
                incedence[10][62] = 0;
                incedence[10][63] = 0;
     
              //

                incedence[11][0] = 0;
                incedence[11][1] = 0;
                incedence[11][2] = 0;
                incedence[11][3] = 0;
                incedence[11][4] = 0;
                incedence[11][5] = 0;
                incedence[11][6] = 0;
                incedence[11][7] = 0;
                incedence[11][8] = 0;
                incedence[11][9] = 0;
                
                incedence[11][10] = 0;
                incedence[11][11] = 0;
                incedence[11][12] = -1;
                incedence[11][13] = 0;
                incedence[11][14] = -1;
                incedence[11][15] = 0;
                incedence[11][16] = 0;
                incedence[11][17] = 0;
                incedence[11][18] = 0;
                incedence[11][19] = 0;
                
                incedence[11][20] = 0;
                incedence[11][21] = 0;
                incedence[11][22] = 0;
                incedence[11][23] = 0;
                incedence[11][24] = 0;
                incedence[11][25] = 0;
                incedence[11][26] = 0;
                incedence[11][27] = 0;
                incedence[11][28] = 1;
                incedence[11][29] = 1;
               
                incedence[11][30] = 0;
                incedence[11][31] = 0;
                incedence[11][32] = 0;
                incedence[11][33] = 0;
                incedence[11][34] = 0;
                incedence[11][35] = 0;
                incedence[11][36] = 0;
                incedence[11][37] = 0;
                incedence[11][38] = 0;
                incedence[11][39] = 0;

                incedence[11][40] = 0;
                incedence[11][41] = 0;
                incedence[11][42] = 0;
                incedence[11][43] = 0;
                incedence[11][44] = 0;
                incedence[11][45] = 0;
                incedence[11][46] = 0;
                incedence[11][47] = 0;
                incedence[11][48] = 0;
                incedence[11][49] = 0;

                incedence[11][50] = 0;
                incedence[11][51] = 0;
                incedence[11][52] = 0;
                incedence[11][53] = 0;
                incedence[11][54] = 0;
                incedence[11][55] = 0;
                incedence[11][56] = 0;
                incedence[11][57] = 0;
                incedence[11][58] = 0;
                incedence[11][59] = 0;

                incedence[11][60] = 0;
                incedence[11][61] = 0;
                incedence[11][62] = 0;
                incedence[11][63] = 0;
   
              //

               
                incedence[12][0] = 0;
                incedence[12][1] = 0;
                incedence[12][2] = 0;
                incedence[12][3] = 0;
                incedence[12][4] = 0;
                incedence[12][5] = 0;
                incedence[12][6] = 0;
                incedence[12][7] = 0;
                incedence[12][8] = 0;
                incedence[12][9] = 0;
                
                incedence[12][10] = 0;
                incedence[12][11] = 0;
                incedence[12][12] = 0;
                incedence[12][13] = -1;
                incedence[12][14] = 0;
                incedence[12][15] = -1;
                incedence[12][16] = 0;
                incedence[12][17] = 0;
                incedence[12][18] = 0;
                incedence[12][19] = 0;
                
                incedence[12][20] = 0;
                incedence[12][21] = 0;
                incedence[12][22] = 0;
                incedence[12][23] = 0;
                incedence[12][24] = 0;
                incedence[12][25] = 0;
                incedence[12][26] = 0;
                incedence[12][27] = 0;
                incedence[12][28] = 0;
                incedence[12][29] = 0;
               
                incedence[12][30] = 1;
                incedence[12][31] = 1;
                incedence[12][32] = 0;
                incedence[12][33] = 0;
                incedence[12][34] = 0;
                incedence[12][35] = 0;
                incedence[12][36] =0;
                incedence[12][37] = 0;
                incedence[12][38] = 0;
                incedence[12][39] = 0;

                incedence[12][40] = 0;
                incedence[12][41] = 0;
                incedence[12][42] = 0;
                incedence[12][43] = 0;
                incedence[12][44] = 0;
                incedence[12][45] = 0;
                incedence[12][46] = 0;
                incedence[12][47] = 0;
                incedence[12][48] = 0;
                incedence[12][49] = 0;

                incedence[12][50] = 0;
                incedence[12][51] = 0;
                incedence[12][52] = 0;
                incedence[12][53] = 0;
                incedence[12][54] = 0;
                incedence[12][55] = 0;
                incedence[12][56] = 0;
                incedence[12][57] = 0;
                incedence[12][58] = 0;
                incedence[12][59] = 0;

                incedence[12][60] = 0;
                incedence[12][61] = 0;
                incedence[12][62] = 0;
                incedence[12][63] = 0;
  
              //
 incedence[13][0] = 0;
                incedence[13][1] = 0;
                incedence[13][2] = 0;
                incedence[13][3] = 0;
                incedence[13][4] = 0;
                incedence[13][5] = 0;
                incedence[13][6] = 0;
                incedence[13][7] = 0;
                incedence[13][8] = 0;
                incedence[13][9] = 0;
                
                incedence[13][10] = 0;
                incedence[13][11] = 0;
                incedence[13][12] = 0;
                incedence[13][13] = 0;
                incedence[13][14] = 0;
                incedence[13][15] = 0;
                incedence[13][16] = -1;
                incedence[13][17] = 0;
                incedence[13][18] = -1;
                incedence[13][19] = 0;
                
                incedence[13][20] = 0;
                incedence[13][21] = 0;
                incedence[13][22] = 0;
                incedence[13][23] = 0;
                incedence[13][24] = 0;
                incedence[13][25] = 0;
                incedence[13][26] = 0;
                incedence[13][27] = 0;
                incedence[13][28] = 0;
                incedence[13][29] = 0;
               
                incedence[13][30] = 0;
                incedence[13][31] = 0;
                incedence[13][32] = 1;
                incedence[13][33] = 1;
                incedence[13][34] = 0;
                incedence[13][35] = 0;
                incedence[13][36] = 0;
                incedence[13][37] = 0;
                incedence[13][38] = 0;
                incedence[13][39] = 0;

                incedence[13][40] = 0;
                incedence[13][41] = 0;
                incedence[13][42] = 0;
                incedence[13][43] = 0;
                incedence[13][44] = 0;
                incedence[13][45] = 0;
                incedence[13][46] = 0;
                incedence[13][47] = 0;
                incedence[13][48] = 0;
                incedence[13][49] = 0;

                incedence[13][50] = 0;
                incedence[13][51] = 0;
                incedence[13][52] = 0;
                incedence[13][53] = 0;
                incedence[13][54] = 0;
                incedence[13][55] = 0;
                incedence[13][56] = 0;
                incedence[13][57] = 0;
                incedence[13][58] = 0;
                incedence[13][59] = 0;

                incedence[13][60] = 0;
                incedence[13][61] = 0;
                incedence[13][62] = 0;
                incedence[13][63] = 0;


             //  
                incedence[14][0] = 0;
                incedence[14][1] = 0;
                incedence[14][2] = 0;
                incedence[14][3] = 0;
                incedence[14][4] = 0;
                incedence[14][5] = 0;
                incedence[14][6] = 0;
                incedence[14][7] = 0;
                incedence[14][8] = 0;
                incedence[14][9] = 0;
                
                incedence[14][10] = 0;
                incedence[14][11] = 0;
                incedence[14][12] = 0;
                incedence[14][13] = 0;
                incedence[14][14] = 0;
                incedence[14][15] = 0;
                incedence[14][16] = 0;
                incedence[14][17] = -1;
                incedence[14][18] = 0;
                incedence[14][19] = -1;
                
                incedence[14][20] = 0;
                incedence[14][21] = 0;
                incedence[14][22] = 0;
                incedence[14][23] = 0;
                incedence[14][24] = 0;
                incedence[14][25] = 0;
                incedence[14][26] = 0;
                incedence[14][27] = 0;
                incedence[14][28] = 0;
                incedence[14][29] = 0;
               
                incedence[14][30] = 0;
                incedence[14][31] = 0;
                incedence[14][32] = 0;
                incedence[14][33] = 0;
                incedence[14][34] = 1;
                incedence[14][35] = 1;
                incedence[14][36] = 0;
                incedence[14][37] = 0;
                incedence[14][38] = 0;
                incedence[14][39] = 0;

                incedence[14][40] = 0;
                incedence[14][41] = 0;
                incedence[14][42] = 0;
                incedence[14][43] = 0;
                incedence[14][44] = 0;
                incedence[14][45] = 0;
                incedence[14][46] = 0;
                incedence[14][47] = 0;
                incedence[14][48] = 0;
                incedence[14][49] = 0;

                incedence[14][50] = 0;
                incedence[14][51] = 0;
                incedence[14][52] = 0;
                incedence[14][53] = 0;
                incedence[14][54] = 0;
                incedence[14][55] = 0;
                incedence[14][56] = 0;
                incedence[14][57] = 0;
                incedence[14][58] = 0;
                incedence[14][59] = 0;

                incedence[14][60] = 0;
                incedence[14][61] = 0;
                incedence[14][62] = 0;
                incedence[14][63] = 0;
    
              //

               
                incedence[15][0] = 0;
                incedence[15][1] = 0;
                incedence[15][2] = 0;
                incedence[15][3] = 0;
                incedence[15][4] = 0;
                incedence[15][5] = 0;
                incedence[15][6] = 0;
                incedence[15][7] = 0;
                incedence[15][8] = 0;
                incedence[15][9] = 0;
                
                incedence[15][10] = 0;
                incedence[15][11] = 0;
                incedence[15][12] = 0;
                incedence[15][13] = 0;
                incedence[15][14] = 0;
                incedence[15][15] = 0;
                incedence[15][16] = 0;
                incedence[15][17] = 0;
                incedence[15][18] = 0;
                incedence[15][19] = 0;
                
                incedence[15][20] = -1;
                incedence[15][21] = 0;
                incedence[15][22] = -1;
                incedence[15][23] = 0;
                incedence[15][24] = 0;
                incedence[15][25] = 0;
                incedence[15][26] = 0;
                incedence[15][27] = 0;
                incedence[15][28] = 0;
                incedence[15][29] = 0;
               
                incedence[15][30] = 0;
                incedence[15][31] = 0;
                incedence[15][32] = 0;
                incedence[15][33] = 0;
                incedence[15][34] = 0;
                incedence[15][35] = 0;
                incedence[15][36] = 1;
                incedence[15][37] = 1;
                incedence[15][38] = 0;
                incedence[15][39] = 0;

                incedence[15][40] = 0;
                incedence[15][41] = 0;
                incedence[15][42] = 0;
                incedence[15][43] =0;
                incedence[15][44] = 0;
                incedence[15][45] = 0;
                incedence[15][46] = 0;
                incedence[15][47] = 0;
                incedence[15][48] = 0;
                incedence[15][49] = 0;

                incedence[15][50] = 0;
                incedence[15][51] = 0;
                incedence[15][52] = 0;
                incedence[15][53] = 0;
                incedence[15][54] = 0;
                incedence[15][55] = 0;
                incedence[15][56] = 0;
                incedence[15][57] = 0;
                incedence[15][58] = 0;
                incedence[15][59] = 0;

                incedence[15][60] = 0;
                incedence[15][61] = 0;
                incedence[15][62] = 0;
                incedence[15][63] = 0;

              //

               
                incedence[16][0] = 0;
                incedence[16][1] = 0;
                incedence[16][2] = 0;
                incedence[16][3] = 0;
                incedence[16][4] = 0;
                incedence[16][5] = 0;
                incedence[16][6] = 0;
                incedence[16][7] = 0;
                incedence[16][8] = 0;
                incedence[16][9] = 0;
                
                incedence[16][10] = 0;
                incedence[16][11] = 0;
                incedence[16][12] = 0;
                incedence[16][13] = 0;
                incedence[16][14] = 0;
                incedence[16][15] = 0;
                incedence[16][16] = 0;
                incedence[16][17] = 0;
                incedence[16][18] = 0;
                incedence[16][19] = 0;
                
                incedence[16][20] = 0;
                incedence[16][21] = -1;
                incedence[16][22] = 0;
                incedence[16][23] = -1;
                incedence[16][24] = 0;
                incedence[16][25] = 0;
                incedence[16][26] = 0;
                incedence[16][27] = 0;
                incedence[16][28] = 0;
                incedence[16][29] = 0;
               
                incedence[16][30] = 0;
                incedence[16][31] = 0;
                incedence[16][32] = 0;
                incedence[16][33] = 0;
                incedence[16][34] = 0;
                incedence[16][35] = 0;
                incedence[16][36] = 0;
                incedence[16][37] = 0;
                incedence[16][38] = 1;
                incedence[16][39] = 1;

                incedence[16][40] = 0;
                incedence[16][41] = 0;
                incedence[16][42] = 0;
                incedence[16][43] = 0;
                incedence[16][44] = 0;
                incedence[16][45] = 0;
                incedence[16][46] = 0;
                incedence[16][47] = 0;
                incedence[16][48] = 0;
                incedence[16][49] = 0;

                incedence[16][50] = 0;
                incedence[16][51] = 0;
                incedence[16][52] = 0;
                incedence[16][53] = 0;
                incedence[16][54] = 0;
                incedence[16][55] = 0;
                incedence[16][56] = 0;
                incedence[16][57] = 0;
                incedence[16][58] = 0;
                incedence[16][59] = 0;

                incedence[16][60] = 0;
                incedence[16][61] = 0;
                incedence[16][62] = 0;
                incedence[16][63] = 0;

              //

               
                incedence[17][0] = 0;
                incedence[17][1] = 0;
                incedence[17][2] = 0;
                incedence[17][3] = 0;
                incedence[17][4] = 0;
                incedence[17][5] = 0;
                incedence[17][6] = 0;
                incedence[17][7] = 0;
                incedence[17][8] = 0;
                incedence[17][9] = 0;
                
                incedence[17][10] = 0;
                incedence[17][11] = 0;
                incedence[17][12] = 0;
                incedence[17][13] = 0;
                incedence[17][14] = 0;
                incedence[17][15] = 0;
                incedence[17][16] = 0;
                incedence[17][17] = 0;
                incedence[17][18] = 0;
                incedence[17][19] = 0;
                
                incedence[17][20] = 0;
                incedence[17][21] = 0;
                incedence[17][22] = 0;
                incedence[17][23] = 0;
                incedence[17][24] = -1;
                incedence[17][25] = 0;
                incedence[17][26] = 0;
                incedence[17][27] = 0;
                incedence[17][28] = -1;
                incedence[17][29] = 0;
               
                incedence[17][30] = 0;
                incedence[17][31] = 0;
                incedence[17][32] = 0;
                incedence[17][33] = 0;
                incedence[17][34] = 0;
                incedence[17][35] = 0;
                incedence[17][36] = 0;
                incedence[17][37] = 0;
                incedence[17][38] = 0;
                incedence[17][39] = 0;

                incedence[17][40] = 1;
                incedence[17][41] = 1;
                incedence[17][42] = 0;
                incedence[17][43] = 0;
                incedence[17][44] = 0;
                incedence[17][45] = 0;
                incedence[17][46] = 0;
                incedence[17][47] =0;
                incedence[17][48] =0;
                incedence[17][49] = 0;

                incedence[17][50] = 0;
                incedence[17][51] = 0;
                incedence[17][52] = 0;
                incedence[17][53] = 0;
                incedence[17][54] = 0;
                incedence[17][55] = 0;
                incedence[17][56] = 0;
                incedence[17][57] = 0;
                incedence[17][58] = 0;
                incedence[17][59] = 0;

                incedence[17][60] = 0;
                incedence[17][61] = 0;
                incedence[17][62] = 0;
                incedence[17][63] = 0;


              //

               
                incedence[18][0] = 0;
                incedence[18][1] = 0;
                incedence[18][2] = 0;
                incedence[18][3] = 0;
                incedence[18][4] = 0;
                incedence[18][5] = 0;
                incedence[18][6] = 0;
                incedence[18][7] = 0;
                incedence[18][8] = 0;
                incedence[18][9] = 0;
                
                incedence[18][10] = 0;
                incedence[18][11] = 0;
                incedence[18][12] = 0;
                incedence[18][13] = 0;
                incedence[18][14] = 0;
                incedence[18][15] = 0;
                incedence[18][16] = 0;
                incedence[18][17] = 0;
                incedence[18][18] = 0;
                incedence[18][19] = 0;
                
                incedence[18][20] = 0;
                incedence[18][21] = 0;
                incedence[18][22] = 0;
                incedence[18][23] = 0;
                incedence[18][24] = 0;
                incedence[18][25] = 0;
                incedence[18][26] = -1;
                incedence[18][27] = 0;
                incedence[18][28] = 0;
                incedence[18][29] = 0;
               
                incedence[18][30] = -1;
                incedence[18][31] = 0;
                incedence[18][32] = 0;
                incedence[18][33] = 0;
                incedence[18][34] = 0;
                incedence[18][35] = 0;
                incedence[18][36] = 0;
                incedence[18][37] = 0;
                incedence[18][38] = 0;
                incedence[18][39] = 0;

                incedence[18][40] = 0;
                incedence[18][41] = 0;
                incedence[18][42] = 1;
                incedence[18][43] = 1;
                incedence[18][44] = 0;
                incedence[18][45] = 0;
                incedence[18][46] = 0;
                incedence[18][47] = 0;
                incedence[18][48] = 0;
                incedence[18][49] = 0;

                incedence[18][50] =0;
                incedence[18][51] = 0;
                incedence[18][52] =0;
                incedence[18][53] = 0;
                incedence[18][54] = 0;
                incedence[18][55] = 0;
                incedence[18][56] = 0;
                incedence[18][57] = 0;
                incedence[18][58] = 0;
                incedence[18][59] = 0;

                incedence[18][60] = 0;
                incedence[18][61] = 0;
                incedence[18][62] = 0;
                incedence[18][63] = 0;
 
              //

               
                incedence[19][0] = 0;
                incedence[19][1] = 0;
                incedence[19][2] = 0;
                incedence[19][3] = 0;
                incedence[19][4] = 0;
                incedence[19][5] = 0;
                incedence[19][6] = 0;
                incedence[19][7] = 0;
                incedence[19][8] = 0;
                incedence[19][9] = 0;
                
                incedence[19][10] = 0;
                incedence[19][11] = 0;
                incedence[19][12] = 0;
                incedence[19][13] = 0;
                incedence[19][14] = 0;
                incedence[19][15] = 0;
                incedence[19][16] = 0;
                incedence[19][17] = 0;
                incedence[19][18] = 0;
                incedence[19][19] = 0;
                
                incedence[19][20] = 0;
                incedence[19][21] = 0;
                incedence[19][22] = 0;
                incedence[19][23] = 0;
                incedence[19][24] = 0;
                incedence[19][25] = -1;
                incedence[19][26] = 0;
                incedence[19][27] = 0;
                incedence[19][28] = 0;
                incedence[19][29] = -1;
               
                incedence[19][30] = 0;
                incedence[19][31] = 0;
                incedence[19][32] = 0;
                incedence[19][33] = 0;
                incedence[19][34] = 0;
                incedence[19][35] = 0;
                incedence[19][36] = 0;
                incedence[19][37] = 0;
                incedence[19][38] = 0;
                incedence[19][39] = 0;

                incedence[19][40] = 0;
                incedence[19][41] = 0;
                incedence[19][42] = 0;
                incedence[19][43] = 0;
                incedence[19][44] = -1;
                incedence[19][45] = -1;
                incedence[19][46] = 0;
                incedence[19][47] = 0;
                incedence[19][48] = 0;
                incedence[19][49] = 0;

                incedence[19][50] = 0;
                incedence[19][51] = 0;
                incedence[19][52] = 0;
                incedence[19][53] = 0;
                incedence[19][54] = 0;
                incedence[19][55] = 0;
                incedence[19][56] = 0;
                incedence[19][57] = 0;
                incedence[19][58] = 0;
                incedence[19][59] = 0;

                incedence[19][60] = 0;
                incedence[19][61] = 0;
                incedence[19][62] = 0;
                incedence[19][63] = 0;
   
              //
                incedence[20][0] = 0;
                incedence[20][1] = 0;
                incedence[20][2] = 0;
                incedence[20][3] = 0;
                incedence[20][4] = 0;
                incedence[20][5] = 0;
                incedence[20][6] = 0;
                incedence[20][7] = 0;
                incedence[20][8] = 0;
                incedence[20][9] = 0;
                
                incedence[20][10] = 0;
                incedence[20][11] = 0;
                incedence[20][12] = 0;
                incedence[20][13] = 0;
                incedence[20][14] = 0;
                incedence[20][15] = 0;
                incedence[20][16] = 0;
                incedence[20][17] = 0;
                incedence[20][18] = 0;
                incedence[20][19] = 0;
                
                incedence[20][20] = 0;
                incedence[20][21] = 0;
                incedence[20][22] = 0;
                incedence[20][23] = 0;
                incedence[20][24] = 0;
                incedence[20][25] = 0;
                incedence[20][26] = 0;
                incedence[20][27] = -1;
                incedence[20][28] = 0;
                incedence[20][29] = 0;
               
                incedence[20][30] = 0;
                incedence[20][31] = -1;
                incedence[20][32] = 0;
                incedence[20][33] = 0;
                incedence[20][34] = 0;
                incedence[20][35] = 0;
                incedence[20][36] = 0;
                incedence[20][37] = 0;
                incedence[20][38] = 0;
                incedence[20][39] = 0;

                incedence[20][40] = 0;
                incedence[20][41] = 0;
                incedence[20][42] = 0;
                incedence[20][43] = 0;
                incedence[20][44] = 0;
                incedence[20][45] = 0;
                incedence[20][46] = 1;
                incedence[20][47] = 1;
                incedence[20][48] = 0;
                incedence[20][49] = 0;

                incedence[20][50] = 0;
                incedence[20][51] = 0;
                incedence[20][52] = 0;
                incedence[20][53] = 0;
                incedence[20][54] = 0;
                incedence[20][55] = 0;
                incedence[20][56] = 0;
                incedence[20][57] = 0;
                incedence[20][58] = 0;
                incedence[20][59] = 0;

                incedence[20][60] = 0;
                incedence[20][61] = 0;
                incedence[20][62] = 0;
                incedence[20][63] = 0;

              //
                incedence[21][0] = 0;
                incedence[21][1] = 0;
                incedence[21][2] = 0;
                incedence[21][3] = 0;
                incedence[21][4] = 0;
                incedence[21][5] = 0;
                incedence[21][6] = 0;
                incedence[21][7] = 0;
                incedence[21][8] = 0;
                incedence[21][9] = 0;
                
                incedence[21][10] = 0;
                incedence[21][11] = 0;
                incedence[21][12] = 0;
                incedence[21][13] = 0;
                incedence[21][14] = 0;
                incedence[21][15] = 0;
                incedence[21][16] = 0;
                incedence[21][17] = 0;
                incedence[21][18] = 0;
                incedence[21][19] = 0;
                
                incedence[21][20] = 0;
                incedence[21][21] = 0;
                incedence[21][22] = 0;
                incedence[21][23] = 0;
                incedence[21][24] = 0;
                incedence[21][25] = 0;
                incedence[21][26] = 0;
                incedence[21][27] = 0;
                incedence[21][28] = 0;
                incedence[21][29] = 0;
               
                incedence[21][30] = 0;
                incedence[21][31] = 0;
                incedence[21][32] = -1;
                incedence[21][33] = 0;
                incedence[21][34] = 0;
                incedence[21][35] = 0;
                incedence[21][36] = -1;
                incedence[21][37] = 0;
                incedence[21][38] = 0;
                incedence[21][39] = 0;

                incedence[21][40] = 0;
                incedence[21][41] = 0;
                incedence[21][42] = 0;
                incedence[21][43] = 0;
                incedence[21][44] = 0;
                incedence[21][45] = 0;
                incedence[21][46] = 0;
                incedence[21][47] = 0;
                incedence[21][48] = 1;
                incedence[21][49] = 1;

                incedence[21][50] = 0;
                incedence[21][51] = 0;
                incedence[21][52] = 0;
                incedence[21][53] = 0;
                incedence[21][54] = 0;
                incedence[21][55] = 0;
                incedence[21][56] = 0;
                incedence[21][57] = 0;
                incedence[21][58] = 0;
                incedence[21][59] = 0;

                incedence[21][60] = 0;
                incedence[21][61] = 0;
                incedence[21][62] = 0;
                incedence[21][63] = 0;

              //
                incedence[22][0] = 0;
                incedence[22][1] = 0;
                incedence[22][2] = 0;
                incedence[22][3] = 0;
                incedence[22][4] = 0;
                incedence[22][5] = 0;
                incedence[22][6] = 0;
                incedence[22][7] = 0;
                incedence[22][8] = 0;
                incedence[22][9] = 0;
                
                incedence[22][10] = 0;
                incedence[22][11] = 0;
                incedence[22][12] = 0;
                incedence[22][13] = 0;
                incedence[22][14] = 0;
                incedence[22][15] = 0;
                incedence[22][16] = 0;
                incedence[22][17] = 0;
                incedence[22][18] = 0;
                incedence[22][19] = 0;
                
                incedence[22][20] = 0;
                incedence[22][21] = 0;
                incedence[22][22] = 0;
                incedence[22][23] = 0;
                incedence[22][24] = 0;
                incedence[22][25] = 0;
                incedence[22][26] = 0;
                incedence[22][27] = 0;
                incedence[22][28] = 0;
                incedence[22][29] = 0;
               
                incedence[22][30] = 0;
                incedence[22][31] = 0;
                incedence[22][32] = 0;
                incedence[22][33] = 0;
                incedence[22][34] = -1;
                incedence[22][35] = 0;
                incedence[22][36] = 0;
                incedence[22][37] = 0;
                incedence[22][38] = -1;
                incedence[22][39] =0;

                incedence[22][40] = 0;
                incedence[22][41] = 0;
                incedence[22][42] = 0;
                incedence[22][43] = 0;
                incedence[22][44] = 0;
                incedence[22][45] = 0;
                incedence[22][46] = 0;
                incedence[22][47] = 0;
                incedence[22][48] = 0;
                incedence[22][49] = 0;

                incedence[22][50] = 1;
                incedence[22][51] = 1;
                incedence[22][52] = 0;
                incedence[22][53] = 0;
                incedence[22][54] = 0;
                incedence[22][55] = 0;
                incedence[22][56] = 0;
                incedence[22][57] = 0;
                incedence[22][58] = 0;
                incedence[22][59] = 0;

                incedence[22][60] = 0;
                incedence[22][61] =0;
                incedence[22][62] =0;
                incedence[22][63] = 0;
               
//
                incedence[23][0] = 0;
                incedence[23][1] = 0;
                incedence[23][2] = 0;
                incedence[23][3] = 0;
                incedence[23][4] = 0;
                incedence[23][5] = 0;
                incedence[23][6] = 0;
                incedence[23][7] = 0;
                incedence[23][8] = 0;
                incedence[23][9] = 0;
                
                incedence[23][10] = 0;
                incedence[23][11] = 0;
                incedence[23][12] = 0;
                incedence[23][13] = 0;
                incedence[23][14] = 0;
                incedence[23][15] = 0;
                incedence[23][16] = 0;
                incedence[23][17] = 0;
                incedence[23][18] = 0;
                incedence[23][19] = 0;
                
                incedence[23][20] = 0;
                incedence[23][21] = 0;
                incedence[23][22] = 0;
                incedence[23][23] = 0;
                incedence[23][24] = 0;
                incedence[23][25] = 0;
                incedence[23][26] = 0;
                incedence[23][27] = 0;
                incedence[23][28] = 0;
                incedence[23][29] = 0;
               
                incedence[23][30] = 0;
                incedence[23][31] = 0;
                incedence[23][32] = 0;
                incedence[23][33] = -1;
                incedence[23][34] = 0;
                incedence[23][35] = 0;
                incedence[23][36] = 0;
                incedence[23][37] = -1;
                incedence[23][38] = 0;
                incedence[23][39] = 0;

                incedence[23][40] = 0;
                incedence[23][41] = 0;
                incedence[23][42] = 0;
                incedence[23][43] = 0;
                incedence[23][44] = 0;
                incedence[23][45] = 0;
                incedence[23][46] = 0;
                incedence[23][47] = 0;
                incedence[23][48] = 0;
                incedence[23][49] = 0;

                incedence[23][50] = 0;
                incedence[23][51] = 0;
                incedence[23][52] = 1;
                incedence[23][53] = 1;
                incedence[23][54] = 0;
                incedence[23][55] = 0;
                incedence[23][56] = 0;
                incedence[23][57] = 0;
                incedence[23][58] = 0;
                incedence[23][59] = 0;

                incedence[23][60] = 0;
                incedence[23][61] = 0;
                incedence[23][62] = 0;
                incedence[23][63] = 0;
               //////////////////
                incedence[24][0] = 0;
                incedence[24][1] = 0;
                incedence[24][2] = 0;
                incedence[24][3] = 0;
                incedence[24][4] = 0;
                incedence[24][5] = 0;
                incedence[24][6] = 0;
                incedence[24][7] = 0;
                incedence[24][8] = 0;
                incedence[24][9] = 0;
                
                incedence[24][10] = 0;
                incedence[24][11] = 0;
                incedence[24][12] = 0;
                incedence[24][13] = 0;
                incedence[24][14] = 0;
                incedence[24][15] = 0;
                incedence[24][16] = 0;
                incedence[24][17] = 0;
                incedence[24][18] = 0;
                incedence[24][19] = 0;
                
                incedence[24][20] = 0;
                incedence[24][21] = 0;
                incedence[24][22] = 0;
                incedence[24][23] = 0;
                incedence[24][24] = 0;
                incedence[24][25] = 0;
                incedence[24][26] = 0;
                incedence[24][27] = 0;
                incedence[24][28] = 0;
                incedence[24][29] = 0;
              
                incedence[24][30] = 0;
                incedence[24][31] = 0;
                incedence[24][32] = 0;
                incedence[24][33] = 0;
                incedence[24][34] = 0;
                incedence[24][35] = -1;
                incedence[24][36] = 0;
                incedence[24][37] = 0;
                incedence[24][38] = 0;
                incedence[24][39] = -1;

                incedence[24][40] = 0;
                incedence[24][41] = 0;
                incedence[24][42] =0;
                incedence[24][43] = 0;
                incedence[24][44] = 0;
                incedence[24][45] = 0;
                incedence[24][46] = 0;
                incedence[24][47] = 0;
                incedence[24][48] = 0;
                incedence[24][49] = 0;

                incedence[24][50] = 0;
                incedence[24][51] = 0;
                incedence[24][52] = 0;
                incedence[24][53] = 0;
                incedence[24][54] = 1;
                incedence[24][55] = 1;
                incedence[24][56] = 0;
                incedence[24][57] = 0;
                incedence[24][58] = 0;
                incedence[24][59] = 0;

                incedence[24][60] = 0;
                incedence[24][61] = 0;
                incedence[24][62] = 0;
                incedence[24][63] = 0;

//
                incedence[25][0] = 0;
                incedence[25][1] = 0;
                incedence[25][2] = 0;
                incedence[25][3] = 0;
                incedence[25][4] = 0;
                incedence[25][5] = 0;
                incedence[25][6] = 0;
                incedence[25][7] = 0;
                incedence[25][8] = 0;
                incedence[25][9] = 0;
                
                incedence[25][10] = 0;
                incedence[25][11] = 0;
                incedence[25][12] = 0;
                incedence[25][13] = 0;
                incedence[25][14] = 0;
                incedence[25][15] = 0;
                incedence[25][16] = 0;
                incedence[25][17] = 0;
                incedence[25][18] = 0;
                incedence[25][19] = 0;
                
                incedence[25][20] = 0;
                incedence[25][21] = 0;
                incedence[25][22] = 0;
                incedence[25][23] = 0;
                incedence[25][24] = 0;
                incedence[25][25] = 0;
                incedence[25][26] = 0;
                incedence[25][27] = 0;
                incedence[25][28] = 0;
                incedence[25][29] = 0;
               
                incedence[25][30] = 0;
                incedence[25][31] = 0;
                incedence[25][32] = 0;
                incedence[25][33] = 0;
                incedence[25][34] = 0;
                incedence[25][35] = 0;
                incedence[25][36] = 0;
                incedence[25][37] = 0;
                incedence[25][38] = 0;
                incedence[25][39] = 0;
                incedence[25][40] = -1;
                incedence[25][41] = 0;
                incedence[25][42] = 0;
                incedence[25][43] = 0;
                incedence[25][44] = 0;
                incedence[25][45] = 0;
                incedence[25][46] = 0;
                incedence[25][47] = 0;
                incedence[25][48] = -1;
                incedence[25][49] = 0;

                incedence[25][50] = 0;
                incedence[25][51] = 0;
                incedence[25][52] = 0;
                incedence[25][53] = 0;
                incedence[25][54] = 0;
                incedence[25][55] = 0;
                incedence[25][56] = 1;
                incedence[25][57] = 0;
                incedence[25][58] = 0;
                incedence[25][59] = 0;

                incedence[25][60] = 0;
                incedence[25][61] = 0;
                incedence[25][62] = 0;
                incedence[25][63] = 0;

//
          incedence[26][0] = 0;
                incedence[26][1] = 0;
                incedence[26][2] = 0;
                incedence[26][3] = 0;
                incedence[26][4] = 0;
                incedence[26][5] = 0;
                incedence[26][6] = 0;
                incedence[26][7] = 0;
                incedence[26][8] = 0;
                incedence[26][9] = 0;
                
                incedence[26][10] = 0;
                incedence[26][11] = 0;
                incedence[26][12] = 0;
                incedence[26][13] = 0;
                incedence[26][14] = 0;
                incedence[26][15] = 0;
                incedence[26][16] = 0;
                incedence[26][17] = 0;
                incedence[26][18] = 0;
                incedence[26][19] = 0;
                
                incedence[26][20] = 0;
                incedence[26][21] = 0;
                incedence[26][22] = 0;
                incedence[26][23] = 0;
                incedence[26][24] = 0;
                incedence[26][25] = 0;
                incedence[26][26] = 0;
                incedence[26][27] = 0;
                incedence[26][28] = 0;
                incedence[26][29] = 0;
               
                incedence[26][30] = 0;
                incedence[26][31] = 0;
                incedence[26][32] = 0;
                incedence[26][33] = 0;
                incedence[26][34] = 0;
                incedence[26][35] = 0;
                incedence[26][36] = 0;
                incedence[26][37] = 0;
                incedence[26][38] = 0;
                incedence[26][39] = 0;

                incedence[26][40] = 0;
                incedence[26][41] = 0;
                incedence[26][42] = -1;
                incedence[26][43] = 0;
                incedence[26][44] = 0;
                incedence[26][45] = 0;
                incedence[26][46] = 0;
                incedence[26][47] =0;
                incedence[26][48] = 0;
                incedence[26][49] = 0;

                incedence[26][50] = -1;
                incedence[26][51] = 0;
                incedence[26][52] = 0;
                incedence[26][53] = 0;
                incedence[26][54] = 0;
                incedence[26][55] = 0;
                incedence[26][56] = 0;
                incedence[26][57] = 1;
                incedence[26][58] = 0;
                incedence[26][59] = 0;

                incedence[26][60] = 0;
                incedence[26][61] = 0;
                incedence[26][62] = 0;
                incedence[26][63] = 0;

//
             incedence[27][0] = 0;
                incedence[27][1] = 0;
                incedence[27][2] = 0;
                incedence[27][3] = 0;
                incedence[27][4] = 0;
                incedence[27][5] = 0;
                incedence[27][6] = 0;
                incedence[27][7] = 0;
                incedence[27][8] = 0;
                incedence[27][9] = 0;
                
                incedence[27][10] = 0;
                incedence[27][11] = 0;
                incedence[27][12] = 0;
                incedence[27][13] = 0;
                incedence[27][14] = 0;
                incedence[27][15] = 0;
                incedence[27][16] = 0;
                incedence[27][17] = 0;
                incedence[27][18] = 0;
                incedence[27][19] = 0;
                
                incedence[27][20] = 0;
                incedence[27][21] = 0;
                incedence[27][22] = 0;
                incedence[27][23] = 0;
                incedence[27][24] = 0;
                incedence[27][25] = 0;
                incedence[27][26] = 0;
                incedence[27][27] = 0;
                incedence[27][28] = 0;
                incedence[27][29] = 0;
               
                incedence[27][30] = 0;
                incedence[27][31] = 0;
                incedence[27][32] = 0;
                incedence[27][33] = 0;
                incedence[27][34] = 0;
                incedence[27][35] = 0;
                incedence[27][36] = 0;
                incedence[27][37] = 0;
                incedence[27][38] = 0;
                incedence[27][39] = 0;

                incedence[27][40] = 0;
                incedence[27][41] = 0;
                incedence[27][42] = 0;
                incedence[27][43] = 0;
                incedence[27][44] = -1;
                incedence[27][45] = 0;
                incedence[27][46] = 0;
                incedence[27][47] = 0;
                incedence[27][48] = 0;
                incedence[27][49] = 0;

                incedence[27][50] = 0;
                incedence[27][51] = 0;
                incedence[27][52] =-1;
                incedence[27][53] = 0;
                incedence[27][54] = 0;
                incedence[27][55] = 0;
                incedence[27][56] = 0;
                incedence[27][57] = 0;
                incedence[27][58] = 1;
                incedence[27][59] = 0;

                incedence[27][60] = 0;
                incedence[27][61] = 0;
                incedence[27][62] = 0;
                incedence[27][63] = 0;

//
                incedence[28][0] = 0;
                incedence[28][1] = 0;
                incedence[28][2] = 0;
                incedence[28][3] = 0;
                incedence[28][4] = 0;
                incedence[28][5] = 0;
                incedence[28][6] = 0;
                incedence[28][7] = 0;
                incedence[28][8] = 0;
                incedence[28][9] = 0;
               
                incedence[28][10] = 0;
                incedence[28][11] = 0;
                incedence[28][12] = 0;
                incedence[28][13] = 0;
                incedence[28][14] = 0;
                incedence[28][15] = 0;
                incedence[28][16] = 0;
                incedence[28][17] = 0;
                incedence[28][18] = 0;
                incedence[28][19] = 0;
                
                incedence[28][20] = 0;
                incedence[28][21] = 0;
                incedence[28][22] = 0;
                incedence[28][23] = 0;
                incedence[28][24] = 0;
                incedence[28][25] = 0;
                incedence[28][26] = 0;
                incedence[28][27] = 0;
                incedence[28][28] = 0;
                incedence[28][29] = 0;
               
                incedence[28][30] = 0;
                incedence[28][31] = 0;
                incedence[28][32] = 0;
                incedence[28][33] = 0;
                incedence[28][34] = 0;
                incedence[28][35] = 0;
                incedence[28][36] = 0;
                incedence[28][37] = 0;
                incedence[28][38] = 0;
                incedence[28][39] = 0;

                incedence[28][40] = 0;
                incedence[28][41] = 0;
                incedence[28][42] = 0;
                incedence[28][43] = 0;
                incedence[28][44] = 0;
                incedence[28][45] = 0;
                incedence[28][46] = -1;
                incedence[28][47] = 0;
                incedence[28][48] = 0;
                incedence[28][49] = 0;

                incedence[28][50] = 0;
                incedence[28][51] = 0;
                incedence[28][52] = 0;
                incedence[28][53] = 0;
                incedence[28][54] = -1;
                incedence[28][55] = 0;
                incedence[28][56] = 0;
                incedence[28][57] = 0;
                incedence[28][58] = 0;
                incedence[28][59] = 1;

                incedence[28][60] = 0;
                incedence[28][61] = 0;
                incedence[28][62] = 0;
                incedence[28][63] = 0;
              
//
                incedence[29][0] = 0;
                incedence[29][1] = 0;
                incedence[29][2] = 0;
                incedence[29][3] = 0;
                incedence[29][4] = 0;
                incedence[29][5] = 0;
                incedence[29][6] = 0;
                incedence[29][7] = 0;
                incedence[29][8] = 0;
                incedence[29][9] = 0;
               
                incedence[29][10] = 0;
                incedence[29][11] = 0;
                incedence[29][12] = 0;
                incedence[29][13] = 0;
                incedence[29][14] = 0;
                incedence[29][15] = 0;
                incedence[29][16] = 0;
                incedence[29][17] = 0;
                incedence[29][18] = 0;
                incedence[29][19] = 0;
                
                incedence[29][20] = 0;
                incedence[29][21] = 0;
                incedence[29][22] = 0;
                incedence[29][23] = 0;
                incedence[29][24] = 0;
                incedence[29][25] = 0;
                incedence[29][26] = 0;
                incedence[29][27] = 0;
                incedence[29][28] = 0;
                incedence[29][29] = 0;
               
                incedence[29][30] = 0;
                incedence[29][31] = 0;
                incedence[29][32] = 0;
                incedence[29][33] = 0;
                incedence[29][34] = 0;
                incedence[29][35] = 0;
                incedence[29][36] = 0;
                incedence[29][37] = 0;
                incedence[29][38] = 0;
                incedence[29][39] = 0;

                incedence[29][40] = 0;
                incedence[29][41] = -1;
                incedence[29][42] = 0;
                incedence[29][43] = 0;
                incedence[29][44] = 0;
                incedence[29][45] = 0;
                incedence[29][46] = 0;
                incedence[29][47] = 0;
                incedence[29][48] = 0;
                incedence[29][49] = -1;

                incedence[29][50] = 0;
                incedence[29][51] = 0;
                incedence[29][52] = 0;
                incedence[29][53] = 0;
                incedence[29][54] = 0;
                incedence[29][55] = 0;
                incedence[29][56] = 0;
                incedence[29][57] = 0;
                incedence[29][58] = 0;
                incedence[29][59] = 0;

                incedence[29][60] = 1;
                incedence[29][61] = 0;
                incedence[29][62] = 0;
                incedence[29][63] = 0;
                

//
                incedence[30][0] = 0;
                incedence[30][1] = 0;
                incedence[30][2] = 0;
                incedence[30][3] = 0;
                incedence[30][4] = 0;
                incedence[30][5] = 0;
                incedence[30][6] = 0;
                incedence[30][7] = 0;
                incedence[30][8] = 0;
                incedence[30][9] = 0;
                
                incedence[30][10] = 0;
                incedence[30][11] = 0;
                incedence[30][12] = 0;
                incedence[30][13] = 0;
                incedence[30][14] = 0;
                incedence[30][15] = 0;
                incedence[30][16] = 0;
                incedence[30][17] = 0;
                incedence[30][18] = 0;
                incedence[30][19] = 0;
                
                incedence[30][20] = 0;
                incedence[30][21] = 0;
                incedence[30][22] = 0;
                incedence[30][23] = 0;
                incedence[30][24] = 0;
                incedence[30][25] = 0;
                incedence[30][26] = 0;
                incedence[30][27] = 0;
                incedence[30][28] = 0;
                incedence[30][29] = 0;
               
                incedence[30][30] = 0;
                incedence[30][31] = 0;
                incedence[30][32] = 0;
                incedence[30][33] = 0;
                incedence[30][34] = 0;
                incedence[30][35] = 0;
                incedence[30][36] = 0;
                incedence[30][37] = 0;
                incedence[30][38] = 0;
                incedence[30][39] = 0;

                incedence[30][40] = 0;
                incedence[30][41] = 0;
                incedence[30][42] = 0;
                incedence[30][43] = -1;
                incedence[30][44] = 0;
                incedence[30][45] = 0;
                incedence[30][46] = 0;
                incedence[30][47] = 0;
                incedence[30][48] = 0;
                incedence[30][49] = 0;

                incedence[30][50] = 0;
                incedence[30][51] = -1;
                incedence[30][52] = 0;
                incedence[30][53] = 0;
                incedence[30][54] = 0;
                incedence[30][55] = 0;
                incedence[30][56] = 0;
                incedence[30][57] = 0;
                incedence[30][58] = 0;
                incedence[30][59] = 0;

                incedence[30][60] = 0;
                incedence[30][61] = 1;
                incedence[30][62] = 0;
                incedence[30][63] = 0;
             
            
               
                /////****1 row

              
                incedence[31][0] = 0;
                incedence[31][1] = 0;
                incedence[31][2] = 0;
                incedence[31][3] = 0;
                incedence[31][4] = 0;
                incedence[31][5] = 0;
                incedence[31][6] = 0;
                incedence[31][7] = 0;
                incedence[31][8] = 0;
                incedence[31][9] = 0;
                
                incedence[31][10] = 0;
                incedence[31][11] = 0;
                incedence[31][12] = 0;
                incedence[31][13] = 0;
                incedence[31][14] = 0;
                incedence[31][15] = 0;
                incedence[31][16] = 0;
                incedence[31][17] = 0;
                incedence[31][18] = 0;
                incedence[31][19] = 0;
                
                incedence[31][20] = 0;
                incedence[31][21] = 0;
                incedence[31][22] = 0;
                incedence[31][23] = 0;
                incedence[31][24] = 0;
                incedence[31][25] = 0;
                incedence[31][26] = 0;
                incedence[31][27] = 0;
                incedence[31][28] = 0;
                incedence[31][29] = 0;
  
                incedence[31][30] = 0;
                incedence[31][31] = 0;
                incedence[31][32] = 0;
                incedence[31][33] = 0;
                incedence[31][34] = 0;
                incedence[31][35] = 0;
                incedence[31][36] = 0;
                incedence[31][37] = 0;
                incedence[31][38] = 0;
                incedence[31][39] = 0;

                incedence[31][40] = 0;
                incedence[31][41] = 0;
                incedence[31][42] = 0;
                incedence[31][43] = 0;
                incedence[31][44] = 0;
                incedence[31][45] = -1;
                incedence[31][46] = 0;
                incedence[31][47] = 0;
                incedence[31][48] = 0;
                incedence[31][49] = 0;

                incedence[31][50] = 0;
                incedence[31][51] = 0;
                incedence[31][52] = 0;
                incedence[31][53] = -1;
                incedence[31][54] = 0;
                incedence[31][55] = 0;
                incedence[31][56] = 0;
                incedence[31][57] = 0;
                incedence[31][58] = 0;
                incedence[31][59] = 0;

                incedence[31][60] = 0;
                incedence[31][61] = 0;
                incedence[31][62] = 1;
                incedence[31][63] = 0;
  
               
               
              
///****2row          

                
                incedence[32][0] = 0;
                incedence[32][1] = 0;
                incedence[32][2] = 0;
                incedence[32][3] = 0;
                incedence[32][4] = 0;
                incedence[32][5] = 0;
                incedence[32][6] = 0;
                incedence[32][7] = 0;
                incedence[32][8] = 0;
                incedence[32][9] = 0;
                
                incedence[32][10] = 0;
                incedence[32][11] = 0;
                incedence[32][12] = 0;
                incedence[32][13] = 0;
                incedence[32][14] = 0;
                incedence[32][15] = 0;
                incedence[32][16] = 0;
                incedence[32][17] = 0;
                incedence[32][18] = 0;
                incedence[32][19] = 0;
                
                incedence[32][20] = 0;
                incedence[32][21] = 0;
                incedence[32][22] = 0;
                incedence[32][23] = 0;
                incedence[32][24] = 0;
                incedence[32][25] = 0;
                incedence[32][26] = 0;
                incedence[32][27] = 0;
                incedence[32][28] = 0;
                incedence[32][29] = 0;
               
                incedence[32][30] = 0;
                incedence[32][31] = 0;
                incedence[32][32] = 0;
                incedence[32][33] = 0;
                incedence[32][34] = 0;
                incedence[32][35] = 0;
                incedence[32][36] = 0;
                incedence[32][37] = 0;
                incedence[32][38] = 0;
                incedence[32][39] = 0;

                incedence[32][40] = 0;
                incedence[32][41] = 0;
                incedence[32][42] = 0;
                incedence[32][43] = 0;
                incedence[32][44] = 0;
                incedence[32][45] = 0;
                incedence[32][46] = 0;
                incedence[32][47] = -1;
                incedence[32][48] = 0;
                incedence[32][49] = 0;

                incedence[32][50] = 0;
                incedence[32][51] = 0;
                incedence[32][52] = 0;
                incedence[32][53] = 0;
                incedence[32][54] = 0;
                incedence[32][55] = -1;
                incedence[32][56] = 0;
                incedence[32][57] = 0;
                incedence[32][58] = 0;
                incedence[32][59] = 0;
                incedence[32][60] = 0;
                incedence[32][61] = 0;
                incedence[32][62] = 0;
                incedence[32][63] =1;

               
               ///****3row 

                incedence[33][0] = 0;
                incedence[33][1] = 0;
                incedence[33][2] = 0;
                incedence[33][3] = 0;
                incedence[33][4] = 0;
                incedence[33][5] = 0;
                incedence[33][6] = 0;
                incedence[33][7] = 0;
                incedence[33][8] = 0;
                incedence[33][9] = 0;
               
                incedence[33][10] = 0;
                incedence[33][11] = 0;
                incedence[33][12] = 0;
                incedence[33][13] = 0;
                incedence[33][14] = 0;
                incedence[33][15] = 0;
                incedence[33][16] = 0;
                incedence[33][17] = 0;
                incedence[33][18] = 0;
                incedence[33][19] = 0;
                
                incedence[33][20] = 0;
                incedence[33][21] = 0;
                incedence[33][22] = 0;
                incedence[33][23] = 0;
                incedence[33][24] = 0;
                incedence[33][25] = 0;
                incedence[33][26] = 0;
                incedence[33][27] = 0;
                incedence[33][28] = 0;
                incedence[33][29] = 0;
               
                incedence[33][30] = 0;
                incedence[33][31] = 0;
                incedence[33][32] = 0;
                incedence[33][33] = 0;
                incedence[33][34] = 0;
                incedence[33][35] = 0;
                incedence[33][36] = 0;
                incedence[33][37] = 0;
                incedence[33][38] = 0;
                incedence[33][39] = 0;

                incedence[33][40] = 0;
                incedence[33][41] = 0;
                incedence[33][42] = 0;
                incedence[33][43] = 0;
                incedence[33][44] = 0;
                incedence[33][45] = 0;
                incedence[33][46] = 0;
                incedence[33][47] = 0;
                incedence[33][48] = 0;
                incedence[33][49] = 0;

                incedence[33][50] = 0;
                incedence[33][51] = 0;
                incedence[33][52] = 0;
                incedence[33][53] = 0;
                incedence[33][54] = 0;
                incedence[33][55] = 0;
                incedence[33][56] = -1;
                incedence[33][57] = -1;
                incedence[33][58] = -1;
                incedence[33][59] = -1;

                incedence[33][60] = -1;
                incedence[33][61] = -1;
                incedence[33][62] = -1;
                incedence[33][63] = -1;

              ///****4row

               
    } 
  /*public void fill_Execution() {
        for (int i = 0; i < noftasks; i++) {
             execution[0] = 11;
            execution[1] = 12;
            execution[2] = 12;
            execution[3] = 13;
            execution[4] = 15;
            execution[5] = 9;
            execution[6] = 13;
            execution[7] = 12;  
           
        }
    }*/   
    //*** communication time for all edges ***//
    public void fill_Communication() {
        for (int i = 0; i < nofedges; i++) {
            
       // communication[i]=randomGenerator.nextInt((15 - 5) + 1) +5; 
        communication[i]=randomGenerator.nextInt((30 - 10) + 1) +10; 
    //communication[i]=randomGenerator.nextInt((100 - 50) + 1) +50; 
    //  communication[i]=randomGenerator.nextInt((100 - 50) + 1) +50; 
        
//           communication[0] = 3;
//            communication[1] = 2;
//            communication[2] = 4;
//            communication[3] = 3;
//            communication[4] = 4;
//            communication[5] = 3;
//            communication[6] = 4;
//            communication[7] = 5;
//            communication[8] = 4;
//            communication[9] = 3;
//            communication[10] = 2;
//            communication[11] = 3;
//            communication[12] = 4;
//            communication[13] = 3;
//            communication[14] = 3;
//            communication[15] = 4;
//            communication[16] = 5;
//            communication[17] =3;
//            communication[18] = 2;
//            communication[19] = 4;
//            communication[20] = 3;
//            communication[21] = 3;
//            communication[22] = 4;
//            communication[23] = 2;
//            communication[24] = 4;
//            communication[25] = 3;
//            communication[26] = 3;
//            communication[27] = 4;
//            communication[28] = 2;
//            communication[29] = 3;
//            communication[30] = 4;
//            communication[31] = 2;
//            communication[32] = 2;
//            communication[33] = 3;
//            communication[34] = 4;
//            communication[35] = 3;
//            communication[36] = 2;
//            communication[37] = 3;
//            communication[38] = 3;
//            communication[39] = 3;
//            communication[40] = 1; 
//            communication[41] = 3;
//            communication[42] = 2;
//            communication[43] = 3;
//            communication[44] = 2;
//            communication[45] = 4;
//            communication[46] = 4;
//            communication[47] = 3;
//            communication[48] = 4;
//            communication[49] = 2;
//            communication[50] = 2;
//            communication[51] = 4;
//            communication[52] = 3;
//            communication[53] = 4;
//            communication[54] = 3;
//            communication[55] = 2;
//            communication[56] = 3;
//            communication[57] = 3;
//            communication[58] = 4;
//            communication[59] = 2;
//            communication[60] = 4;
//            communication[61] = 2;
//            communication[62] = 3;
//            communication[63] = 3;
//         
                         }
                       }

     //*** Levels For All tasks ****************//
    public void fill_levels() {
        for (int i = 0; i < noftasks; i++) {
           level[0] = 0;
            level[1] = 1;
            level[2] = 1;
            level[3] = 1;
            level[4] = 1;
            level[5] = 1;
            level[6] = 1;
            level[7] = 1;
            level[8] = 1;
            level[9] = 2;
            level[10] = 2;
            level[11] = 2;
            level[12] = 2;
            level[13] = 2;
            level[14] = 2;
            level[15] =2;
            level[16] = 2;
            level[17] = 3;
            level[18] = 3;
            level[19] = 3;
            level[20] = 3;
            level[21] = 3;
            level[22] = 3;
            level[23] = 3;
            level[24] = 3;
            level[25] = 4;
            level[26] = 4;
            level[27] = 4;
            level[28] = 4;
            level[29] = 4;
            level[30] = 4;
            level[31] =4;
            level[32] = 4;
             level[33] = 5;

        
           
      }
    }
    public int degreeIn(int taski) {
        int count = 0;
        fill_Incedence();
        for (int col = 0; col < nofedges; col++) {
            if (incedence[taski][col] == -1) {
                count++;
            }
        }
        return count;
    }

    //****predeccessor to get parent nodes for each task ***//
    public int[][] predecessor(int node) {
        fill_Incedence();
        // degreeIn(node);
        int[][] flag = new int[2][degreeIn(node)];
        int index = 0;// count nodes have apredecessor
        for (int j = 0; j < nofedges; j++) {
            if ((incedence[node][j] == -1)) {
                flag[0][index] = j; // select edge ..
                for (int jj = 0; jj < noftasks; jj++) {
                    if ((incedence[jj][j] == 1)) {
                        flag[1][index] = jj; // select node ....
                        index++;
                        break;
                    }
                }
            }
        }
        return flag;
    }

    //********check start********//
    public boolean check_Start(int node) {
        return degreeIn(node) ==0;

    }

    //*** Degree out count Exit edges for task using incedence when cell=1 ****//
    public int degreeOut(int taski) {
        int count = 0;
        fill_Incedence();
        for (int col = 0; col < nofedges; col++) {
            if (incedence[taski][col] == 1) {
                count++;
            }
        }
        return count;
    }

    //************* Successor ************//
    public int[][] Successor(int node) {
        fill_Incedence();
        int[][] flag = new int[2][degreeOut(node)];
        int index = 0;
        for (int j = 0; j < nofedges; j++) {
            if ((incedence[node][j] == 1)) {
                flag[0][index] = j; // select edge ..
                for (int jj = 0; jj < noftasks; jj++) {
                    if ((incedence[jj][j] == -1)) {
                        flag[1][index] = jj; // select node ....
                        index++;
                        break;
                    }
                }
            }
        }
        return flag;
    }

    //********check End********//
    public boolean check_End(int node) {
        int flag = 0;
        fill_Incedence();
        for (int i = 0; i < nofedges; i++) {
            if (incedence[node][i] != 1) {
                flag++;
            } else {
                break;
            }
        }
        return (flag == nofedges);
        /*if( flag == nofedges ) return true;else return false;*/

    }

    public static void main(String[] args) {
        GraphSimulation obj = new GraphSimulation();
        
        
             System.out.println("Incedence Matrix");
            for (int row = 0; row < noftasks; row++) {
            for (int col = 0; col < nofedges; col++) {
            obj.fill_Incedence();
               
         System.err.print("\t"+obj.incedence[row][col]);
            
            
            }
                System.err.println("");   
            }
            
           // System.out.println("Execution Time");
           /*for (int n = 0; n < noftasks; n++) {
          // obj.fill_Execution();
            System.err.println(" node :"+n+"\t"+obj.execution[n]);
           }*/
           
            
           for (int e = 0; e < nofedges; e++) {
           obj.fill_Communication();
           // System.err.println(" \t \t \t Edge :"+e+"\t"+obj.communication[e]);
            System.err.println(obj.communication[e]);
           }
           
           
           
  
    }

}
