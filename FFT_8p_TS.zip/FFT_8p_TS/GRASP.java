/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package FFT_8p_TS;



import java.util.*;

/**
 *
 * @author Aplaa Saad
 */
public class GRASP {
      int cl[];
    public int RCL[];
    public int[] finalRCL;
    public double alpha = 0.4;
        public double beta = 0.6;
    int[] bestSol;
    double bestMake;
    int[] constructionSolution;
    MachineAssign S1;
    ArrayList<Double> probability;
    Set<int[]> solution;
    ArrayList<int[]> options;
    ArrayList<int[]> population;
    ArrayList<Double> pop_make;
    
    public void GRASP(){
   cl = new int[GraphSimulation.noftasks];
        constructionSolution = new int[GraphSimulation.noftasks];
        probability = new ArrayList<>();
        solution = new HashSet<>();
        options = new ArrayList<>();
        bestSol = new int[GraphSimulation.noftasks];
        population = new ArrayList<>();
        pop_make = new ArrayList<>();
    }

   
    // Validate Any Schedule
    public boolean validateConstruction() {
        boolean valid = true;
        for (int i = 0; i < constructionSolution.length; i++) {
            for (int ii = i + 1; ii < constructionSolution.length; ii++) {
                if ((GraphSimulation.level[constructionSolution[i]] > GraphSimulation.level[constructionSolution[ii]])) {
                    valid = false;
                    break;
                }
            }
        }

        return valid;
    }

    //      Phase 1 Construction Phase
    public void construct(int[] cl) throws Exception {
        if (cl.length < 1) throw new Exception("Empty input");
        GraphUtils obj = new GraphUtils();
        int rclLength = (int) (alpha * cl.length); // RCL length
        finalRCL = new int[GraphSimulation.noftasks];
        for (int i = 0; i < cl.length; i += rclLength) {
            int sliceSize;
            if (i + rclLength < cl.length) {
                sliceSize = rclLength;
            } else {
                sliceSize = cl.length - i;
            }
            int[] slice = Arrays.copyOfRange(cl, i, i + sliceSize);
            ArrayList shuffledSlice = new ArrayList<Integer>();
            int randomTaskIdx = getRandomNumberInRange(0, sliceSize - 1);


            while (shuffledSlice.size() < sliceSize) {
                if (randomTaskIdx >= 0 && randomTaskIdx < sliceSize && !(shuffledSlice.contains(slice[randomTaskIdx]))) {
                    shuffledSlice.add(slice[randomTaskIdx]);
                } else {
                    randomTaskIdx = getRandomNumberInRange(0, sliceSize - 1);
                }
            }

            // swap single slice
            for (int r = 0; r < sliceSize; r++) {
                for (int rr = r + 1; rr < sliceSize; rr++) {
                    if (GraphSimulation.level[(int) shuffledSlice.get(r)] > GraphSimulation.level[(int) shuffledSlice.get(rr)]) {
                        Collections.swap(shuffledSlice, r, rr);
                    }
                }
            }
            for (int r = 0; r < sliceSize; r++) {
                finalRCL[i + r] = (int) shuffledSlice.get(r);
            }
        }
        //ensure finalRCL in the correct order
        for (int r = 0; r < finalRCL.length; r++) {
            for (int rr = r + 1; rr < finalRCL.length; rr++) {
                if (GraphSimulation.level[finalRCL[r]] > GraphSimulation.level[finalRCL[rr]]) {
                    int temp = finalRCL[r];
                    finalRCL[r] = finalRCL[rr];
                    finalRCL[rr] = temp;
                }
            }
        }
        constructionSolution = finalRCL.clone();
    }

    //_________________local Search_________________//

  
 public void Search() {
     
       MachineAssign x = new MachineAssign();
        x.Assigning(constructionSolution);

        int beta_length = (int) (beta * GraphSimulation.noftasks); // the number of stable tasks
      /*w  for (int t = 0; t < DAG.noftasks; t++) {
            System.out.print(" T" + constructionSolution[t] + " ");
        }
        System.out.println("make : " + x.makespan + "  flow : " + x.flowtime);*/
        //----------------------------------------------------------------------

        for (int ii = GraphSimulation.noftasks - 1; ii >= beta_length + 1; ii--) {

            int temp = 0;
            if (GraphSimulation.level[constructionSolution[ii]] >= GraphSimulation.level[constructionSolution[ii - 1]]) {
                temp = constructionSolution[ii];
                constructionSolution[ii] = constructionSolution[ii - 1];
                constructionSolution[ii - 1] = temp;
            }
            MachineAssign s = new MachineAssign();
            s.Assigning(constructionSolution);

            if ((s.makespan > x.makespan)||((s.makespan == x.makespan))) {
              //  System.out.println("one .....ignored\n");
               temp = constructionSolution[ii];
               constructionSolution[ii] = constructionSolution[ii - 1];
               constructionSolution[ii - 1] = temp;

            } else {
                x.makespan = s.makespan;
               
              /*  for (int t = 0; t < DAG.noftasks; t++) {
                    System.out.print(" T" + constructionSolution[t] + " ");
                }
                System.out.println("make : " + s.makespan + "  flow : " + s.flowtime);
*/
            }
        }
    }
    
    
    
    // random number generation
    public int getRandomNumberInRange(int min, int max) {

       if (min >= max) {
            throw new IllegalArgumentException("max must be greater than min");
        }

        Random r = new Random();
        return r.nextInt((max - min) + 1) + min;
    }
      
      
          public static void main(String[] args) {
  ArrayList<Double> bestMake = new ArrayList<>();
        int noRuns = 20;
        try {
          
            for (int i = 0; i < noRuns; i++) {
       
                GRASP cp = new GRASP();
            int[] input = new GraphUtils().Bottom_Descending().clone();
             //int[] input = new GraphUtils().Top_Ascending().clone();
         //  int[] input = new GraphUtils().CriticalPath_Descending().clone();
                cp.construct(input);
                cp.Search();
               
// System.out.print("\033[36m  ");
           /* for (int x : cp.constructionSolution) {
                System.out.print(" T" + x + "  ");
            }*/
           MachineAssign s = new MachineAssign();
            s.Assigning(cp.constructionSolution);
             bestMake.add(s.makespan);
         System.out.print( + s.makespan+",");
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
          double sumOfMake = 0;
        for (double d :bestMake) {
            sumOfMake += d;
        } 
          double avgBestMake = sumOfMake / noRuns;
            
             System.out.print("\n Avg Make\t:: " + avgBestMake +"\n");                 
         
           
    
        }
      
      }
    
       

    


