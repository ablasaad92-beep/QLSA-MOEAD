package FFT_8P_QLSA_Prallel;


import java.util.*;
import java.util.logging.Level;
import java.util.logging.Logger;


/**
 * @author Aplaa Saad
 */
public class MOEAD {

    Solution first;
    Solution second;
    ArrayList<Solution> population;
    int[] bestSol;
    double bestMake;


    public MOEAD() {
        population = new ArrayList<>();
        bestSol = new int[GraphSimulation.noftasks];
    }

    public static int[][] findAllNeighbors(int populationSize, int neighborSize) {
        int[][] allNeighbors = new int[populationSize][];

        for (int i = 0; i < populationSize; i++) {
            int startIndex = Math.max(0, i - neighborSize + 1);
            int endIndex = Math.min(populationSize, i + neighborSize);

            int[] neighbors = new int[endIndex - startIndex];
            for (int j = startIndex; j < endIndex; j++) {
                neighbors[j - startIndex] = j;
            }

            allNeighbors[i] = neighbors;
        }

        return allNeighbors;
    }


    

    public static double[] getReferencePoint(double[][] functionValues) {
        double[] referencePoint = new double[2];

        List<Double> f1Values = new ArrayList<Double>();
        List<Double> f2Values = new ArrayList<Double>();
        for (int i = 0; i < functionValues.length; i++) {
            f1Values.add(functionValues[i][0]);
            f2Values.add(functionValues[i][1]);
        }

        referencePoint[0] = Collections.min(f1Values);
        referencePoint[1] = Collections.max(f2Values);
        return referencePoint;
    }

    double[][] getMakeSpanUtilization(ArrayList<Solution> pop) {
        double[][] arr = new double[pop.size()][2];
        for (int i = 0; i < pop.size(); i++) {
            Solution s = pop.get(i);
            arr[i][0] = s.makeSpan;
            arr[i][1] = s.resourceUtilization;
        }
        return arr;
    }


    // apply cross over
    public void crossOver(double crossoverProbability) {
        Random random = new Random();

        // Check if crossover should occur
        if (random.nextDouble() > crossoverProbability) {
            // If no crossover, return the parents as they are
            return;
        }

        // Randomly select the number of crossover points (1 to parent length - 1)
        int numCrossoverPoints = random.nextInt(GraphSimulation.noftasks - 1) + 1;

        // Sort the crossover points in ascending order
        int[] crossoverPoints = new int[numCrossoverPoints];
        for (int i = 0; i < numCrossoverPoints; i++) {
            crossoverPoints[i] = random.nextInt(GraphSimulation.noftasks);
        }
        Arrays.sort(crossoverPoints);

        // Create offspring by alternating between parents in each crossover segment
        int[] offspring1 = new int[GraphSimulation.noftasks];
        int[] offspring2 = new int[GraphSimulation.noftasks];

        int parentIndex = 0; // Start with the first parent
        for (int i = 0; i < GraphSimulation.noftasks; i++) {
            offspring1[i] = parentIndex == 0 ? first.tasksOrder[i] : second.tasksOrder[i];
            offspring2[i] = parentIndex == 0 ? second.tasksOrder[i] : first.tasksOrder[i];

            // Switch parent when a crossover point is reached
            if (Arrays.binarySearch(crossoverPoints, i) >= 0) {
                parentIndex = 1 - parentIndex;
            }
        }
        first.tasksOrder = offspring1;
        first.isAssigned = false;
        second.tasksOrder = offspring2;
        second.isAssigned = false;
    }
//  public void crossSA(double crossoverProbability) throws Exception {
//        Random random = new Random();
//
//        // Check if crossover should occur
//        if (random.nextDouble() > crossoverProbability) {
//            // If no crossover, return the parents as they are
//            return;
//        }
//    Greedy_SA s=new Greedy_SA();
//    s.construct(first.tasksOrder);
//    s.SearchSimulated();
//    s.construct(second.tasksOrder);
//    s.SearchSimulated();
//              first.isAssigned = false;
//              second.isAssigned = false;
//    }
////
//   public void crossTS(double crossoverProbability) throws Exception {
//        Random random = new Random();
//
//        // Check if crossover should occur
//        if (random.nextDouble() > crossoverProbability) {
//            // If no crossover, return the parents as they are
//            return;
//        }
//    GReedy_TabuSearch s=new GReedy_TabuSearch();
//    s.construct(first.tasksOrder);
//    s.Tabu_Search();
//    s.construct(second.tasksOrder);
//       s.Tabu_Search();
//              first.isAssigned = false;
//              second.isAssigned = false;
//    }
  
  
  
    // generate population weights method
    public void generatePopulationWeights() {
        int populationSize = population.size();
        double slice = 1.0 / (populationSize - 1);
        for (int i = 0; i < populationSize; i++) {
            population.get(i).weight.factor1 = i * slice;
            population.get(i).weight.factor2 = (1 - i * slice);
        }
    }

    void compareAndSwapIfMinimized(Solution mutatedSolution, int[][] allNeighbours, int iterationNo) {
        try {
            double derivedMOF = mutatedSolution.getMOF();
            for (int i = 0; i < allNeighbours[iterationNo].length; i++) {
                int itemIdx = allNeighbours[iterationNo][i];
                double mof = this.population.get(itemIdx).getMOF();
                if (derivedMOF < mof) {
                    population.set(itemIdx, mutatedSolution);
                }
            }
        } catch (Exception e) {
            System.out.println(e.getMessage());
        }
    }

    // initialize population
    public void initialization(MachineAssign atmp) {
        for (int i = 0; i < 100; i++) {
Qlearning_SA p = new Qlearning_SA();
            try {
p.construct();
p.SearchSimulated();
            } catch (Exception ex) {
                Logger.getLogger(MOEAD.class.getName()).log(Level.SEVERE, null, ex);
            }

// int[] tmp = new GraphUtils().random_population().clone();
int[] tmp = p.constructionSolution.clone();

            if (!atmp.isIdle()) atmp.resetMachine(); // reset machine
            atmp.Assigning(tmp);
            Solution s = new Solution(tmp);
            s.isAssigned = true;
            s.makeSpan = atmp.makespan;
            s.resourceUtilization = atmp.calculateBeta(MachineAssign.nofprocessors);
            population.add(s);
            atmp.resetMachine();
        }
        bestSol = population.get(0).tasksOrder.clone();
        bestMake = population.get(0).makeSpan;

    }

    // apply mutation
    public void mutation(MachineAssign atmp, double mutationProbability) {
        if (checkValid(first.tasksOrder) && checkValid(second.tasksOrder)) {
            Random random = new Random();

            // Check if mutation should occur
            if (random.nextDouble() > mutationProbability) {
                // If no mutation, return the chromosomes as it is
                return;
            }

            // Randomly select two distinct mutation points
            int mutationPoint1;
            int mutationPoint2;
            do {
                mutationPoint1 = random.nextInt(GraphSimulation.noftasks);
                mutationPoint2 = random.nextInt(GraphSimulation.noftasks);
            } while (mutationPoint2 == mutationPoint1 || (!(GraphSimulation.level[mutationPoint1] == GraphSimulation.level[mutationPoint2])));

            // Perform swap mutation for first solution
            int[] mutatedFirst = Arrays.copyOf(first.tasksOrder, GraphSimulation.noftasks);
            int temp = mutatedFirst[mutationPoint1];
            mutatedFirst[mutationPoint1] = mutatedFirst[mutationPoint2];
            mutatedFirst[mutationPoint2] = temp;
            first.tasksOrder = mutatedFirst;

            if (!atmp.isIdle()) atmp.resetMachine(); // make sure machine is idle
            // assign first mutated solution and then reset machine
            if (!first.isAssigned) {
                atmp.Assigning(first.tasksOrder);
                first.isAssigned = true;
                first.makeSpan = atmp.makespan;
                first.resourceUtilization = atmp.calculateBeta(MachineAssign.nofprocessors);
                atmp.resetMachine();
            }

            // Perform swap mutation for second solution
            int[] mutatedSecond = Arrays.copyOf(second.tasksOrder, GraphSimulation.noftasks);
            temp = mutatedSecond[mutationPoint1];
            mutatedSecond[mutationPoint1] = mutatedSecond[mutationPoint2];
            mutatedSecond[mutationPoint2] = temp;
            second.tasksOrder = mutatedSecond;


            // assign second mutated solution and then reset machine
            if (!second.isAssigned) {
                atmp.Assigning(second.tasksOrder);
                second.isAssigned = true;
                second.makeSpan = atmp.makespan;
                second.resourceUtilization = atmp.calculateBeta(MachineAssign.nofprocessors);
                atmp.resetMachine();
            }
        } else {
            first.isValid = checkValid(first.tasksOrder);
            second.isValid = checkValid(second.tasksOrder);
        }

    }

    // tournament size selection
    public void selection() {
        ArrayList<Solution> firstGroup = new ArrayList<>();
        ArrayList<Solution> secondGroup = new ArrayList<>();
        //select first random group
        for (int i = 0; i < 5; i++) {
            int temp = (int) (Math.random() * 20);
            firstGroup.add(population.get(temp));
        }
        for (int i = 0; i < 5; i++) {
            int temp = (int) (Math.random() * 20);
            secondGroup.add(population.get(temp));
        }
        int x1 = 0;
        for (int i = 1; i < firstGroup.size(); i++) {
            if (firstGroup.get(x1).makeSpan > firstGroup.get(i).makeSpan) {
                x1 = i;
            }
        }
        first = firstGroup.get(x1).clone();
        int x2 = 0;
        for (int i = 1; i < secondGroup.size(); i++) {
            if (secondGroup.get(x1).makeSpan > secondGroup.get(i).makeSpan) {
                x2 = i;
            }
        }
        second = secondGroup.get(x2).clone();
    }

    public int getRandomNumberInRange(int min, int max) {

        if (min >= max) {
            throw new IllegalArgumentException("max must be greater than min");
        }

        Random r = new Random();
        return r.nextInt((max - min) + 1) + min;
    }

    public boolean checkValid(int[] a) {
        boolean flag = true;
        for (int i = 0; i < GraphSimulation.noftasks; i++) {
            for (int ii = 0; ii < GraphSimulation.noftasks; ii++) {
                if ((i != ii) && (a[i] == a[ii])) {
                    flag = false;
                    break;
                }
            }
        }
        return flag;
    }

    private ArrayList<Solution> population(int i) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

}

class Solution implements Cloneable {
    int[] tasksOrder;
    boolean isAssigned;
    boolean isValid;
    double makeSpan;
    double resourceUtilization;

    Weight weight;

    public Solution(int[] tasksOrder) {
        this.tasksOrder = tasksOrder;
        isAssigned = false;
        isValid = true;
        weight = new Weight();
    }

    double getMOF() throws Exception {
        if (!isAssigned) throw new Exception("Solution doesn't assigned yet");
        return this.weight.factor1 * makeSpan - (this.weight.factor2 * (1 / resourceUtilization));
    }

    @Override
    public Solution clone() {
        try {
            return (Solution) super.clone();
        } catch (CloneNotSupportedException e) {
            throw new AssertionError();
        }
    }

    @Override
//    public String toString() {
//        return "Solution{" +
//                "tasksOrder=" + Arrays.toString(tasksOrder) +
//                ", isAssigned=" + isAssigned +
//                ", isValid=" + isValid +
//                ", makeSpan=" + makeSpan +
//                ", resourceUtilization=" + resourceUtilization +
//                ", weight=" + weight +
//                '}';
//    }
    public String toString() {
        return
                makeSpan + "\t" + resourceUtilization;
    }

    public static class Weight {
        double factor1, factor2;

        @Override
        public String toString() {
            return "Weight{" +
                    "factor1=" + factor1 +
                    ", factor2=" + factor2 +
                    '}';
        }
    }

}